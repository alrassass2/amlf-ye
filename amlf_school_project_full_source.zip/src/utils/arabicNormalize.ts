/**
 * Utility to normalize Arabic text for robust search.
 * Ignores all diacritics (tashkeel), simplifies Arabic letters variations:
 * - Normalizes (أ / إ / آ / ا) to standard alef (ا)
 * - Normalizes (ة / ه) to standard hāʾ (ه)
 * - Normalizes (ي / ى) to standard yāʾ (ي)
 */
export function normalizeArabicText(text: string): string {
  if (!text) return "";
  return text
    .replace(/[\u064B-\u0652]/g, "") // remove tashkeel
    .replace(/[أإآا]/g, "ا")
    .replace(/[ىي]/g, "ي")
    .replace(/[ةه]/g, "ه")
    .replace(/\s+/g, " ") // normalize spacing
    .trim()
    .toLowerCase();
}

/**
 * Perform a highly flexible Arabic-aware lookup.
 * Returns true if candidate contains query after normalization.
 */
export function arabicSearchMatch(candidate: string, query: string): boolean {
  if (!candidate || !query) return false;
  const normCandidate = normalizeArabicText(candidate);
  const normQuery = normalizeArabicText(query);
  return normCandidate.includes(normQuery);
}
