import React, { useState } from "react";
import { Student } from "../types";
import { initialStudents, saveData, getSavedData } from "../data";
import { BookOpen, User, Calendar, Award, MessageSquare, Send, Bot, FileText, CheckCircle, Clock } from "lucide-react";

export default function StudentPortal() {
  const [studentId, setStudentId] = useState<string>("");
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [hasLoggedIn, setHasLoggedIn] = useState<boolean>(false);
  const [errorText, setErrorText] = useState<string>("");

  // Daily temporary homework variables matching student's grade (24 hour expiration)
  const [solvingDailyId, setSolvingDailyId] = useState<string | null>(null);
  const [dailySolutionInput, setDailySolutionInput] = useState<string>("");
  const [dailySolutions, setDailySolutions] = useState<any[]>(() => 
    getSavedData<any[]>("school_daily_homeworks_solutions", [])
  );

  // Homework submission states
  const [submittingAssignmentId, setSubmittingAssignmentId] = useState<string | null>(null);
  const [submissionText, setSubmissionText] = useState<string>("");

  // AI Chat states
  const [chatMessages, setChatMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([
    { role: "assistant", content: "أهلاً بك يا بطل المستقبل! أنا مساعدك التعليمي الذكي في مدرسة أمل المستقبل وطموحنا مساندتك. يمكنك أن تسألني لشرح أي جزء من منهج الحساب، العلوم، قواعد اللغة العربية، الإعراب، أو اللغة الإنجليزية، واقتراح خطط دراسية ممتازة ومثالية للمراجعة اليوم." }
  ]);
  const [userMsg, setUserMsg] = useState<string>("");
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  // Custom AI knowledge base state and Administration states
  const [customKnowledgeRaw, setCustomKnowledgeRaw] = useState<string>(() => {
    return localStorage.getItem("school_ai_custom_knowledge") || 
`دوام|يبدأ الدوام الرسمي في المدرسة من الساعة 7:30 صباحاً وحتى الساعة 1:00 ظهراً لكافة المراحل الأكاديمية.
باص|خدمة الباص والحافلات المدرسية تغطي كافة المربعات السكنية وتكلفتها السنوية تبدأ من 2000 ريال ويمكن تسجيل الأبناء بسهولة بالتنسيق مع الكنترول والمنصة المالية.
الرسوم|الرسوم الدراسية للمدرسة متميزة ومقسمة لأقساط شهرية أو ربع سنوية في لوحة متابعة الرسوم وحجوزات الباص.
تواصل|يمكن التواصل مع الإدارة للتسجيل والردود عبر الخط الساخن مباشرة أو بالنقر على زر المطور ALRASSASS للانتقال إلى الواتس آب مباشرة +967774632249.
موقع الكنترول|بوابة رصد وتعديل النتائج للكنترول تتوفر في أسفل الصفحة لأعضاء الهيئة الإدارية للمدرسة.`;
  });

  const [showKnowledgeModal, setShowKnowledgeModal] = useState<boolean>(false);
  const [knowledgePassword, setKnowledgePassword] = useState<string>("");
  const [isKnowledgeAuthorized, setIsKnowledgeAuthorized] = useState<boolean>(false);
  const [knowledgeErrorMsg, setKnowledgeErrorMsg] = useState<string>("");
  const [knowledgeSuccessMsg, setKnowledgeSuccessMsg] = useState<string>("");

  const parseCustomRules = (rawText: string) => {
    const lines = rawText.split("\n");
    const rules: { keywords: string[]; answer: string }[] = [];
    for (const line of lines) {
      if (!line.trim()) continue;
      if (line.includes("|")) {
        const [keyPart, ansPart] = line.split("|");
        if (keyPart && ansPart) {
          const keywords = keyPart.split(",").map(k => k.trim().toLowerCase()).filter(Boolean);
          rules.push({ keywords, answer: ansPart.trim() });
        }
      } else {
        const separators = [":", "：", "-", " - "];
        let matched = false;
        for (const sep of separators) {
          if (line.includes(sep)) {
            const parts = line.split(sep);
            const keyPart = parts[0];
            const ansPart = parts.slice(1).join(sep);
            if (keyPart && ansPart && keyPart.trim().length > 0 && ansPart.trim().length > 0) {
              const keywords = keyPart.split(",").map(k => k.trim().toLowerCase()).filter(Boolean);
              rules.push({ keywords, answer: ansPart.trim() });
              matched = true;
              break;
            }
          }
        }
      }
    }
    return rules;
  };

  // Suggested questions list
  const samplePrompts = [
    "كيف أقوم بإعراب قصيدة لغة الضاد؟",
    "اشرح لي جدول ضرب الرقم 9 بطريقة ميسرة",
    "ما هي عوارض الخلايا النباتية في العلوم؟",
    "اكتب لي خطة دراسية ممتعة ومبسطة للمراجعة قبل النهائي"
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText("");

    if (!studentId.trim()) return;

    const savedStudents = getSavedData<Student[]>("school_students", initialStudents);
    const found = savedStudents.find(s => s.id === studentId.trim());

    if (found) {
      setCurrentStudent(found);
      setHasLoggedIn(true);
    } else {
      setErrorText("عذراً، الرقم الأكاديمي غير مسجل أو منتهي الفعالية. يرجى مراجعة الجدول أو استخدام الرقم 101 للتجربة.");
    }
  };

  const handleLogout = () => {
    setCurrentStudent(null);
    setHasLoggedIn(false);
    setStudentId("");
  };

  const handleUploadHomework = (assignmentId: string) => {
    setSubmittingAssignmentId(assignmentId);
    setSubmissionText("");
  };

  const submitHomework = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentStudent || !submittingAssignmentId || !submissionText.trim()) return;

    // Load entire database of school students
    const savedStudents = getSavedData<Student[]>("school_students", initialStudents);
    
    // Find index of targeted student
    const sIdx = savedStudents.findIndex(s => s.id === currentStudent.id);
    if (sIdx !== -1) {
      const student = savedStudents[sIdx];
      // Find assignment under student
      const aIdx = student.assignments.findIndex(a => a.id === submittingAssignmentId);
      if (aIdx !== -1) {
        student.assignments[aIdx].status = "submitted";
        student.assignments[aIdx].feedback = `تم رفع واجبك الرقمي الموثق: "${submissionText}" وسيتم تقويمه بواسطة المعلم قريباً.`;
      }
      
      saveData("school_students", savedStudents);
      setCurrentStudent({ ...student });
    }

    setSubmittingAssignmentId(null);
    setSubmissionText("");
  };

  const getActiveDailyHomeworks = (grade: string) => {
    const raw = getSavedData<any[]>("school_daily_homeworks", []);
    const now = Date.now();
    return raw.filter((hw) => {
      const isRecent = (now - hw.createdAt) < 24 * 60 * 60 * 1000;
      const isForClass = hw.targetGrade === grade;
      return isRecent && isForClass;
    });
  };

  const handleSolveDailyHomework = (hwId: string, text: string) => {
    if (!currentStudent || !text.trim()) return;

    const newSolution = {
      id: "dsol-" + Date.now() + "-" + Math.floor(Math.random() * 1000),
      homeworkId: hwId,
      studentId: currentStudent.id,
      studentName: currentStudent.name,
      solutionText: text.trim(),
      submittedAt: Date.now()
    };

    const updated = [newSolution, ...dailySolutions];
    setDailySolutions(updated);
    saveData("school_daily_homeworks_solutions", updated);
    
    setSolvingDailyId(null);
    setDailySolutionInput("");
  };

  const handleSendAiMessage = async (promptMsg: string) => {
    if (!promptMsg.trim()) return;

    const updatedMessages = [...chatMessages, { role: "user" as const, content: promptMsg }];
    setChatMessages(updatedMessages);
    setUserMsg("");
    setAiLoading(true);

    // 1. Check for immediate instant local knowledge matching first without calling external AI (per requirements!)
    const normalizedPrompt = promptMsg.toLowerCase();
    const rules = parseCustomRules(customKnowledgeRaw);
    let matchedReply = "";

    for (const r of rules) {
      const matchFound = r.keywords.some(kw => normalizedPrompt.includes(kw));
      if (matchFound) {
        matchedReply = r.answer;
        break;
      }
    }

    if (matchedReply) {
      // Simulate small delay to mimic live response but extremely fast offline-like response
      setTimeout(() => {
        setChatMessages(prev => [...prev, { role: "assistant" as const, content: matchedReply }]);
        setAiLoading(false);
      }, 350);
      return;
    }

    // 2. Fallback to Gemini with prepended admin info
    try {
      const customContext = `أنت المساعد الذكي لمدرسة أمل المستقبل. متاح لك الالتزام التام ببيانات المدرسة وملفها العام المدرج من الإدارة:\n${customKnowledgeRaw}\nتجاوب بناء على هذه التوجيهات تماماً وبأسلوب مهذب ومحبب للطلاب.`;
      
      const payloadMessages = [
        { role: "user" as const, content: `تعليمات خاصة بإدارة المدرسة:\n${customContext}` },
        { role: "assistant" as const, content: "مفهوم تماماً، سألتزم بجميع بيانات وقواعد الإدارة وأجيب الطلاب بناء على معلوماتكم المعتمدة." },
        ...updatedMessages
      ];

      const response = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: payloadMessages }),
      });

      const data = await response.json();
      if (response.ok && data.text) {
        setChatMessages(prev => [...prev, { role: "assistant" as const, content: data.text }]);
      } else {
        setChatMessages(prev => [...prev, { 
          role: "assistant" as const, 
          content: `عذراً، حدثت هفوة في خادم الاتصال: "${data.error || 'يرجى مراجعة إعدادات مفتاح Gemini API'}"` 
        }]);
      }
    } catch (err: any) {
      console.error("Gemini API request error:", err);
      setChatMessages(prev => [...prev, { 
        role: "assistant" as const, 
        content: "تعذر الاتصال بخادم الذكاء الاصطناعي، يرجى الفحص والتحقق من تشغيل اتصال الإنترنت ومفتاح Gemini دقة." 
      }]);
    } finally {
      setAiLoading(false);
    }
  };

  // Calculate upcoming assignments in the next 7 days (based on active time: 2026-05-20)
  const todayStart = (() => {
    const d = new Date();
    // fallback or force to 2026-05-20 for full stability against static mock dates
    if (d.getFullYear() !== 2026) {
      return new Date(2026, 4, 20); // May 20, 2026
    }
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  })();
  const sevenDaysLater = new Date(todayStart.getTime() + 7 * 24 * 60 * 60 * 1000);

  const upcomingAssignments = currentStudent
    ? currentStudent.assignments.filter((ass) => {
        const assDate = new Date(ass.dueDate);
        return assDate >= todayStart && assDate <= sevenDaysLater;
      })
    : [];

  return (
    <div id="student-portal-section" className="space-y-12 pb-12 text-right">
      
      {!hasLoggedIn ? (
        <div className="max-w-md mx-auto bg-white p-8 rounded-3xl border border-slate-100 shadow-md space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-primary/10 text-primary border border-primary/20 rounded-full flex items-center justify-center mx-auto text-2xl font-bold">
              🎓
            </div>
            <h2 className="text-xl font-bold text-slate-900 font-display">منصة الطالب التعليمية الذكية</h2>
            <p className="text-xs text-slate-500">سجل الدخول باستخدام رقمك الأكاديمي لمشاهدة الواجبات وحل الفروض والمذاكرة بالذكاء الاصطناعي.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">الرقم الأكاديمي للطالب:</label>
              <input
                id="student-portal-id-input"
                type="text"
                required
                placeholder="أدخل رقمك الأكاديمي (مثال: 101، 102)"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-center font-mono focus:outline-none focus:border-primary/50"
              />
            </div>

            {errorText && (
              <p className="text-xs text-rose-600 bg-rose-50 p-2.5 rounded-lg border border-rose-100">{errorText}</p>
            )}

            <button
              id="btn-login-student"
              type="submit"
              className="w-full bg-primary hover:bg-slate-800 text-white font-bold py-3.5 rounded-xl text-xs transition duration-200 shadow-md"
            >
              تسجيل الدخول للمنصة
            </button>
          </form>

          <div className="text-center border-t border-slate-50 pt-4 text-[10px] text-slate-400">
            <span>💡 للاختبار، أدخل الرقم الأكاديمي <strong>101</strong> للطالب عمر، أو <strong>102</strong> للطالبة سارة.</span>
          </div>
        </div>
      ) : (
        currentStudent && (
          <div className="space-y-8 animate-fade-in">
            {/* Student Dashboard Header bar */}
            <div className="bg-gradient-to-r from-primary to-secondary text-white rounded-3xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-4 shadow-md">
              <div className="flex items-center gap-4 text-right">
                <div className="w-14 h-14 bg-white/10 border border-white/20 rounded-full flex items-center justify-center text-xl font-bold">
                  🎒
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white font-display">{currentStudent.name}</h2>
                  <p className="text-xs text-blue-150 mt-1">{currentStudent.grade} | رقم أكاديمي: {currentStudent.id}</p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <div className="bg-white/5 border border-white/10 px-4 py-2 rounded-xl text-center">
                  <p className="text-xs text-blue-200 leading-none">معدل الحضور</p>
                  <p className="text-lg font-extrabold text-accent mt-1">
                    {Math.round((currentStudent.attendance.present / (currentStudent.attendance.present + currentStudent.attendance.absent)) * 100)}%
                  </p>
                </div>
                <button
                  id="btn-logout-student"
                  onClick={handleLogout}
                  className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-4 py-2 rounded-xl text-xs font-bold transition duration-150"
                >
                  خروج من المنصة
                </button>
              </div>
            </div>

            {/* Core Content Layout Block */}
            <div className="grid lg:grid-cols-12 gap-8">
              
              {/* Left Column: Homework & Grades (8 cols) */}
              <div className="lg:col-span-7 space-y-8">
                
                {/* 24-Hour Temporary Daily Homeworks Block (من عتاد الفصول الدراسية وتجمعها) */}
                <div className="bg-gradient-to-br from-sky-50 to-indigo-50/50 border-2 border-sky-200 rounded-3xl p-6 shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-sky-100 pb-3">
                    <div className="flex items-center gap-3 justify-start">
                      <div className="p-2.5 bg-sky-500 text-white rounded-xl shadow-sm animate-bounce">
                        <Clock className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-900 font-display text-base">📌 الواجبات اليومية المؤقتة لصفك الدراسي</h4>
                        <p className="text-[11px] text-sky-850 font-semibold">تظهر فور بث المعلمين وتنحذف تلقائياً من نظام صفحة الطالب بعد مرور 24 ساعة</p>
                      </div>
                    </div>
                    <span className="bg-sky-100 text-sky-900 text-[10px] font-bold px-3 py-1 rounded-full shrink-0">
                      صلاحية 24 ساعة
                    </span>
                  </div>

                  {(() => {
                    const activeDHW = getActiveDailyHomeworks(currentStudent.grade);
                    if (activeDHW.length === 0) {
                      return (
                        <div className="text-center py-6 bg-white border border-dashed border-sky-200 rounded-2xl">
                          <p className="text-2xl">☀️</p>
                          <p className="text-xs font-bold text-slate-600 mt-1">لا توجد واجبات يومية معلقة لصفك الدراسي حالياً!</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">المعلمون يبثون الأسئلة الدورية باستمرار، فور بث أي تكليف سيصلك هنا ويزول تلقائياً بعد 24 ساعة.</p>
                        </div>
                      );
                    }

                    return (
                      <div className="space-y-4">
                        {activeDHW.map((hw) => {
                          const hasSolved = dailySolutions.find(sol => sol.homeworkId === hw.id && sol.studentId === currentStudent.id);
                          const elapsed = Date.now() - hw.createdAt;
                          const hoursLeft = Math.max(0, 24 - elapsed / (1000 * 60 * 60));
                          const formattedHours = Math.floor(hoursLeft);
                          const formattedMinutes = Math.floor((hoursLeft % 1) * 60);

                          return (
                            <div key={hw.id} className="p-4 bg-white border border-sky-100 rounded-2xl space-y-3 shadow-xs hover:border-sky-300 transition-colors">
                              <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
                                <div className="flex items-center gap-1.5 font-bold">
                                  <span className="bg-sky-100 text-sky-800 text-[10px] px-2 py-0.5 rounded border border-sky-200">
                                    {hw.subject}
                                  </span>
                                  <span className="text-slate-500">
                                    بواسطة: {hw.teacherName}
                                  </span>
                                </div>
                                <span className="text-amber-600 font-extrabold text-[10.5px] bg-amber-50 px-2 py-0.5 rounded flex items-center gap-0.5 border border-amber-100">
                                  ⏱️ المتبقي للحل: {formattedHours} ساعة و {formattedMinutes} دقيقة
                                </span>
                              </div>

                              <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100/50">
                                <p className="text-slate-800 text-xs font-semibold leading-relaxed whitespace-pre-wrap">{hw.title}</p>
                              </div>

                              {hasSolved ? (
                                <div className="bg-emerald-50 text-emerald-850 p-3 rounded-xl border border-emerald-100 text-xs font-semibold space-y-1">
                                  <p className="flex items-center gap-1 text-emerald-800 font-bold">
                                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                                    <span>تم إرسال إجابتك وحفظ التكليف بنهج رسمي:</span>
                                  </p>
                                  <p className="italic bg-white p-2 rounded-lg border border-emerald-50 text-[11px] text-slate-705">“ {hasSolved.solutionText} ”</p>
                                </div>
                              ) : (
                                <div className="space-y-2">
                                  {solvingDailyId === hw.id ? (
                                    <div className="bg-sky-50/20 p-3 rounded-xl border border-sky-100 space-y-2.5">
                                      <textarea
                                        rows={2}
                                        required
                                        placeholder="اكتب إجابتك أو الحل هنا بوضوح..."
                                        value={dailySolutionInput}
                                        onChange={(e) => setDailySolutionInput(e.target.value)}
                                        className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-medium focus:outline-none focus:border-sky-400 text-right"
                                      />
                                      <div className="flex justify-end gap-1.5">
                                        <button
                                          type="button"
                                          onClick={() => { setSolvingDailyId(null); setDailySolutionInput(""); }}
                                          className="bg-white border text-slate-500 px-3 py-1 rounded-lg text-[10px]"
                                        >
                                          إلغاء
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => handleSolveDailyHomework(hw.id, dailySolutionInput)}
                                          className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-1 rounded-lg text-[10px]"
                                        >
                                          تسليم الإجابة فورًا
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => { setSolvingDailyId(hw.id); setDailySolutionInput(""); }}
                                      className="bg-sky-600 hover:bg-sky-700 active:bg-indigo-900 text-white font-bold px-4 py-2 rounded-xl text-xs transition duration-150 shadow-xs"
                                    >
                                      حل الواجب اليومي وإرسال الجواب
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    );
                  })()}
                </div>

                {/* Upcoming Assignments to be submitted in the next 7 days */}
                <div className="bg-gradient-to-br from-amber-50 to-orange-50/40 border-2 border-amber-200/50 rounded-3xl p-6 shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-200/30 pb-3">
                    <div className="flex items-center gap-3 justify-start">
                      <div className="p-2 bg-amber-500 text-white rounded-xl shadow-sm animate-pulse">
                        <Clock className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-900 font-display text-base">⏳ واجبات قادمة (تستحق خلال 7 أيام)</h4>
                        <p className="text-[11px] text-amber-850 font-semibold">بادر بحل فروضك الدراسية المتأخرة لتحقيق أفضل الدرجات والتميز الأكاديمي</p>
                      </div>
                    </div>
                    <span className="bg-amber-100 text-amber-900 text-[10px] font-bold px-3 py-1 rounded-full shrink-0">
                      7 أيام قادمة
                    </span>
                  </div>

                  {upcomingAssignments.length > 0 ? (
                    <div className="grid gap-3">
                      {upcomingAssignments.map((ass) => {
                        // calculate days difference
                        const assDate = new Date(ass.dueDate);
                        const daysLeft = Math.ceil((assDate.getTime() - todayStart.getTime()) / (1000 * 60 * 60 * 24));
                        return (
                          <div key={ass.id} className="p-4 bg-white border border-amber-100/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm hover:border-amber-300 transition-colors">
                            <div className="space-y-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="text-[10px] bg-amber-100 text-amber-900 font-extrabold px-2 py-0.5 rounded border border-amber-200">{ass.subject}</span>
                                <span className={`text-[9px] px-2 py-0.5 rounded font-extrabold ${
                                  daysLeft <= 0 ? "bg-red-100 text-red-800" :
                                  daysLeft === 1 ? "bg-orange-150 text-orange-900" :
                                  "bg-amber-150 text-amber-900"
                                }`}>
                                  {daysLeft <= 0 ? "يستحق اليوم!" : daysLeft === 1 ? "يستحق غداً!" : `متبقي ${daysLeft} يوم`}
                                </span>
                              </div>
                              <h5 className="font-bold text-slate-800 text-xs">{ass.title}</h5>
                              <p className="text-[10px] text-slate-400">تاريخ التسليم الأقصى: {ass.dueDate}</p>
                            </div>

                            <div className="shrink-0">
                              {ass.status === "pending" ? (
                                <button
                                  id={`btn-upcoming-solve-${ass.id}`}
                                  onClick={() => handleUploadHomework(ass.id)}
                                  className="bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs transition duration-150 shadow-sm"
                                >
                                  حل الواجب ورفع الإجابة
                                </button>
                              ) : ass.status === "submitted" ? (
                                <span className="text-xs bg-amber-50 text-amber-700 font-bold px-3 py-1.5 rounded-full border border-amber-100/50">قيد المراجعة</span>
                              ) : (
                                <span className="text-xs bg-emerald-50 text-emerald-850 font-bold px-3 py-1.5 rounded-full border border-emerald-100">✓ تم التقويم ({ass.grade})</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-6 bg-white border border-dashed border-amber-200 rounded-2xl">
                      <p className="text-2xl">🎉</p>
                      <p className="text-xs font-bold text-slate-600 mt-1">لا توجد واجبات معلقة تستحق خلال الـ 7 أيام القادمة!</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">عمل رائع يا بطل! لقد أنجزت فروضك وواجباتك المدرسية أولاً بأول.</p>
                    </div>
                  )}
                </div>

                {/* 1. Academic homework task center */}
                <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center gap-3 justify-start pb-2 border-b border-slate-50">
                    <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                      <FileText className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-800 font-display">الواجبات والمهام الدراسية النشطة</h3>
                  </div>

                  {submittingAssignmentId ? (
                    <form onSubmit={submitHomework} className="bg-slate-50 p-4 rounded-xl border border-slate-150 space-y-3">
                      <p className="text-xs font-bold text-slate-700">تأكيد رفع الإجابة للواجب المحدد:</p>
                      <textarea
                        required
                        rows={3}
                        placeholder="اكتب إجابتك هنا بوضوح وسيحفظ عملك ريثما يتم تقويمه..."
                        value={submissionText}
                        onChange={(e) => setSubmissionText(e.target.value)}
                        className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
                      />
                      <div className="flex gap-2 justify-end">
                        <button
                          type="button"
                          onClick={() => setSubmittingAssignmentId(null)}
                          className="bg-white text-slate-500 border border-slate-200 px-3 py-1.5 rounded-lg text-xs"
                        >
                          إلغاء الأمر
                        </button>
                        <button
                          id="btn-confirm-upload"
                          type="submit"
                          className="bg-primary text-white font-bold px-4 py-1.5 rounded-lg text-xs"
                        >
                          إرسال الواجب للمعلم
                        </button>
                      </div>
                    </form>
                  ) : null}

                  <div className="space-y-4 pt-2">
                    {currentStudent.assignments.map((ass) => (
                      <div key={ass.id} className="p-4 bg-slate-50/50 rounded-xl border border-slate-100/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <span className="text-[10px] bg-blue-50 text-primary font-bold px-2 py-0.5 rounded border border-blue-100">{ass.subject}</span>
                          <h4 className="font-bold text-slate-800 text-xs">{ass.title}</h4>
                          <p className="text-[10px] text-slate-400 flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" /> تاريخ التسليم: {ass.dueDate}
                          </p>
                          {ass.feedback && <p className="text-[11px] bg-amber-50 text-amber-800 p-2 rounded border border-amber-100/55 mt-2">{ass.feedback}</p>}
                        </div>

                        <div className="shrink-0">
                          {ass.status === "pending" ? (
                            <button
                              id={`btn-upload-${ass.id}`}
                              onClick={() => handleUploadHomework(ass.id)}
                              className="bg-primary hover:bg-slate-800 text-white font-bold px-4 py-2 rounded-xl text-xs transition"
                            >
                              حل الواجب ورفع العمل
                            </button>
                          ) : ass.status === "submitted" ? (
                            <span className="text-xs bg-amber-50 text-amber-700 font-bold px-3 py-1.5 rounded-full">قيد الانتظار لموافقة المعلم</span>
                          ) : (
                            <div className="text-right">
                              <span className="text-xs bg-emerald-50 text-emerald-700 font-bold px-3 py-1.5 rounded-full block text-center">✓ تم التقويم: {ass.grade}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. Grades card */}
                <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center gap-3 justify-start pb-2 border-b border-slate-50">
                    <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
                      <Award className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-800 font-display">رصد الدرجات التفصيلي لهذا الشهر</h3>
                  </div>

                  <div className="space-y-3">
                    {currentStudent.grades.map((score, i) => {
                      // Determine performance indicators dynamically
                      let qualityColor = "bg-emerald-50 text-emerald-850 border-emerald-200";
                      let dotColor = "bg-emerald-500";
                      let indicatorEmoji = "🌟";

                      if (score.total >= 85) {
                        qualityColor = "bg-emerald-50 text-emerald-800 border-emerald-200";
                        dotColor = "bg-emerald-500";
                        indicatorEmoji = "🌟";
                      } else if (score.total >= 65) {
                        qualityColor = "bg-amber-50 text-amber-800 border-amber-200";
                        dotColor = "bg-amber-500";
                        indicatorEmoji = "✨";
                      } else {
                        qualityColor = "bg-rose-50 text-rose-800 border-rose-200";
                        dotColor = "bg-rose-500";
                        indicatorEmoji = "⚠️";
                      }

                      return (
                        <div key={i} className="py-3 border-b border-slate-55 flex items-center justify-between text-xs flex-wrap gap-2 hover:bg-slate-50/50 px-2 rounded-lg transition-colors">
                          <div className="flex items-center gap-2">
                            <span className={`w-2.5 h-2.5 rounded-full ${dotColor} shrink-0`} />
                            <span className="font-semibold text-slate-800">{score.subject}</span>
                          </div>
                          <div className="flex items-center gap-3 flex-wrap">
                            <span className="text-slate-400">العلامة: <strong className="text-primary font-bold text-sm font-mono">{score.total}</strong> / 100</span>
                            <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] font-extrabold ${qualityColor}`}>
                              <span>{indicatorEmoji}</span>
                              <span>{score.grade}</span>
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right Column: Floating beautiful AI Tutor assistant widget (5 cols) */}
              <div className="lg:col-span-5 space-y-6">
                
                {/* AI Chat Widget */}
                <div className="bg-white border-2 border-primary/20 rounded-3xl shadow-md overflow-hidden flex flex-col justify-between h-[520px]">
                  
                  {/* AI Widget Header */}
                  <div className="bg-primary text-white p-4 flex items-center justify-between gap-3 relative">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white/10 rounded-xl shrink-0">
                        <Bot className="w-6 h-6 text-accent" />
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-white font-display">مساعد أمل الذكي (الذكاء الاصطناعي)</h3>
                        <p className="text-[10px] text-blue-150">مرشد ومساعد دراسي ذكي للطلاب على مدار الساعة</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setShowKnowledgeModal(true);
                        setKnowledgePassword("");
                        setIsKnowledgeAuthorized(false);
                        setKnowledgeErrorMsg("");
                        setKnowledgeSuccessMsg("");
                      }}
                      className="bg-white/15 hover:bg-white/25 active:bg-white/35 text-white font-extrabold text-[10px] px-2.5 py-1.5 rounded-lg border border-white/20 transition duration-150 cursor-pointer shadow-xs whitespace-nowrap"
                    >
                      ⚙️ تحديث البيانات
                    </button>
                  </div>

                  {/* Message Stream */}
                  <div className="flex-grow p-4 overflow-y-auto space-y-4 text-xs bg-slate-50">
                    {chatMessages.map((msg, i) => (
                      <div key={i} className={`flex max-w-[85%] flex-col ${msg.role === "user" ? "mr-auto text-left" : "ml-auto text-right"}`}>
                        <div className={`p-3 rounded-2xl leading-relaxed whitespace-pre-wrap ${
                          msg.role === "user" 
                            ? "bg-primary text-white rounded-tl-none text-right" 
                            : "bg-white text-slate-800 border border-slate-100 rounded-tr-none text-right shadow-sm"
                        }`}>
                          {msg.content}
                        </div>
                      </div>
                    ))}
                    {aiLoading && (
                      <div className="ml-auto text-right max-w-[80%] flex items-center gap-2 p-3 bg-white rounded-2xl border border-slate-100 shadow-sm">
                        <span className="animate-spin text-primary">⚙️</span>
                        <span className="text-slate-400 text-[11px]">مساعد أمل يراجع الدرس ويكتب الإجابة الفنية...</span>
                      </div>
                    )}
                  </div>

                  {/* Suggestions drawer */}
                  <div className="p-2.5 bg-white border-t border-slate-50">
                    <p className="text-[10px] text-slate-400 mb-1.5 font-bold">💡 أسئلة يمكنك تصفح نقاشها للمذاكرة:</p>
                    <div className="flex flex-wrap gap-1.5 justify-start">
                      {samplePrompts.map((p, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendAiMessage(p)}
                          className="bg-slate-50 hover:bg-slate-100 text-slate-650 text-[10px] px-2.5 py-1.5 rounded-lg border border-slate-150 transition-colors"
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Input form */}
                  <div className="p-3 bg-slate-50 border-t border-slate-100">
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleSendAiMessage(userMsg);
                      }} 
                      className="flex gap-2"
                    >
                      <input
                        type="text"
                        placeholder="اطرح استفساراً في الرياضيات، النحو، أو التاريخ..."
                        value={userMsg}
                        onChange={(e) => setUserMsg(e.target.value)}
                        className="flex-grow p-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right"
                      />
                      <button
                        type="submit"
                        disabled={aiLoading}
                        className="bg-primary hover:bg-slate-850 text-white p-2.5 rounded-xl transition duration-150 shrink-0"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </form>
                  </div>

                </div>

              </div>

            </div>
          </div>
        )
      )}

      {/* KNOWLEDGE UPDATE MODAL FOR ADMIN */}
      {showKnowledgeModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-slate-900 select-none animate-fade-in text-right font-sans">
          <div className="bg-white rounded-3xl w-full max-w-lg border border-slate-150 overflow-hidden shadow-2xl animate-scale-up">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-l from-primary to-primary/80 text-white p-5 flex items-center justify-between">
              <h3 className="text-sm font-black flex items-center gap-1.5">
                <span>⚙️ لوحة تحديث بيانات المساعد الذكي</span>
              </h3>
              <button 
                onClick={() => {
                  setShowKnowledgeModal(false);
                  setKnowledgePassword("");
                  setIsKnowledgeAuthorized(false);
                  setKnowledgeErrorMsg("");
                  setKnowledgeSuccessMsg("");
                }} 
                className="text-white bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-lg text-xs font-bold transition duration-200 cursor-pointer"
              >
                ✖ إغلاق
              </button>
            </div>

            {/* Modal content */}
            {!isKnowledgeAuthorized ? (
              // Step 1: Input Password
              <div className="p-6 space-y-4">
                <p className="text-xs text-slate-500 font-bold leading-relaxed">
                  الرجاء إدخال كلمة المرور المعتمدة للإدارة لتتمكن من تحديث أو إضافة معلومات وقواعد المساعد الذكي الفورية:
                </p>

                {knowledgeErrorMsg && (
                  <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-[10.5px] text-rose-650 font-black leading-relaxed">
                    ⚠️ {knowledgeErrorMsg}
                  </div>
                )}

                <div className="space-y-1">
                  <label className="block text-[10.5px] font-bold text-slate-600">كلمة مرور الإدارة المعتمدة:</label>
                  <input
                    type="password"
                    placeholder="أدخل كلمة المرور هنا..."
                    value={knowledgePassword}
                    onChange={(e) => setKnowledgePassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-primary/50 focus:ring-1 focus:ring-primary/20 text-xs py-2.5 px-3 rounded-xl font-mono text-center tracking-widest text-slate-750"
                  />
                </div>

                <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowKnowledgeModal(false)}
                    className="bg-slate-100 text-slate-500 hover:bg-slate-200 font-extrabold px-4 py-2 rounded-xl text-xs transition duration-150 cursor-pointer"
                  >
                    إلغاء الأمر
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (knowledgePassword === "D@r573$E") {
                        setIsKnowledgeAuthorized(true);
                        setKnowledgeErrorMsg("");
                      } else {
                        setKnowledgeErrorMsg("كلمة المرور غير صحيحة! يرجى إعادة المحاولة بدقة.");
                      }
                    }}
                    className="bg-primary hover:bg-slate-850 text-white font-black px-5 py-2 rounded-xl text-xs transition duration-150 shadow-md cursor-pointer"
                  >
                    دخول وتحديث البيانات 🔓
                  </button>
                </div>
              </div>
            ) : (
              // Step 2: Edit Custom Knowledge
              <div className="p-6 space-y-4">
                <p className="text-xs text-slate-500 font-bold leading-relaxed">
                  أنتم مصرح لكم بتحديث معلومات وقواعد المساعد الآن. يتم استخدام هذه البيانات للردود الفورية للطلاب، أو يتم غرسها كمعرفة مخصصة إضافية لمساعد أمل:
                </p>

                <div className="p-3 bg-amber-50 border border-amber-200 text-amber-805 rounded-xl space-y-1 text-[10px] leading-relaxed">
                  <p className="font-bold">💡 طريقة الصياغة الفورية للردود:</p>
                  <p>اكتب في كل سطر الكلمات المفتاحية متبوعة بالرمز (|) ثم الرد الفوري، مثال:</p>
                  <p className="font-mono bg-white/75 p-1.5 rounded border border-amber-100">
                    دوام،وقت،ساعة | الدوام من 7:30ص إلى 1:00م
                  </p>
                  <p>أيضاً، أي سطر عادي بدون الرمز (|) سيتم تزويده للمساعد كمرجع دراسي عام للردود الذكية.</p>
                </div>

                {knowledgeSuccessMsg && (
                  <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-[10.5px] text-emerald-800 font-black leading-relaxed">
                    ✓ {knowledgeSuccessMsg}
                  </div>
                )}

                <div className="space-y-1">
                  <label className="block text-[10.5px] font-bold text-slate-600">صندوق بيانات وقواعد المساعد الذكي:</label>
                  <textarea
                    rows={8}
                    value={customKnowledgeRaw}
                    onChange={(e) => setCustomKnowledgeRaw(e.target.value)}
                    placeholder="اكتب المعرفة هنا..."
                    className="w-full bg-slate-50 border border-slate-205 focus:border-primary/50 focus:ring-1 focus:ring-primary/20 text-xs p-3 rounded-xl font-bold font-sans text-slate-720 leading-relaxed text-right"
                  />
                </div>

                <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setIsKnowledgeAuthorized(false);
                      setKnowledgePassword("");
                    }}
                    className="bg-slate-100 text-slate-500 hover:bg-slate-200 font-extrabold px-4 py-2 rounded-xl text-xs transition duration-150 cursor-pointer"
                  >
                    قفل الجلسة 🔒
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      localStorage.setItem("school_ai_custom_knowledge", customKnowledgeRaw);
                      setKnowledgeSuccessMsg("تم حفظ وربط البيانات وإرسالها للمساعد الذكي في الذاكرة بنجاح! ✓");
                      setTimeout(() => {
                        setKnowledgeSuccessMsg("");
                        setShowKnowledgeModal(false);
                        setIsKnowledgeAuthorized(false);
                        setKnowledgePassword("");
                        setChatMessages(prev => [
                          ...prev,
                          { role: "assistant" as const, content: "🔔 نظام: تم تحديث قاعدة بيانات معلوماتي المرجعية والردود الفورية بنجاح بواسطة إدارة المدرسة!" }
                        ]);
                      }, 1200);
                    }}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-black px-5 py-2 rounded-xl text-xs transition duration-150 shadow-md cursor-pointer"
                  >
                    حفظ وإرسال للتحديث 💾
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
