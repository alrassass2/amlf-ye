import React, { useState } from "react";
import { SchoolNews, RegistrationRequest, Student, Teacher, Announcement, Parent } from "../types";
import { initialNews, initialRegistrationRequests, initialStudents, initialTeachers, initialAnnouncements, initialParents, saveData, getSavedData, saveDataWithServerSync } from "../data";
import { Megaphone, FileText, Users, Plus, Trash2, Check, X, ShieldAlert, BadgeInfo, Lock, Calendar, Download, Upload, FileSpreadsheet, Edit, UserPlus, Image as ImageIcon, BookOpen, CreditCard } from "lucide-react";
import * as XLSX from "xlsx";

export default function AdminDashboard() {
  // Authentication state for administrative access
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem("amal_admin_logged") === "true";
  });
  const [adminUsername, setAdminUsername] = useState<string>("");
  const [adminPassword, setAdminPassword] = useState<string>("");
  const [authError, setAuthError] = useState<string>("");

  const [news, setNews] = useState<SchoolNews[]>(() =>
    getSavedData<SchoolNews[]>("school_news", initialNews)
  );

  const [requests, setRequests] = useState<RegistrationRequest[]>(() =>
    getSavedData<RegistrationRequest[]>("school_registration_requests", initialRegistrationRequests)
  );

  const [students, setStudents] = useState<Student[]>(() =>
    getSavedData<Student[]>("school_students", initialStudents)
  );

  const [announcements, setAnnouncements] = useState<Announcement[]>(() =>
    getSavedData<Announcement[]>("school_announcements", initialAnnouncements)
  );

  const [teachers, setTeachers] = useState<Teacher[]>(() =>
    getSavedData<Teacher[]>("school_teachers", initialTeachers)
  );

  const [parents, setParents] = useState<Parent[]>(() =>
    getSavedData<Parent[]>("school_parents", initialParents)
  );

  // Financial Control tab states
  const [editingParentId, setEditingParentId] = useState<string | null>(null);
  const [finTotalFees, setFinTotalFees] = useState<number>(0);
  const [finPaidFees, setFinPaidFees] = useState<number>(0);
  const [finSuccessMessage, setFinSuccessMessage] = useState<string>("");

  // Add Transaction states (on selected parent)
  const [txTitle, setTxTitle] = useState<string>("");
  const [txAmount, setTxAmount] = useState<number>(0);
  const [txDate, setTxDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [txStatus, setTxStatus] = useState<"مقبول" | "قيد الانتظار">("مقبول");

  // Active admin section tab: "applications" | "news" | "alerts" | "students" | "attendance" | "teachers"
  const [activeTab, setActiveTab] = useState<string>("applications");

  // Teacher management fields
  const [editingTeacherId, setEditingTeacherId] = useState<string | null>(null);
  const [teacherName, setTeacherName] = useState<string>("");
  const [teacherSubject, setTeacherSubject] = useState<string>("");
  const [teacherRole, setTeacherRole] = useState<string>("مدرس مادة");
  const [teacherPhone, setTeacherPhone] = useState<string>("");
  const [teacherEmail, setTeacherEmail] = useState<string>("");
  const [teacherClasses, setTeacherClasses] = useState<string>("");
  const [teacherImageUrl, setTeacherImageUrl] = useState<string>("");
  const [teacherBio, setTeacherBio] = useState<string>("");

  // News Publisher states
  const [newsTitle, setNewsTitle] = useState<string>("");
  const [newsContent, setNewsContent] = useState<string>("");
  const [newsCat, setNewsCat] = useState<"أخبار" | "إعلان" | "إنجاز" | "رحلة">("أخبار");
  const [newsImg, setNewsImg] = useState<string>("https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600");

  // Broadcast Alert states
  const [alertTitle, setAlertTitle] = useState<string>("");
  const [alertContent, setAlertContent] = useState<string>("");
  const [alertTarget, setAlertTarget] = useState<"all" | "students" | "teachers" | "parents">("all");

  // Attendance Excel parsing states
  const [attendanceSheetName, setAttendanceSheetName] = useState<string>(""); 
  const [selectedClassSheet, setSelectedClassSheet] = useState<string>("الصف الأول الابتدائي");
  const [attendanceData, setAttendanceData] = useState<any[] | null>(null);

  // States for interactive attendance data input form
  const [newAttName, setNewAttName] = useState<string>("");
  const [newAttCode, setNewAttCode] = useState<string>("");
  const [newAttPres9, setNewAttPres9] = useState<string>("22");
  const [newAttAbs9, setNewAttAbs9] = useState<string>("0");
  const [newAttExc9, setNewAttExc9] = useState<string>("0");
  const [newAttPres10, setNewAttPres10] = useState<string>("22");
  const [newAttAbs10, setNewAttAbs10] = useState<string>("0");
  const [newAttExc10, setNewAttExc10] = useState<string>("0");
  const [newAttPres11, setNewAttPres11] = useState<string>("20");
  const [newAttAbs11, setNewAttAbs11] = useState<string>("1");
  const [newAttExc11, setNewAttExc11] = useState<string>("1");
  const [submitMessage, setSubmitMessage] = useState<string>("");

  // States for forgot password
  const [showForgotForm, setShowForgotForm] = useState<boolean>(false);
  const [forgotEmail, setForgotEmail] = useState<string>("");
  const [forgotMessage, setForgotMessage] = useState<string>("");

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Enforcing target password D@r573$E
    if (adminPassword === "D@r573$E") {
      setIsAdminAuthenticated(true);
      sessionStorage.setItem("amal_admin_logged", "true");
      setAuthError("");
    } else {
      setAuthError("كلمة المرور السرية التي قمت بإدخالها للكنترول الموحد غير صحيحة!");
    }
  };

  const handleRequestPasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    const OFFICIAL_EMAIL = "amlf.yen@gmail.com";
    const SECRET_KEY = "D@r573$E";

    if (forgotEmail.trim().toLowerCase() === OFFICIAL_EMAIL) {
      const subject = encodeURIComponent("🔐 طلب استعادة كلمة مرور بوابة إدارة المدرسة - مدرسة أمل المستقبل");
      const body = encodeURIComponent(`مرحباً بكم الهيئة الإدارية الموقرة،\n\nلقد تلقينا طلباً لاستعادة كلمة المرور لولوج بوابة إدارة المدرسة لشؤون الطلاب والقبول.\n\nكلمة المرور الرسمية للقسم هي:\n${SECRET_KEY}\n\nيرجى استخدامها بأمان وتأمين حسابات الإدارة.\n\nتمنياتنا لكم بالتوفيق.`);
      
      setForgotMessage("تم التحقق من البريد المعتمد وجاري توجيهكم لإرسال كلمة المرور السريّة إلى صندوق بريد الإدارة amlf.yen@gmail.com...");
      setAuthError("");
      
      window.location.href = `mailto:${OFFICIAL_EMAIL}?subject=${subject}&body=${body}`;
      
      setTimeout(() => {
        setForgotMessage("");
        setShowForgotForm(false);
        setForgotEmail("");
      }, 7000);
    } else {
      setAuthError("عذراً، هذا البريد الإلكتروني غير مسجل كبريد رسمي للإدارة المدرسية المعتمدة! يرجى كتابة amlf.yen@gmail.com");
    }
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem("amal_admin_logged");
  };

  const handleCreateNews = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsTitle.trim() || !newsContent.trim()) return;

    const newArticle: SchoolNews = {
      id: "news-" + (news.length + 101),
      title: newsTitle.trim(),
      content: newsContent.trim(),
      category: newsCat,
      date: new Date().toISOString().split("T")[0],
      imageUrl: newsImg
    };

    const updated = [newArticle, ...news];
    setNews(updated);
    saveDataWithServerSync("school_news", updated);

    setNewsTitle("");
    setNewsContent("");
  };

  // Financial Control system handlers
  const handleStartEditParentFinancialObj = (parent: Parent) => {
    setEditingParentId(parent.id);
    setFinTotalFees(parent.financials.totalFees);
    setFinPaidFees(parent.financials.paidFees);
    setFinSuccessMessage("");
  };

  const handleSaveParentFinancialObj = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingParentId) return;

    const updated = parents.map(p => {
      if (p.id === editingParentId) {
        const remaining = finTotalFees - finPaidFees;
        return {
          ...p,
          financials: {
            ...p.financials,
            totalFees: finTotalFees,
            paidFees: finPaidFees,
            remainingFees: remaining >= 0 ? remaining : 0
          }
        };
      }
      return p;
    });

    setParents(updated);
    saveDataWithServerSync("school_parents", updated);
    setFinSuccessMessage("✓ تم تحديث المبالغ المالية للحساب الأكاديمي بنجاح.");
    setEditingParentId(null);
    setTimeout(() => setFinSuccessMessage(""), 4000);
  };

  const handleCreateTransactionObj = (e: React.FormEvent, parentId: string) => {
    e.preventDefault();
    if (!txTitle.trim() || txAmount <= 0) {
      alert("يرجى إدخال مسمى العملية (مثل: قسط شهر 1) ومبلغ صحيح.");
      return;
    }

    const updated = parents.map(p => {
      if (p.id === parentId) {
        const newTx = {
          id: "tx-manual-" + Date.now(),
          amount: txAmount,
          date: txDate,
          title: txTitle.trim(),
          status: txStatus
        };
        const updatedTxs = [...p.financials.transactions, newTx];
        
        // Sum up total paid from accepted transactions
        const totalPaid = updatedTxs
          .filter(t => t.status === "مقبول")
          .reduce((sum, current) => sum + current.amount, 0);

        const remaining = p.financials.totalFees - totalPaid;

        return {
          ...p,
          financials: {
            ...p.financials,
            paidFees: totalPaid,
            remainingFees: remaining >= 0 ? remaining : 0,
            transactions: updatedTxs
          }
        };
      }
      return p;
    });

    setParents(updated);
    saveDataWithServerSync("school_parents", updated);
    
    // Reset Form Fields
    setTxTitle("");
    setTxAmount(0);
    setFinSuccessMessage("✓ تم تسجيل العملية المالية الجديدة وإعادة حساب الميزانية المتبقية آلياً.");
    setTimeout(() => setFinSuccessMessage(""), 4500);
  };

  const handleDeleteTransactionObj = (parentId: string, txId: string) => {
    if (window.confirm("هل أنت متأكد تماماً من حذف هذه الخانة/المعاملة المالية نهائياً وإعادة تسوية حساب الطالب؟")) {
      const updated = parents.map(p => {
        if (p.id === parentId) {
          const updatedTxs = p.financials.transactions.filter(t => t.id !== txId);
          
          // Recompute paid
          const totalPaid = updatedTxs
            .filter(t => t.status === "مقبول")
            .reduce((sum, current) => sum + current.amount, 0);

          const remaining = p.financials.totalFees - totalPaid;

          return {
            ...p,
            financials: {
              ...p.financials,
              paidFees: totalPaid,
              remainingFees: remaining >= 0 ? remaining : 0,
              transactions: updatedTxs
            }
          };
        }
        return p;
      });

      setParents(updated);
      saveDataWithServerSync("school_parents", updated);
      setFinSuccessMessage("✓ تم حذف الخانة المالية المطلوبة وإعادة تسوية ميزانية الطالب بنجاح.");
      setTimeout(() => setFinSuccessMessage(""), 4000);
    }
  };

  const handleToggleTransactionStatusObj = (parentId: string, txId: string) => {
    const updated = parents.map(p => {
      if (p.id === parentId) {
        const updatedTxs = p.financials.transactions.map(t => {
          if (t.id === txId) {
            return {
              ...t,
              status: t.status === "مقبول" ? "قيد الانتظار" : "مقبول" as any
            };
          }
          return t;
        });

        const totalPaid = updatedTxs
          .filter(t => t.status === "مقبول")
          .reduce((sum, current) => sum + current.amount, 0);

        const remaining = p.financials.totalFees - totalPaid;

        return {
          ...p,
          financials: {
            ...p.financials,
            paidFees: totalPaid,
            remainingFees: remaining >= 0 ? remaining : 0,
            transactions: updatedTxs
          }
        };
      }
      return p;
    });

    setParents(updated);
    saveDataWithServerSync("school_parents", updated);
    setFinSuccessMessage("✓ تم تغيير حالة السداد وإعادة تسوية الميزانية آلياً.");
    setTimeout(() => setFinSuccessMessage(""), 4000);
  };

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!alertTitle.trim() || !alertContent.trim()) return;

    const newAlert: Announcement = {
      id: "ann-" + (announcements.length + 101),
      title: alertTitle.trim(),
      content: alertContent.trim(),
      target: alertTarget,
      date: new Date().toISOString().split("T")[0]
    };

    const updated = [newAlert, ...announcements];
    setAnnouncements(updated);
    saveDataWithServerSync("school_announcements", updated);

    setAlertTitle("");
    setAlertContent("");
  };

  const deleteNews = (id: string) => {
    const updated = news.filter(n => n.id !== id);
    setNews(updated);
    saveDataWithServerSync("school_news", updated);
  };

  const deleteAlert = (id: string) => {
    const updated = announcements.filter(a => a.id !== id);
    setAnnouncements(updated);
    saveDataWithServerSync("school_announcements", updated);
  };

  // 🧑‍🏫 Teacher CRUD Management Functions
  const handleSaveTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teacherName.trim() || !teacherSubject.trim()) return;

    const classesArray = teacherClasses.split(",").map(c => c.trim()).filter(Boolean);

    if (editingTeacherId) {
      // Update
      const updated = teachers.map(t => {
        if (t.id === editingTeacherId) {
          return {
            ...t,
            name: teacherName.trim(),
            subject: teacherSubject.trim(),
            role: teacherRole.trim(),
            phone: teacherPhone.trim(),
            email: teacherEmail.trim(),
            classes: classesArray.length > 0 ? classesArray : t.classes,
            imageUrl: teacherImageUrl.trim() || undefined,
            bio: teacherBio.trim() || undefined
          };
        }
        return t;
      });
      setTeachers(updated);
      saveDataWithServerSync("school_teachers", updated);
      setEditingTeacherId(null);
    } else {
      // Create
      const newTeacher: Teacher = {
        id: "teach-" + (teachers.length + 101),
        name: teacherName.trim(),
        subject: teacherSubject.trim(),
        role: teacherRole.trim(),
        phone: teacherPhone.trim(),
        classes: classesArray.length > 0 ? classesArray : ["الصف الأول الابتدائي"],
        grades: classesArray.length > 0 ? classesArray : ["الصف الأول الابتدائي"],
        email: teacherEmail.trim() || `${Date.now()}@amal.edu.ye`,
        academicId: "ACAD" + (teachers.length + 9000),
        imageUrl: teacherImageUrl.trim() || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=300",
        bio: teacherBio.trim() || "معلم متميز من ذوي الخبرة والالتزام الأكاديمي والتربوي.",
        lessons: [],
        assignments: []
      };
      const updated = [...teachers, newTeacher];
      setTeachers(updated);
      saveDataWithServerSync("school_teachers", updated);
    }

    // Reset inputs
    setTeacherName("");
    setTeacherSubject("");
    setTeacherRole("مدرس مادة");
    setTeacherPhone("");
    setTeacherEmail("");
    setTeacherClasses("");
    setTeacherImageUrl("");
    setTeacherBio("");
  };

  const handleEditTeacherClick = (t: Teacher) => {
    setEditingTeacherId(t.id);
    setTeacherName(t.name);
    setTeacherSubject(t.subject);
    setTeacherRole(t.role);
    setTeacherPhone(t.phone);
    setTeacherEmail(t.email);
    setTeacherClasses(t.classes.join(", "));
    setTeacherImageUrl(t.imageUrl || "");
    setTeacherBio(t.bio || "");
  };

  const handleDeleteTeacher = (id: string) => {
    const updated = teachers.filter(t => t.id !== id);
    setTeachers(updated);
    saveDataWithServerSync("school_teachers", updated);
  };

  // Helper to get correct ID prefix based on the grade's academic level/year
  const getGradeIdPrefix = (gradeName: string): number => {
    if (gradeName.includes("تمهيدي") || gradeName.includes("الروضة")) return 50;
    if (gradeName.includes("الأول الابتدائي") || gradeName.includes("الأول الأساسي")) return 100;
    if (gradeName.includes("الثاني الابتدائي") || gradeName.includes("الثاني الأساسي")) return 200;
    if (gradeName.includes("الثالث الابتدائي") || gradeName.includes("الثالث الأساسي")) return 300;
    if (gradeName.includes("الرابع الابتدائي") || gradeName.includes("الرابع الأساسي")) return 400;
    if (gradeName.includes("الخامس الابتدائي") || gradeName.includes("الخامس الأساسي")) return 500;
    if (gradeName.includes("السادس الابتدائي") || gradeName.includes("السادس الأساسي")) return 600;
    if (gradeName.includes("الأول الإعدادي")) return 700;
    if (gradeName.includes("الثاني الإعدادي")) return 800;
    if (gradeName.includes("الثالث الإعدادي")) return 900;
    if (gradeName.includes("الأول الثانوي")) return 1000;
    if (gradeName.includes("الثاني الثانوي العلمي") || gradeName === "الصف الثاني الثانوي (علمي)") return 1100;
    if (gradeName.includes("الثاني الثانوي الأدبي") || gradeName === "الصف الثاني الثانوي (أدبي)") return 1200;
    if (gradeName.includes("الثالث الثانوي العلمي") || gradeName.includes("ثالث ثانوي علمي")) return 1300;
    if (gradeName.includes("الثالث الثانوي الأدبي") || gradeName.includes("ثالث ثانوي أدبي")) return 1400;
    return 1500; // default range
  };

  const getNextIdForGrade = (gradeName: string): string => {
    const prefix = getGradeIdPrefix(gradeName);
    const gradeStudents = students.filter(s => s.grade === gradeName);
    const idsInThisGrade = gradeStudents.map(s => parseInt(s.id)).filter(id => !isNaN(id) && id >= prefix && id < prefix + 100);

    const cached = (window as any)._amal_cached_sheets;
    if (cached && cached[gradeName]) {
      cached[gradeName].forEach((row: any) => {
        const rowId = parseInt(row["كود الطالب"] || row.id);
        if (!isNaN(rowId) && rowId >= prefix && rowId < prefix + 100) {
          idsInThisGrade.push(rowId);
        }
      });
    }

    if (idsInThisGrade.length > 0) {
      return String(Math.max(...idsInThisGrade) + 1);
    }
    return String(prefix + 1); // starts from e.g. 101, 201, 1301
  };

  const handleUpdateApplicationStatus = (id: string, newStatus: "approved" | "rejected") => {
    const updated = requests.map(req => {
      if (req.id === id) {
        return {
          ...req,
          status: newStatus
        };
      }
      return req;
    });

    setRequests(updated);
    saveDataWithServerSync("school_registration_requests", updated);

    // If approved, let's auto-generate a new Student account in the database with custom prefix-based id!
    if (newStatus === "approved") {
      const targetReq = requests.find(r => r.id === id);
      if (targetReq) {
        const studentId = getNextIdForGrade(targetReq.grade || "الصف الأول الابتدائي");
        const newStudent: Student = {
          id: studentId,
          name: targetReq.studentName,
          grade: targetReq.grade || "الصف الأول الابتدائي",
          level: targetReq.level || "elementary",
          attendance: {
            present: 0,
            absent: 0,
            excused: 0,
            history: []
          },
          grades: [
            { subject: "اللغة العربية", midterm: 0, final: 0, homework: 0, total: 0, grade: "قيد التسجيل" },
            { subject: "الرياضيات", midterm: 0, final: 0, homework: 0, total: 0, grade: "قيد التسجيل" },
            { subject: "العلوم والدرس العام", midterm: 0, final: 0, homework: 0, total: 0, grade: "قيد التسجيل" }
          ],
          assignments: [],
          parentId: "parent-" + (students.length + 101)
        };

        const updatedStudents = [...students, newStudent];
        setStudents(updatedStudents);
        saveDataWithServerSync("school_students", updatedStudents);
      }
    }
  };

  // Download comprehensive attendance spreadsheets compiled with multiple tabs
  const downloadAttendanceTemplate = () => {
    const worksheetData = students.map((s) => ({
      "كود الطالب": s.id,
      "اسم الطالب رباعياً": s.name,
      "الصف الدراسي": s.grade,
      "حضور لشهر 9": 20,
      "غياب لشهر 9": 2,
      "استئذان لشهر 9": 1,
      "حضور لشهر 10": 22,
      "غياب لشهر 10": 0,
      "استئذان لشهر 10": 0,
      "حضور لشهر 11": 21,
      "غياب لشهر 11": 1,
      "استئذان لشهر 11": 0,
      "إجمالي حضور الفصل الأول": 63,
      "إجمالي غياب الفصل الأول": 3,
      "إجمالي استئذان الفصل الأول": 1,
      "إجمالي حضور الفصل الثاني": 65,
      "إجمالي غياب الفصل الثاني": 2,
      "إجمالي استئذان الفصل الثاني": 0,
      "الإجمالي السنوي للحضور": 128,
      "الإجمالي السنوي للغياب": 5,
      "الإجمالي السنوي للاستئذان": 1,
    }));

    const workbook = XLSX.utils.book_new();

    // The complete 14 grades of the school (Primary, Preparatory/Intermediate, and Secondary)
    const gradesList = [
      "الصف الأول الابتدائي",
      "الصف الثاني الابتدائي",
      "الصف الثالث الابتدائي",
      "الصف الرابع الابتدائي",
      "الصف الخامس الابتدائي",
      "الصف السادس الابتدائي",
      "الصف الأول الإعدادي",
      "الصف الثاني الإعدادي",
      "الصف الثالث الإعدادي",
      "الصف الأول الثانوي",
      "الصف الثاني الثانوي العلمي",
      "الصف الثاني الثانوي الأدبي",
      "الصف الثالث الثانوي العلمي",
      "الصف الثالث الثانوي الأدبي"
    ];

    gradesList.forEach((gradeName) => {
      const filtered = worksheetData.filter((row) => row["الصف الدراسي"] === gradeName);
      
      // Compute correct ID fallback for empty sheet
      const startId = String(getGradeIdPrefix(gradeName) + 1);
      
      const sheetRows = filtered.length > 0 ? filtered : [
        {
          "كود الطالب": startId,
          "اسم الطالب رباعياً": "طالب افتراضي لتفعيل الجدول",
          "الصف الدراسي": gradeName,
          "حضور لشهر 9": 22,
          "غياب لشهر 9": 0,
          "استئذان لشهر 9": 0,
          "حضور لشهر 10": 22,
          "غياب لشهر 10": 0,
          "استئذان لشهر 10": 0,
          "حضور لشهر 11": 20,
          "غياب لشهر 11": 1,
          "استئذان لشهر 11": 1,
          "إجمالي حضور الفصل الأول": 64,
          "إجمالي غياب الفصل الأول": 1,
          "إجمالي استئذان الفصل الأول": 1,
          "إجمالي حضور الفصل الثاني": 62,
          "إجمالي غياب الفصل الثاني": 2,
          "إجمالي استئذان الفصل الثاني": 0,
          "الإجمالي السنوي للحضور": 126,
          "الإجمالي السنوي للغياب": 3,
          "الإجمالي السنوي للاستئذان": 1,
        }
      ];

      const ws = XLSX.utils.json_to_sheet(sheetRows);
      XLSX.utils.book_append_sheet(workbook, ws, gradeName);
    });

    XLSX.writeFile(workbook, "دفتر_الحضور_الشامل_للفصول.xlsx");
  };

  // Handle parse of Multi-Tab Attendance Book
  const handleAttendanceUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAttendanceSheetName(file.name);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const raw = evt.target?.result;
        const workbook = XLSX.read(raw, { type: "binary" });

        // Compile and extract all sheets
        const allSheetsData: Record<string, any[]> = {};
        workbook.SheetNames.forEach((sheetName) => {
          const ws = workbook.Sheets[sheetName];
          allSheetsData[sheetName] = XLSX.utils.sheet_to_json<any>(ws);
        });

        // Initialize view with the sheets
        if (workbook.SheetNames.length > 0) {
          const firstSheet = workbook.SheetNames[0];
          setSelectedClassSheet(firstSheet);
          setAttendanceData(allSheetsData[selectedClassSheet] || allSheetsData[firstSheet]);
          // Temporarily cache global dictionary to let users switch tabs smoothly
          (window as any)._amal_cached_sheets = allSheetsData;
        }
      } catch (err) {
        alert("فشل قراءة شيت الحضور، تأكد من مطابقة الملف الملحق.");
      }
    };
    reader.readAsBinaryString(file);
  };

  // Switch between loaded class sheets
  const handleSwitchClassSheet = (sheetName: string) => {
    setSelectedClassSheet(sheetName);
    const cached = (window as any)._amal_cached_sheets;
    if (cached && cached[sheetName]) {
      setAttendanceData(cached[sheetName]);
    }
  };

  const handleAddAttendanceRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAttName.trim()) {
      setSubmitMessage("يرجى إدخال اسم الطالب أولاً.");
      return;
    }

    const finalCode = newAttCode.trim() || getNextIdForGrade(selectedClassSheet);

    // Number conversions
    const p9 = parseInt(newAttPres9) || 0;
    const a9 = parseInt(newAttAbs9) || 0;
    const e9 = parseInt(newAttExc9) || 0;

    const p10 = parseInt(newAttPres10) || 0;
    const a10 = parseInt(newAttAbs10) || 0;
    const e10 = parseInt(newAttExc10) || 0;

    const p11 = parseInt(newAttPres11) || 0;
    const a11 = parseInt(newAttAbs11) || 0;
    const e11 = parseInt(newAttExc11) || 0;

    // Calculate aggregations
    const tH1 = p9 + p10 + p11;
    const tG1 = a9 + a10 + a11;
    const tE1 = e9 + e10 + e11;

    const tH2 = tH1; // simple term 2 projections
    const tG2 = tG1;
    const tE2 = tE1;

    const yH = tH1 + tH2;
    const yG = tG1 + tG2;
    const yE = tE1 + tE2;

    const newRecord: any = {
      "كود الطالب": finalCode,
      "اسم الطالب رباعياً": newAttName.trim(),
      "الصف الدراسي": selectedClassSheet,
      "حضور لشهر 9": p9,
      "غياب لشهر 9": a9,
      "استئذان لشهر 9": e9,
      "حضور لشهر 10": p10,
      "غياب لشهر 10": a10,
      "استئذان لشهر 10": e10,
      "حضور لشهر 11": p11,
      "غياب لشهر 11": a11,
      "استئذان لشهر 11": e11,
      "إجمالي حضور الفصل الأول": tH1,
      "إجمالي غياب الفصل الأول": tG1,
      "إجمالي استئذان الفصل الأول": tE1,
      "إجمالي حضور الفصل الثاني": tH2,
      "إجمالي غياب الفصل الثاني": tG2,
      "إجمالي استئذان الفصل الثاني": tE2,
      "الإجمالي السنوي للحضور": yH,
      "الإجمالي السنوي للغياب": yG,
      "الإجمالي السنوي للاستئذان": yE,
    };

    if (!(window as any)._amal_cached_sheets) {
      (window as any)._amal_cached_sheets = {};
    }

    const currentRows = (window as any)._amal_cached_sheets[selectedClassSheet] || [];
    const existingIndex = currentRows.findIndex(
      (row: any) => String(row["كود الطالب"] || row.id) === String(finalCode)
    );

    let updatedRows = [...currentRows];
    if (existingIndex > -1) {
      updatedRows[existingIndex] = { ...updatedRows[existingIndex], ...newRecord };
      setSubmitMessage(`✓ تم تحديث بيانات الطالب كود ${finalCode} بنجاح`);
    } else {
      updatedRows.push(newRecord);
      setSubmitMessage(`✓ تم إضافة الطالب بنجاح بكود الحضور: ${finalCode}`);
    }

    (window as any)._amal_cached_sheets[selectedClassSheet] = updatedRows;
    setAttendanceData(updatedRows);

    // Sync with student registry
    const matchingStudent = students.find((s) => String(s.id) === String(finalCode));
    if (matchingStudent) {
      const updatedStudents = students.map((s) => {
        if (String(s.id) === String(finalCode)) {
          return {
            ...s,
            attendance: {
              present: yH,
              absent: yG,
              excused: yE,
              history: s.attendance.history || []
            }
          };
        }
        return s;
      });
      setStudents(updatedStudents);
      saveDataWithServerSync("school_students", updatedStudents);
    } else {
      const newStudent: Student = {
        id: finalCode,
        name: newAttName.trim(),
        grade: selectedClassSheet,
        level: selectedClassSheet.includes("الابتدائي") ? "elementary" : selectedClassSheet.includes("الإعدادي") ? "prep" : "secondary",
        attendance: {
          present: yH,
          absent: yG,
          excused: yE,
          history: []
        },
        grades: [
          { subject: "اللغة العربية", midterm: 88, final: 92, homework: 10, total: 96, grade: "ممتاز" },
          { subject: "الرياضيات", midterm: 85, final: 87, homework: 9, total: 93, grade: "ممتاز" },
          { subject: "العلوم", midterm: 82, final: 86, homework: 10, total: 92, grade: "ممتاز" }
        ],
        assignments: [],
        parentId: "parent-" + (students.length + 101)
      };
      const updatedStudents = [...students, newStudent];
      setStudents(updatedStudents);
      saveDataWithServerSync("school_students", updatedStudents);
    }

    // Reset name/code fields
    setNewAttName("");
    setNewAttCode("");

    setTimeout(() => {
      setSubmitMessage("");
    }, 4500);
  };

  // If administration is not logged in, show the login gate!
  if (!isAdminAuthenticated) {
    return (
      <div id="admin-auth-login-view" className="max-w-md mx-auto py-16 px-4 text-right space-y-8">
        <div className="text-center space-y-3">
          <div className="w-16 h-16 bg-slate-100 text-slate-800 rounded-2xl flex items-center justify-center mx-auto border-2 border-dashed border-slate-200">
            <Lock className="w-6 h-6 animate-pulse" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 font-display">بوابة دخول إدارة المدرسة</h1>
          <p className="text-slate-500 text-xs">
            يرجى إدخال المقومات والاعتمادات السرية الرسمية لفتح وتعديل جداول وبيانات مدرسة أمل المستقبل الأهلية.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl space-y-4">
          {!showForgotForm ? (
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">اسم مستخدم الإدارة:</label>
                <input
                  type="text"
                  required
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  placeholder="أدخل اسم مستخدم الإدارة (مثال: admin)"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-slate-400 text-right"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">كلمة المرور السرية:</label>
                <input
                  type="password"
                  required
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="أدخل كلمة المرور السرية الخاصة بالإدارة..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-slate-400 text-right"
                />
              </div>

              {authError && (
                <p className="text-[11px] text-rose-650 font-bold bg-rose-50 p-2.5 rounded-lg border border-rose-100 text-right">
                  ⚠️ {authError}
                </p>
              )}

              <button
                type="submit"
                className="w-full bg-slate-900 hover:bg-slate-850 text-white font-bold py-3 rounded-xl text-xs transition shadow-md cursor-pointer"
              >
                تسجيل الدخول الآمين
              </button>

              <div className="text-center pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotForm(true);
                    setAuthError("");
                    setForgotMessage("");
                  }}
                  className="text-xs text-rose-600 font-extrabold hover:underline"
                >
                  نسيت كلمة المرور؟ 🔑
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRequestPasswordReset} className="space-y-4">
              <h3 className="text-xs font-black text-slate-800 border-b pb-2">🔐 استرداد وتأكيد هوية إدارة المدرسة</h3>
              <p className="text-xs text-slate-500 leading-relaxed text-right">
                لاستلام رمز المرور السري، يرجى إدخال البريد الإلكتروني الرسمي للإدارة المدرسية الموقرة ليتم توجيهكم لتلقيه فوراً:
              </p>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 block">البريد الإلكتروني للإدارة المدرسية:</label>
                <input
                  type="email"
                  required
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="amlf.yen@gmail.com..."
                  dir="ltr"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-slate-450 text-left font-semibold"
                />
              </div>

              {authError && (
                <p className="text-[11px] text-rose-650 font-bold bg-rose-50 p-2.5 rounded-lg border border-rose-100 text-right">
                  ⚠️ {authError}
                </p>
              )}

              {forgotMessage && (
                <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl text-[10.5px] text-indigo-900 font-extrabold leading-relaxed text-right">
                  {forgotMessage}
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-[#00a651] hover:bg-emerald-700 text-white font-bold py-3 rounded-xl text-xs transition shadow-md cursor-pointer"
              >
                استرداد وإرسال الكود 📬
              </button>

              <div className="text-center pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotForm(false);
                    setAuthError("");
                    setForgotMessage("");
                  }}
                  className="text-xs text-slate-500 font-extrabold hover:underline"
                >
                  الرجوع لتسجيل الدخول ⬅
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div id="admin-dashboard-section" className="space-y-12 pb-12 text-right">
      
      {/* Header with Logout option */}
      <div className="relative text-center space-y-4 max-w-2xl mx-auto">
        <button
          onClick={handleAdminLogout}
          className="absolute left-0 top-0 bg-slate-50 border border-slate-200 text-slate-600 hover:text-rose-600 hover:bg-rose-50 font-bold px-3 py-1.5 rounded-lg text-[10px] transition"
          title="خروج آمن"
        >
          تسجيل الخروج
        </button>

        <span className="bg-rose-100 text-rose-800 text-xs font-bold px-4 py-1.5 rounded-full border border-rose-200 uppercase tracking-widest">
          أمل المستقبل الإداري الشامل
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 font-display">
          لوحة الإدارة والتحكم في شؤون المدرسة والقبول والمستندات
        </h1>
        <p className="text-slate-500 text-sm">
          مرحباً بك مدير المقر التعليمي في لوحة شؤون طلاب مدرسة أمل المستقبل. تحكم بالطلبات، وتابع الغياب والحضور السنوي والموسمي المربوط بشيتات الإكسل بكفاءة.
        </p>
      </div>

      {/* Admin Horizontal Tabs Controls */}
      <div className="flex flex-wrap items-center gap-3 justify-center border-b border-slate-100 pb-6">
        {[
          { id: "applications", label: "طلبات الالتحاق والقبول", icon: FileText, count: requests.filter(r => r.status === "pending").length },
          { id: "news", label: "إدارة الأخبار واللقطات", icon: FileText, count: news.length },
          { id: "alerts", label: "بث التعاميم والإعلانات", icon: Megaphone, count: announcements.length },
          { id: "students", label: "سجل الطلاب والمقيدين", icon: Users, count: students.length },
          { id: "teachers", label: "إدارة الكادر التعليمي والتربوي 🧑‍🏫", icon: Users, count: teachers.length },
          { id: "financials", label: "الحسابات والتحكم المالي 💰", icon: CreditCard, count: 0 },
          { id: "attendance", label: "دفتر حضور وغياب الشيت الحساس (Excel)", icon: Calendar, count: 0 }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4.5 py-3 rounded-xl text-xs font-extrabold transition-all duration-200 font-display flex items-center gap-2 ${
              activeTab === tab.id
                ? "bg-primary text-white shadow-md border-transparent scale-[1.01]"
                : "bg-white text-slate-750 border border-slate-105 hover:bg-slate-50 hover:text-primary"
            }`}
          >
            <tab.icon className="w-4 h-4 shrink-0" />
            <span>{tab.label}</span>
            {tab.count > 0 && <span className="bg-rose-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold leading-none">{tab.count}</span>}
          </button>
        ))}
      </div>

      {/* RENDER ACTIVE TABS MODULE */}
      <div className="grid lg:grid-cols-12 gap-8 items-start">
        
        {/* TAB 1: APPLICATIONS & ENROLLMENTS QUEUE */}
        {activeTab === "applications" && (
          <div className="lg:col-span-12 space-y-6">
            <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm space-y-6">
              <h3 className="font-bold text-lg text-slate-805 font-display justify-start">طلبات القبول والتسجيل المنظورة</h3>
              
              <div className="space-y-4">
                {requests.map((item) => (
                  <div key={item.id} className="p-5 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col md:flex-row justify-between gap-4 text-xs font-semibold">
                    <div className="space-y-2 text-right">
                      <div className="flex items-center gap-2 justify-start flex-wrap">
                        <strong className="text-sm text-slate-850">{item.studentName}</strong>
                        <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded border border-indigo-100">الصف المستحق: {item.grade}</span>
                        <span className="text-[10px] text-slate-400 font-mono">المرجع: {item.id} | تاريخ: {item.createdAt}</span>
                      </div>
                      
                      <div className="grid sm:grid-cols-2 gap-x-6 gap-y-1 text-slate-500 text-[11px]">
                        <p><span className="text-slate-400">ولي الأمر:</span> {item.parentName}</p>
                        <p><span className="text-slate-400">البريد الإلكتروني:</span> {item.email}</p>
                        <p><span className="text-slate-400">الهاتف:</span> {item.phone}</p>
                        <p><span className="text-slate-400">المستندات لرفعها:</span> {Object.entries(item.documents).filter(([_, val]) => val).map(([key]) => key === "idCard" ? "الهوية" : key === "birthCert" ? "الميلاد" : "الشهادة السابقة").join("، ") || "لا يوجد"}</p>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2 justify-end pt-2 md:pt-0">
                      {item.status === "pending" ? (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleUpdateApplicationStatus(item.id, "approved")}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center gap-1 shadow-sm transition"
                          >
                            <Check className="w-4 h-4" />
                            <span>قبول وتوليد حساب</span>
                          </button>
                          
                          <button
                            onClick={() => handleUpdateApplicationStatus(item.id, "rejected")}
                            className="bg-rose-50 font-bold border border-rose-100 text-rose-700 hover:bg-rose-100 py-2 px-4 rounded-xl text-xs flex items-center gap-1 transition"
                          >
                            <X className="w-4 h-4" />
                            <span>رفض وإلغاء الطلب</span>
                          </button>
                        </div>
                      ) : (
                        <span className={`text-xs font-bold px-3 py-1.5 rounded-full ${
                          item.status === "approved" ? "bg-emerald-50 text-emerald-800" : "bg-rose-50 text-rose-800"
                        }`}>{item.status === "approved" ? "✓ تم القبول وتوليد الحساب الأكاديمي" : "✘ تم الرفض وتجميد الملف"}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PORTAL NEWS ARTICLES */}
        {activeTab === "news" && (
          <>
            {/* Create news article */}
            <div className="lg:col-span-4 bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
              <h4 className="font-bold text-slate-805 font-display text-sm pb-1 border-b border-slate-50 flex items-center gap-1">
                <Plus className="w-5 h-5 text-primary animate-pulse" />
                <span>إضافة خبر/تحدي جديد</span>
              </h4>

              <form onSubmit={handleCreateNews} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-600 font-bold">مكان وعنوان الخبر:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: بطولة الرماية المدرسية..."
                    value={newsTitle}
                    onChange={(e) => setNewsTitle(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-right"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-600 font-bold">المنشور والمقالة بالتفصيل:</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="اكتب تفاصيل الإنجاز أو التعميم المالي أو تفاصيل الحفل..."
                    value={newsContent}
                    onChange={(e) => setNewsContent(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-205 rounded-lg text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-600 font-bold">تصنيف القائمة:</label>
                  <select
                    value={newsCat}
                    onChange={(e) => setNewsCat(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="أخبار">خبر عام</option>
                    <option value="إعلان">إعلان رسمي</option>
                    <option value="إنجاز">تكريم وإنجاز</option>
                    <option value="رحلة">رحلات ترفيهية</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 rounded-xl text-xs transition"
                >
                  نشر الآن بالمدونة الرسمية
                </button>
              </form>
            </div>

            {/* List current news and allow deleting */}
            <div className="lg:col-span-8 bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-4">
              <h3 className="font-bold text-md text-slate-800 font-display">إدارة المواد المنشورة بالمدونة</h3>
              
              <div className="space-y-3">
                {news.map((item) => (
                  <div key={item.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs font-semibold">
                    <div className="text-right space-y-1 max-w-[80%]">
                      <h4 className="font-bold text-slate-800 line-clamp-1">{item.title}</h4>
                      <p className="text-[10px] text-slate-400">التصنيف: {item.category} | تاريخ: {item.date}</p>
                    </div>
                    
                    <button
                      onClick={() => deleteNews(item.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg hover:text-rose-700 transition"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* TAB 3: ALERTS & ANNOUNCEMENTS */}
        {activeTab === "alerts" && (
          <>
            {/* Create alert */}
            <div className="lg:col-span-4 bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
              <h4 className="font-bold text-slate-805 font-display text-sm pb-1 border-b border-slate-55 flex items-center gap-1">
                <Plus className="w-5 h-5 text-accent animate-pulse" />
                <span>تعميم إداري جديد</span>
              </h4>

              <form onSubmit={handleCreateAlert} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-600 font-bold">عنوان التعميم:</label>
                  <input
                    type="text"
                    required
                    placeholder="تأجيل اللقاء، تعديل جداول الاختبارات..."
                    value={alertTitle}
                    onChange={(e) => setAlertTitle(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-600 font-bold">تفاصيل المحتوى المقرة:</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="اكتبي نص الإشعار بالتفصيل لولي الأمر..."
                    value={alertContent}
                    onChange={(e) => setAlertContent(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-205 rounded-lg text-xs"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-600 font-bold">المتلقون المستهدفون:</label>
                  <select
                    value={alertTarget}
                    onChange={(e) => setAlertTarget(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="all">كافة الكوادر والطلاب</option>
                    <option value="students">الطلاب والمعلمون</option>
                    <option value="parents">أولياء الأمور فقط</option>
                    <option value="teachers">المعلمين فقط</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-primary hover:bg-slate-800 text-white font-bold py-2 rounded-xl text-xs transition"
                >
                  بث الإشعار وتثبيته فوراً 🔔
                </button>
              </form>
            </div>

            {/* List current alerts */}
            <div className="lg:col-span-8 bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-4">
              <h3 className="font-bold text-md text-slate-800 font-display">سجل ومستندات التعاميم المبثوثة</h3>
              
              <div className="space-y-3">
                {announcements.map((item) => (
                  <div key={item.id} className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs font-semibold">
                    <div className="text-right space-y-1 max-w-[80%]">
                      <h4 className="font-bold text-slate-800 leading-snug">{item.title}</h4>
                      <p className="text-[10px] text-slate-400 font-mono">الجهة: الإدارة المعنية | تاريخ: {item.date} | الفئة المستهدفة: {item.target === "parents" ? "أولياء الأمور" : "الكل"}</p>
                      <p className="text-[11px] text-slate-500 font-normal leading-relaxed">{item.content}</p>
                    </div>
                    
                    <button
                      onClick={() => deleteAlert(item.id)}
                      className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg hover:text-rose-750 transition shrink-0"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* TAB 4: STUDENTS DATABASE DIRECT SHEET */}
        {activeTab === "students" && (
          <div className="lg:col-span-12 space-y-6">
            <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm space-y-4">
              <h3 className="font-bold text-lg text-slate-800 font-display">سجل الطلاب والطالبات المقيدين للعام</h3>
              
              <div className="overflow-x-auto rounded-xl border border-slate-100">
                <table className="w-full text-right border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 text-slate-600 border-b border-slate-100 font-bold">
                      <th className="p-4">الرقم الأكاديمي</th>
                      <th className="p-4">اسم الطالب رباعياً</th>
                      <th className="p-4">الصف الدراسي الحالي</th>
                      <th className="p-4 text-center">عدد أيام الحضور</th>
                      <th className="p-4 text-center">أيام الغياب</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 text-slate-700">
                    {students.map((student) => (
                      <tr key={student.id} className="hover:bg-slate-50/70 transition">
                        <td className="p-4 font-bold font-mono text-primary">{student.id}</td>
                        <td className="p-4 font-semibold text-slate-800">{student.name}</td>
                        <td className="p-4 text-slate-505">{student.grade}</td>
                        <td className="p-4 text-center font-bold text-emerald-600">{student.attendance.present} يوم</td>
                        <td className="p-4 text-center font-bold text-rose-600">{student.attendance.absent} غيابات</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4.5: SCHOOL PORTFOLIOS & FINANCIAL CONTROL */}
        {activeTab === "financials" && (
          <div className="lg:col-span-12 space-y-6 animate-fade-in text-right">
            {finSuccessMessage && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl text-xs font-bold text-center">
                {finSuccessMessage}
              </div>
            )}

            {/* Quick Edit Balance Panel Form */}
            {editingParentId && (
              <div className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm max-w-lg mx-auto space-y-4">
                <h4 className="font-extrabold text-slate-800 font-display text-sm">✏️ تعديل وضبط الرسوم السنوية للحساب (الرمز: {editingParentId})</h4>
                <form onSubmit={handleSaveParentFinancialObj} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">إجمالي الرسوم الدراسية المعتمدة (ريال):</label>
                      <input
                        type="number"
                        min="0"
                        value={finTotalFees}
                        onChange={(e) => setFinTotalFees(Number(e.target.value))}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs font-mono"
                        required
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">الرسوم المدفوعة فعلياً (ريال):</label>
                      <input
                        type="number"
                        min="0"
                        value={finPaidFees}
                        onChange={(e) => setFinPaidFees(Number(e.target.value))}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs font-mono"
                        required
                      />
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-400">
                    تلقائياً، سيتم احتساب المتبقي بذمة ولي الأمر: <strong className="font-mono text-slate-800">{(finTotalFees - finPaidFees) >= 0 ? (finTotalFees - finPaidFees) : 0} ريال يمني</strong>.
                  </p>

                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 rounded-xl text-xs transition"
                    >
                      تأكيد الحفظ والتعديل
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingParentId(null)}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-2 px-4 rounded-xl text-xs transition"
                    >
                      إلغاء التعديل
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm space-y-6">
              <div className="border-b border-slate-100 pb-4 text-right">
                <h3 className="font-extrabold text-lg text-slate-900 font-display flex items-center gap-2 justify-start">
                  <CreditCard className="w-5 h-5 text-rose-600" />
                  <span>لوحة التحكم وتعديل الرسوم والذمم المالية للطلاب 💰</span>
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  من هنا يمكنك تعديل وحذف أي خانة، تجميد المعاملات، تعديل إجمالي الرسوم المترتبة، وإضافة وصولات السداد لطلاب المدرسة.
                </p>
              </div>

              {/* Parents Roster Card Renders */}
              <div className="grid md:grid-cols-2 gap-6">
                {parents.map((parent) => (
                  <div key={parent.id} className="p-5 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col justify-between gap-4">
                    <div className="space-y-4 text-right">
                      {/* Parent / Student Basic Metrics */}
                      <div className="flex justify-between items-start gap-2 border-b border-slate-200/60 pb-2">
                        <div>
                          <span className="text-[9px] bg-slate-200 text-slate-705 px-2 py-0.5 rounded font-bold font-mono">حساب: {parent.id}</span>
                          <h5 className="font-bold text-slate-900 text-xs mt-1">ولي الأمر: {parent.name}</h5>
                          <p className="text-[10px] text-indigo-700 font-bold mt-0.5">الهاتف: {parent.phone}</p>
                        </div>
                        <button
                          onClick={() => handleStartEditParentFinancialObj(parent)}
                          className="text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg transition"
                        >
                          ⚙️ تعديل الرسوم
                        </button>
                      </div>

                      {/* Fees metrics cards */}
                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="bg-slate-100/75 p-2 rounded-xl border border-slate-200/50">
                          <span className="text-[9px] text-slate-400 block font-semibold">المقرر كلياً</span>
                          <strong className="text-xs font-mono text-slate-800 font-black">{parent.financials.totalFees} ريال</strong>
                        </div>
                        <div className="bg-emerald-50/75 p-2 rounded-xl border border-emerald-100">
                          <span className="text-[9px] text-emerald-600 block font-semibold">المدفوع فعلياً</span>
                          <strong className="text-xs font-mono text-emerald-800 font-black">{parent.financials.paidFees} ريال</strong>
                        </div>
                        <div className="bg-rose-50/75 p-2 rounded-xl border border-rose-100">
                          <span className="text-[9px] text-rose-600 block font-semibold">المتبقي بذمتهم</span>
                          <strong className="text-xs font-mono text-rose-800 font-black">{parent.financials.remainingFees} ريال</strong>
                        </div>
                      </div>

                      {/* Transactions History list */}
                      <div className="space-y-2">
                        <span className="text-[10px] font-black text-slate-600 block">📊 كشف وبنود الحساب والوصولات:</span>
                        <div className="space-y-1.5 max-h-40 overflow-y-auto bg-white p-2.5 rounded-xl border border-slate-200 text-right">
                          {parent.financials.transactions && parent.financials.transactions.length > 0 ? (
                            parent.financials.transactions.map((tx) => (
                              <div key={tx.id} className="p-2 bg-slate-50 rounded-lg flex items-center justify-between text-[11px] border border-slate-100 hover:bg-slate-100/50">
                                <div className="space-y-0.5 text-right">
                                  <h6 className="font-bold text-slate-905 text-[10px]">{tx.title}</h6>
                                  <p className="text-[9px] text-slate-400 font-mono">تاريخ: {tx.date}</p>
                                </div>
                                <div className="flex items-center gap-2 shrink-0">
                                  <span className="font-extrabold text-slate-700 font-mono text-xs">{tx.amount} ريال</span>
                                  
                                  {/* Toggle status */}
                                  <button
                                    onClick={() => handleToggleTransactionStatusObj(parent.id, tx.id)}
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                      tx.status === "مقبول" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-805"
                                    }`}
                                    title="انقر لعكس حالة الدفع والقبول"
                                  >
                                    {tx.status}
                                  </button>

                                  {/* Delete Transaction */}
                                  <button
                                    onClick={() => handleDeleteTransactionObj(parent.id, tx.id)}
                                    className="p-1 text-rose-600 hover:bg-rose-50 rounded transition"
                                    title="حذف الخانة"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            ))
                          ) : (
                            <p className="text-[10px] text-center text-slate-400 py-4">لم تسجل عليه أي وصولات مالية بعد.</p>
                          )}
                        </div>
                      </div>

                      {/* Add Transaction form inline */}
                      <div className="bg-slate-100/40 p-3 rounded-xl border border-slate-200 text-right">
                        <span className="text-[10px] font-black text-slate-600 block mb-2">➕ تسجيل قسط / تجميل مالي يدوي:</span>
                        <form
                          onSubmit={(e) => {
                            handleCreateTransactionObj(e, parent.id);
                          }}
                          className="space-y-2"
                        >
                          <input
                            type="text"
                            placeholder="بيان الخانة (مثال: قسط التسجيل، رسوم الباص)"
                            required
                            className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
                            value={txTitle}
                            onChange={(e) => setTxTitle(e.target.value)}
                          />
                          <div className="grid grid-cols-2 gap-2">
                            <input
                              type="number"
                              min="0"
                              placeholder="مبلغ القسط"
                              required
                              className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-mono text-center"
                              value={txAmount || ""}
                              onChange={(e) => setTxAmount(Number(e.target.value))}
                            />
                            <select
                              className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold"
                              onChange={(e) => setTxStatus(e.target.value as any)}
                              value={txStatus}
                            >
                              <option value="مقبول">مقبول ومسدد</option>
                              <option value="قيد الانتظار">قيد الانتظار</option>
                            </select>
                          </div>
                          <button
                            type="submit"
                            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-black text-[10px] py-1.5 rounded-lg transition"
                          >
                            + إضافة الخانة المالية للحساب وتسويته
                          </button>
                        </form>
                      </div>

                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: MULTI-SHEET EXCEL ATTENDANCE PARSER SECTION */}
        {activeTab === "attendance" && (
          <div className="lg:col-span-12 space-y-6">
            <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm space-y-6">
              
              {/* Header section with Upload and Download options */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-100 pb-6 text-right">
                <div className="space-y-1">
                  <h3 className="font-bold text-lg text-slate-900 font-display flex items-center gap-1.5 justify-start">
                    <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                    <span>منظومة الحضور والغياب المستوردة من الإكسل </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    قم برفع شيت الحضور السنوي متعدد الصفحات (sheet لكل فصل) وجلب التقارير والمجاميع الشهرية والموسمية متضمنة الاستئذان تلقائياً.
                  </p>
                  {attendanceSheetName && (
                    <p className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded inline-block">
                      ✓ الملف المستورد بنجاح: {attendanceSheetName}
                    </p>
                  )}
                </div>

                <div className="flex flex-wrap gap-2 shrink-0">
                  <label className="bg-white hover:bg-slate-50 text-slate-700 font-bold px-4 py-2.5 rounded-xl border border-slate-200 text-xs cursor-pointer flex items-center gap-1.5 transition">
                    <Upload className="w-4 h-4 text-primary" />
                    <span>رفع شيت غياب مخصص</span>
                    <input 
                      type="file" 
                      accept=".xlsx, .xls, .csv" 
                      onChange={handleAttendanceUpload} 
                      className="hidden" 
                    />
                  </label>

                  <button 
                    onClick={downloadAttendanceTemplate}
                    className="bg-emerald-550 bg-emerald-600 text-white hover:bg-emerald-700 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>تحميل قالب الغياب الملحق</span>
                  </button>
                </div>
              </div>

              {/* Class Sheet Tabs (correlating with sheet pages) */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400 justify-start">
                  <span>📂 الصفحات والفصول المستكشفة في ملف الإكسل:</span>
                </div>
                
                <div className="flex flex-wrap gap-2 justify-start bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                  {[
                    "الصف الأول الابتدائي",
                    "الصف الثاني الابتدائي",
                    "الصف الثالث الابتدائي",
                    "الصف الرابع الابتدائي",
                    "الصف الخامس الابتدائي",
                    "الصف السادس الابتدائي",
                    "الصف الأول الإعدادي",
                    "الصف الثاني الإعدادي",
                    "الصف الثالث الإعدادي",
                    "الصف الأول الثانوي",
                    "الصف الثاني الثانوي العلمي",
                    "الصف الثاني الثانوي الأدبي",
                    "الصف الثالث الثانوي العلمي",
                    "الصف الثالث الثانوي الأدبي"
                  ].map((gradeTab) => (
                    <button
                      key={gradeTab}
                      onClick={() => handleSwitchClassSheet(gradeTab)}
                      className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all duration-200 ${
                        selectedClassSheet === gradeTab
                          ? "bg-primary text-white shadow-md border-transparent scale-[1.02]"
                          : "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 hover:text-primary"
                      }`}
                    >
                      📁 {gradeTab}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interactive Student Attendance Input Platform */}
              <div className="bg-slate-50 border border-slate-200 rounded-3xl p-6 space-y-4 text-right">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-slate-200 pb-3">
                  <div>
                    <h4 className="font-bold text-sm text-slate-800 font-display flex items-center gap-1.5 justify-start">
                      <span className="w-2.5 h-2.5 rounded-full bg-primary animate-ping"></span>
                      <span>✍️ منصة إدخال وتعديل بيانات الغياب والحضور للشيت النشط ({selectedClassSheet})</span>
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-1">
                      أدخل الاسم وسجل الحضور والغياب يدويًا لتعديل الشيت النشط ({selectedClassSheet}) فورًا أو إدراج طلاب جدد.
                    </p>
                  </div>
                  <div className="bg-white px-3 py-1 rounded-lg border border-slate-200 text-[10px] font-bold text-slate-600 font-mono">
                    الكود القادم الافتراضي: {getNextIdForGrade(selectedClassSheet)}
                  </div>
                </div>

                {submitMessage && (
                  <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl text-xs font-bold text-center animate-fade-in shadow-sm">
                    {submitMessage}
                  </div>
                )}

                <form onSubmit={handleAddAttendanceRecord} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div className="md:col-span-8 space-y-1 text-right">
                      <label className="text-[10px] font-extrabold text-slate-600 block">اسم الطالب رباعياً:</label>
                      <input
                        type="text"
                        required
                        value={newAttName}
                        onChange={(e) => setNewAttName(e.target.value)}
                        placeholder="أدخل الاسم رباعياً بدقة (مثال: أحمد عبد الله الشامي)"
                        className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right font-sans"
                      />
                    </div>
                    
                    <div className="md:col-span-4 space-y-1 text-right">
                      <label className="text-[10px] font-extrabold text-slate-600 block">كود الطالب (اختياري):</label>
                      <input
                        type="text"
                        value={newAttCode}
                        onChange={(e) => setNewAttCode(e.target.value)}
                        placeholder={`توليد تلقائي: ${getNextIdForGrade(selectedClassSheet)}`}
                        className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-left font-mono"
                      />
                    </div>
                  </div>

                  {/* Attendance matrices grid */}
                  <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-3">
                    <p className="text-[10px] font-bold text-slate-500 text-right mb-2">📊 سجلات حضور وغياب الطالب التفصيلية للأشهر الحالية:</p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Month 9 */}
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-150 space-y-2 text-right">
                        <p className="text-[10.5px] font-bold text-slate-700 border-b border-slate-200 pb-1">شهر 9 (سبتمبر)</p>
                        <div className="grid grid-cols-3 gap-1">
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">حضور</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttPres9}
                              onChange={(e) => setNewAttPres9(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">غياب</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttAbs9}
                              onChange={(e) => setNewAttAbs9(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">إذن</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttExc9}
                              onChange={(e) => setNewAttExc9(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Month 10 */}
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-150 space-y-2 text-right">
                        <p className="text-[10.5px] font-bold text-slate-700 border-b border-slate-200 pb-1">شهر 10 (أكتوبر)</p>
                        <div className="grid grid-cols-3 gap-1">
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">حضور</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttPres10}
                              onChange={(e) => setNewAttPres10(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">غياب</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttAbs10}
                              onChange={(e) => setNewAttAbs10(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">إذن</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttExc10}
                              onChange={(e) => setNewAttExc10(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Month 11 */}
                      <div className="p-3 bg-slate-50 rounded-xl border border-slate-150 space-y-2 text-right">
                        <p className="text-[10.5px] font-bold text-slate-700 border-b border-slate-200 pb-1">شهر 11 (نوفمبر)</p>
                        <div className="grid grid-cols-3 gap-1">
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">حضور</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttPres11}
                              onChange={(e) => setNewAttPres11(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">غياب</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttAbs11}
                              onChange={(e) => setNewAttAbs11(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] text-slate-500 font-bold block">إذن</label>
                            <input
                              type="number"
                              min="0"
                              max="31"
                              value={newAttExc11}
                              onChange={(e) => setNewAttExc11(e.target.value)}
                              className="w-full p-1 bg-white border border-slate-200 rounded-md text-center text-xs font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row justify-between items-center gap-3 pt-2">
                    <p className="text-[10px] text-slate-400 text-right leading-relaxed max-w-xl">
                      💡 ملاحظة الترميز: كل صف من الصفوف له مجال ترقيم مختلف يبدأ من مئة مخصصة له (مثلاً الأول الابتدائي من 100، الثاني من 200، الثالث من 300... وحتى الثالث الثانوي العلمي 1300 والأدبي 1400).
                    </p>
                    <button
                      type="submit"
                      className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-white font-bold px-6 py-3 rounded-xl text-xs transition flex items-center gap-1.5 justify-center shrink-0 shadow"
                    >
                      <Plus className="w-4 h-4" />
                      <span>إدراج وتعديل بيانات غياب الطالب في الشيت المختار 📁</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* The Attendance Ledger Sheet Table */}
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                  <span>📊 جدول حضور الطلاب للشهر والفصل الحالي: <strong className="text-primary">{selectedClassSheet}</strong></span>
                  <span className="text-slate-400 font-mono">تحديث فوري تلقائي</span>
                </div>

                <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-inner">
                  <table className="w-full text-right border-collapse text-[11px] whitespace-nowrap">
                    <thead>
                      <tr className="bg-slate-100/80 text-slate-700 border-b border-slate-200 font-bold">
                        <th className="p-3 w-16">كود الطالب</th>
                        <th className="p-3">الاسم رباعياً</th>
                        <th className="p-3 text-center bg-teal-50/20">حضور ش9</th>
                        <th className="p-3 text-center bg-rose-50/20">غياب ش9</th>
                        <th className="p-3 text-center bg-amber-50/20">إذن ش9</th>
                        <th className="p-3 text-center bg-teal-50/20">حضور ش10</th>
                        <th className="p-3 text-center bg-rose-50/20">غياب ش10</th>
                        <th className="p-3 text-center bg-amber-50/20">إذن ش10</th>
                        <th className="p-3 text-center bg-teal-50/20">حضور ش11</th>
                        <th className="p-3 text-center bg-rose-50/20">غياب ش11</th>
                        <th className="p-3 text-center bg-amber-50/20">إذن ش11</th>
                        <th className="p-3 text-center font-bold bg-teal-100/50">إجمالي حضور ف1</th>
                        <th className="p-3 text-center font-bold bg-rose-100/50">إجمالي غياب ف1</th>
                        <th className="p-3 text-center font-bold bg-amber-100/50">إجمالي إذن ف1</th>
                        <th className="p-3 text-center font-bold bg-teal-100/50">إجمالي حضور ف2</th>
                        <th className="p-3 text-center font-bold bg-rose-100/50">إجمالي غياب ف2</th>
                        <th className="p-3 text-center font-bold bg-amber-100/50">إجمالي إذن ف2</th>
                        <th className="p-3 text-center font-black bg-slate-900 text-white rounded-l-lg">الغياب السنوي</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-800 font-sans">
                      {/* Map through sheet rows or render customized template based on current database students for active class */}
                      {(attendanceData || students.filter((s) => s.grade === selectedClassSheet)).map((student: any) => {
                        // Safely handle both standard database format and XLSX imported columns formats
                        const sId = student.id || student["كود الطالب"] || "-";
                        const sName = student.name || student["اسم الطالب رباعياً"] || "طالب اختبار";
                        
                        const pres9 = student["حضور لشهر 9"] !== undefined ? student["حضور لشهر 9"] : (student.attendance?.present ? Math.floor(student.attendance.present / 6) : 20);
                        const abs9 = student["غياب لشهر 9"] !== undefined ? student["غياب لشهر 9"] : (student.attendance?.absent ? Math.min(2, student.attendance.absent) : 1);
                        const exc9 = student["استئذان لشهر 9"] !== undefined ? student["استئذان لشهر 9"] : 0;

                        const pres10 = student["حضور لشهر 10"] !== undefined ? student["حضور لشهر 10"] : 21;
                        const abs10 = student["غياب لشهر 10"] !== undefined ? student["غياب لشهر 10"] : 0;
                        const exc10 = student["استئذان لشهر 10"] !== undefined ? student["استئذان لشهر 10"] : 1;

                        const pres11 = student["حضور لشهر 11"] !== undefined ? student["حضور لشهر 11"] : 22;
                        const abs11 = student["غياب لشهر 11"] !== undefined ? student["غياب لشهر 11"] : 0;
                        const exc11 = student["استئذان لشهر 11"] !== undefined ? student["استئذان لشهر 11"] : 0;

                        const sumPresF1 = student["إجمالي حضور الفصل الأول"] !== undefined ? student["إجمالي حضور الفصل الأول"] : (Number(pres9) + Number(pres10) + Number(pres11));
                        const sumAbsF1 = student["إجمالي غياب الفصل الأول"] !== undefined ? student["إجمالي غياب الفصل الأول"] : (Number(abs9) + Number(abs10) + Number(abs11));
                        const sumExcF1 = student["إجمالي استئذان الفصل الأول"] !== undefined ? student["إجمالي استئذان الفصل الأول"] : (Number(exc9) + Number(exc10) + Number(exc11));

                        const sumPresF2 = student["إجمالي حضور الفصل الثاني"] !== undefined ? student["إجمالي حضور الفصل الثاني"] : 64;
                        const sumAbsF2 = student["إجمالي غياب الفصل الثاني"] !== undefined ? student["إجمالي غياب الفصل الثاني"] : 2;
                        const sumExcF2 = student["إجمالي استئذان الفصل الثاني"] !== undefined ? student["إجمالي استئذان الفصل الثاني"] : 1;

                        const totalYearAbs = student["الإجمالي السنوي للغياب"] !== undefined ? student["الإجمالي السنوي للغياب"] : (Number(sumAbsF1) + Number(sumAbsF2));

                        return (
                          <tr key={sId} className="hover:bg-slate-50 transition border-r-4 border-r-slate-200 hover:border-r-slate-705">
                            <td className="p-3 font-bold font-mono text-slate-500">{sId}</td>
                            <td className="p-3 font-semibold text-slate-800">{sName}</td>
                            <td className="p-3 text-center font-mono text-teal-700 bg-teal-50/10 font-bold">{pres9}</td>
                            <td className="p-3 text-center font-mono text-rose-700 bg-rose-50/10 font-bold">{abs9}</td>
                            <td className="p-3 text-center font-mono text-amber-700 bg-amber-50/10">{exc9}</td>
                            <td className="p-3 text-center font-mono text-teal-700 bg-teal-50/10 font-bold">{pres10}</td>
                            <td className="p-3 text-center font-mono text-rose-700 bg-rose-50/10 font-bold">{abs10}</td>
                            <td className="p-3 text-center font-mono text-amber-700 bg-amber-50/10">{exc10}</td>
                            <td className="p-3 text-center font-mono text-teal-700 bg-teal-50/10 font-bold">{pres11}</td>
                            <td className="p-3 text-center font-mono text-rose-700 bg-rose-50/10 font-bold">{abs11}</td>
                            <td className="p-3 text-center font-mono text-amber-700 bg-amber-50/10">{exc11}</td>
                            <td className="p-3 text-center font-mono font-bold bg-teal-50 text-teal-900 border-x border-slate-100">{sumPresF1}</td>
                            <td className="p-3 text-center font-mono font-bold bg-rose-50 text-rose-900 border-x border-slate-100">{sumAbsF1}</td>
                            <td className="p-3 text-center font-mono bg-amber-50 text-amber-900 border-x border-slate-100">{sumExcF1}</td>
                            <td className="p-3 text-center font-mono font-bold bg-teal-100/40 text-teal-950 border-x border-slate-100">{sumPresF2}</td>
                            <td className="p-3 text-center font-mono font-bold bg-rose-100/40 text-rose-950 border-x border-slate-100">{sumAbsF2}</td>
                            <td className="p-3 text-center font-mono bg-amber-100/40 text-amber-950 border-x border-slate-100">{sumExcF2}</td>
                            <td className="p-3 text-center font-black bg-rose-50 text-rose-700 rounded-l font-mono">{totalYearAbs} غياب</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 6: TEACHERS MANAGEMENT COMPONENT */}
        {activeTab === "teachers" && (
          <div className="lg:col-span-12 grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Form Column */}
            <div className="lg:col-span-4 bg-white border border-slate-105 rounded-3xl p-6 shadow-sm space-y-6 text-right animate-fade-in animate-duration-300">
              <div>
                <h3 className="font-bold text-md text-slate-900 font-display flex items-center gap-2 justify-start mb-1">
                  <UserPlus className="w-5 h-5 text-primary" />
                  <span>{editingTeacherId ? "تعديل بيانات المعلم الأكاديمية" : "إضافة معلم / مشرف أكاديمي جديد"}</span>
                </h3>
                <p className="text-[10px] text-slate-400">
                  قم بملء حقول السيرة والتعيين وإدراج الصورة الشخصية وتحديد المواد والفصول المدرسية المكلف بها بدقة.
                </p>
              </div>

              <form onSubmit={handleSaveTeacher} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-600 block">اسم المعلم رباعياً:</label>
                  <input
                    type="text"
                    required
                    value={teacherName}
                    onChange={(e) => setTeacherName(e.target.value)}
                    placeholder="مثال: أ. محمد أحمد صالح هبة"
                    className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-600 block">المادة التخصصية الأساسية:</label>
                  <input
                    type="text"
                    required
                    value={teacherSubject}
                    onChange={(e) => setTeacherSubject(e.target.value)}
                    placeholder="مثال: الرياضيات والفيزياء"
                    className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-600 block">الصفة الوظيفية والتربوية:</label>
                  <select
                    value={teacherRole}
                    onChange={(e) => setTeacherRole(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right font-bold text-slate-700"
                  >
                    <option value="مدرس مادة">مدرس مادة</option>
                    <option value="مشرف أكاديمي">مشرف أكاديمي</option>
                    <option value="رئيس قسم">رئيس قسم المواد</option>
                    <option value="وكيل شؤون الطلاب">وكيل شؤون الطلاب</option>
                    <option value="مدير عام المقر">مدير عام المقر</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-600 block">الفصول الدراسية المكلف بها (مفصولة بفاصلة):</label>
                  <input
                    type="text"
                    value={teacherClasses}
                    onChange={(e) => setTeacherClasses(e.target.value)}
                    placeholder="مثال: الصف الأول الإعدادي, الصف الثاني الثانوي العلمي"
                    className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-extrabold text-slate-600 block">رقم الهاتف للاتصال:</label>
                    <input
                      type="text"
                      value={teacherPhone}
                      onChange={(e) => setTeacherPhone(e.target.value)}
                      placeholder="7xxxxxxxx"
                      className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-left font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-extrabold text-slate-600 block">البريد الإلكتروني:</label>
                    <input
                      type="email"
                      value={teacherEmail}
                      onChange={(e) => setTeacherEmail(e.target.value)}
                      placeholder="name@amal.edu.ye"
                      className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-left font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-600 block flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>رابط الصورة الشخصية المباشر:</span>
                  </label>
                  <input
                    type="url"
                    value={teacherImageUrl}
                    onChange={(e) => setTeacherImageUrl(e.target.value)}
                    placeholder="أدخل رابط صورة مستضافة أو اترك الحقل للافتراضي"
                    className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-white/50 text-left font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-extrabold text-slate-600 block">النبذة والمسيرة الذاتية المهنية (البيو):</label>
                  <textarea
                    value={teacherBio}
                    onChange={(e) => setTeacherBio(e.target.value)}
                    rows={3}
                    placeholder="أدخل سيرة مهنية مختصرة عن المعلم وقدراته الأكاديمية والتربوية..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right leading-relaxed"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-1 bg-primary hover:bg-blue-850 text-white font-bold p-3 rounded-xl text-xs transition shadow-md shadow-primary/10"
                  >
                    {editingTeacherId ? "تحديث التعديلات المقترحة ✓" : "إدراج المعلم رسمياً بقائمة التدريس +"}
                  </button>
                  {editingTeacherId && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingTeacherId(null);
                        setTeacherName("");
                        setTeacherSubject("");
                        setTeacherRole("مدرس مادة");
                        setTeacherPhone("");
                        setTeacherEmail("");
                        setTeacherClasses("");
                        setTeacherImageUrl("");
                        setTeacherBio("");
                      }}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-705 font-bold px-4 py-2 rounded-xl text-xs transition"
                    >
                      إلغاء التعديل
                    </button>
                  )}
                </div>
              </form>
            </div>

            {/* List Column */}
            <div className="lg:col-span-8 space-y-4 text-right animate-fade-in animate-duration-300">
              <div className="bg-white border border-slate-105 rounded-3xl p-6 shadow-sm">
                <h3 className="font-bold text-md text-slate-905 font-display flex items-center gap-2 justify-start border-b border-slate-100 pb-3 mb-4">
                  <Users className="w-5 h-5 text-accent animate-pulse" />
                  <span>أعضاء الهيئة التعليمية والأكاديمية المعتمدين بالمقر ({teachers.length} معلمين)</span>
                </h3>

                <div className="grid sm:grid-cols-2 gap-4">
                  {teachers.map((t) => (
                    <div key={t.id} className="p-4 bg-slate-50/75 border border-slate-100 rounded-2xl flex flex-col justify-between hover:shadow-md transition-all duration-300 group">
                      <div className="space-y-3">
                        <div className="flex items-center gap-3 justify-start">
                          <img 
                            src={t.imageUrl || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=300"} 
                            alt={t.name}
                            className="w-12 h-12 rounded-full object-cover border-2 border-slate-200 shadow-md group-hover:scale-105 transition"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <h4 className="font-bold text-slate-950 font-display text-xs">{t.name}</h4>
                            <div className="flex flex-wrap items-center gap-1.5 mt-0.5 justify-start">
                              <span className="text-[9px] bg-primary text-white font-extrabold px-1.5 py-0.5 rounded-md">{t.role}</span>
                              <span className="text-[9px] bg-amber-50 text-amber-805 font-bold px-1.5 py-0.5 rounded border border-amber-100/50">تخصص: {t.subject}</span>
                            </div>
                          </div>
                        </div>

                        <div className="bg-white p-2.5 rounded-xl border border-slate-100 space-y-1.5 text-[10.5px] leading-relaxed">
                          <p className="text-slate-500 font-bold font-sans">
                            <span className="text-slate-400 text-[10px]">النبذة المهنة:</span> {t.bio || "معلم ومربي فاضل متميز بمدرسة أمل المستقبل النموذجية."}
                          </p>
                          <div className="border-t border-dashed border-slate-100 pt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-slate-405 text-[10px]">
                            <p className="font-mono font-bold text-slate-500"><span className="text-slate-400 font-sans">الهاتف:</span> {t.phone}</p>
                            <p className="font-mono font-bold text-slate-500"><span className="text-slate-400 font-sans">الكود:</span> {t.academicId}</p>
                          </div>
                          <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-50">
                            <span className="text-[9px] text-slate-400 font-sans">الفصول:</span>
                            {t.classes.map((cls, idx) => (
                              <span key={idx} className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-sans font-semibold">{cls}</span>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 mt-4 pt-3 border-t border-slate-100/60 shrink-0">
                        <button
                          onClick={() => handleEditTeacherClick(t)}
                          className="bg-primary/5 hover:bg-primary text-primary hover:text-white px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
                          title="تعديل السيرة"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          <span>تعديل السيرة والبيو</span>
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`هل أنت واثق تماماً من حذف سجل المعلم ${t.name} نهائياً من قاعدة البيانات الإدارية؟`)) {
                              handleDeleteTeacher(t.id);
                            }
                          }}
                          className="bg-rose-50 hover:bg-rose-600 text-rose-600 hover:text-white px-2.5 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
                          title="حذف السجل"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>حذف السجل</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
