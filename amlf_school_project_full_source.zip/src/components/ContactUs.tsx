import React, { useState } from "react";
import { Phone, Mail, MapPin, Send, MessageCircle, AlertCircle, Share2, Facebook, Twitter, Instagram } from "lucide-react";

export default function ContactUs() {
  const [name, setName] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [message, setMessage] = useState<string>("");
  
  const [success, setSuccess] = useState<boolean>(false);
  const [loader, setLoader] = useState<boolean>(false);
  const [generatedWhatsappUrl, setGeneratedWhatsappUrl] = useState<string>("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;

    setLoader(true);
    
    const schoolWhatsappNumber = "967783711148";
    const formattedText = `السلام عليكم ورحمة الله وبركاته، أنا المرسل: ${name}
البريد الإلكتروني للرد: ${email}
رقم الجوال لتسريع التواصل: ${phone || "غير متوفر"}
تفاصيل الاستفسار أو الملاحظة المطلوبة:
${message}`;

    const encodedText = encodeURIComponent(formattedText);
    const whatsappUrl = `https://wa.me/${schoolWhatsappNumber}?text=${encodedText}`;
    setGeneratedWhatsappUrl(whatsappUrl);

    setTimeout(() => {
      setLoader(false);
      setSuccess(true);
      
      // Attempt redirection
      try {
        window.open(whatsappUrl, "_blank");
      } catch (err) {
        window.location.href = whatsappUrl;
      }

      setName("");
      setEmail("");
      setPhone("");
      setMessage("");
    }, 1000);
  };

  return (
    <div id="contact-us-view" className="space-y-12 pb-12 text-right">
      
      {/* Search Header */}
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <span className="bg-primary/10 text-primary text-xs font-bold px-4 py-1.5 rounded-full tracking-wider">
          التواصل المباشر والاستعلام المالي والتعليمي
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 font-display">
          يسعدنا الرد على المكالمات والاستشارات دائماً
        </h1>
        <p className="text-slate-500 text-sm">
          تواصل مع إدارة القبول والتحويل أو احجز موعد زيارة لموقع المدرسة للتعرف على فصولنا واختيار الصف الأفضل لمستقبل طفلك.
        </p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8 items-start">
        
        {/* Contact info channels cards */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Quick contact info cards */}
          <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-6">
            <h3 className="font-bold text-slate-800 font-display text-sm pb-2 border-b border-slate-55">قنوات الاتصال المعتمدة</h3>
            
            <div className="space-y-4 text-xs">
               {/* WhatsApp direct click */}
              <a 
                href="https://wa.me/967783711148?text=مرحباً%20مدرسة%20أمل%20المستقبل%20الأهلية" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-emerald-50 text-emerald-800 rounded-xl hover:bg-emerald-100 transition duration-150"
              >
                <div className="p-2 bg-emerald-500 text-white rounded-lg">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-slate-800 text-xs">دردشة واتساب الفورية</p>
                  <p className="text-[10px] text-slate-500 font-mono">+967 78 371 1148</p>
                </div>
              </a>

              {/* Tel channel */}
              <a 
                href="tel:+967783711148"
                className="flex items-center gap-3 p-3 bg-blue-50 text-blue-800 rounded-xl hover:bg-blue-100 transition duration-150"
              >
                <div className="p-2 bg-primary text-white rounded-lg">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-slate-800 text-xs">رقم الاتصال المباشر</p>
                  <p className="text-[10px] text-slate-500 font-mono">+967 78 371 1148</p>
                </div>
              </a>

              {/* Email channel */}
              <a 
                href="mailto:info@amlf.ye"
                className="flex items-center gap-3 p-3 bg-slate-50 text-slate-800 rounded-xl hover:bg-slate-100 transition duration-150"
              >
                <div className="p-2 bg-slate-800 text-white rounded-lg">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-slate-800 text-xs">البريد الإلكتروني للإدارة</p>
                  <p className="text-[10px] text-slate-500 font-mono">info@amlf.ye</p>
                </div>
              </a>
            </div>
          </div>

          {/* Social media card */}
          <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm text-center space-y-4">
            <h4 className="font-bold text-slate-800 font-display text-sm">حساباتنا الرسمية على السوشيال ميديا (@amlf.ye)</h4>
            <div className="flex items-center justify-center gap-4 text-slate-450">
              <a href="https://facebook.com/amlf.ye" target="_blank" rel="noopener noreferrer" className="p-2 border border-slate-100 rounded-xl hover:text-primary hover:bg-slate-50 transition"><Facebook className="w-5 h-5" /></a>
              <a href="https://twitter.com/amlf.ye" target="_blank" rel="noopener noreferrer" className="p-2 border border-slate-100 rounded-xl hover:text-primary hover:bg-slate-50 transition"><Twitter className="w-5 h-5" /></a>
              <a href="https://instagram.com/amlf.ye" target="_blank" rel="noopener noreferrer" className="p-2 border border-slate-100 rounded-xl hover:text-primary hover:bg-slate-50 transition"><Instagram className="w-5 h-5" /></a>
            </div>
          </div>

          {/* School location instructions details */}
          <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-2">
            <div className="flex items-center gap-2 text-slate-800 font-bold text-xs justify-start">
              <MapPin className="w-4 h-4 text-rose-500" />
              <span>العنوان بالتفصيل:</span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">الجمهورية اليمنية، محافظة الحديدة، مدينة باجل، الشارع العام - مجمع مدرسة أمل المستقبل الأهلية.</p>
          </div>
        </div>

        {/* Dynamic forms and Maps simulator on right column */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* Active Contact Form */}
          <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm space-y-6">
            <h3 className="font-bold text-lg text-slate-800 font-display flex items-center gap-2 justify-start">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span>مراسلة فورية مباشرة للهيئة الاستشارية عبر واتساب</span>
            </h3>
            
            {success ? (
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-700 p-6 rounded-2xl text-center space-y-4">
                <p className="text-xl font-bold">✓ جاري التحويل والمراسلة عبر الواتساب</p>
                <p className="text-xs text-emerald-600">
                  لقد جهّزنا محتوى استفسارك بدقة ومثالية. يرجى النقر على الزر المباشر بالأسفل للإرسال مباشرة إلى رقم واتساب المدرسة الرسمي في حال لم يعمل التحويل التلقائي بمتصفحك:
                </p>
                
                <div className="py-2">
                  <a 
                    href={generatedWhatsappUrl}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3.5 rounded-xl text-xs transition shadow-lg hover:shadow-xl"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>بدء المحادثة والإرسال عبر واتساب الآن 💬</span>
                  </a>
                </div>

                <div className="pt-2">
                  <button 
                    onClick={() => setSuccess(false)}
                    className="bg-white text-slate-700 border border-slate-200 font-semibold px-4 py-2 rounded-xl text-[10px] hover:bg-slate-50 transition"
                  >
                    إرسال استفسار جديد لفريق آخر
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-705">اسمك بالكامل:</label>
                    <input
                      type="text"
                      required
                      placeholder="امثلة: عمر عبد الرحمن"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-emerald-550/50 text-right"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-705">البريد الإلكتروني للرد:</label>
                    <input
                      type="email"
                      required
                      placeholder="yourname@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-emerald-550/50 text-left font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-705">رقم الجوال لتسريع التواصل المالي (اختياري):</label>
                  <input
                    type="tel"
                    placeholder="مثال: 0599000000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-emerald-550/50 text-left font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-705">تفاصيل الاستفسار أو الملاحظة المطلوبة لـ الهيئة الاستشارية:</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="اكتب هنا كافة تفاصيل استفسارك حول الصفوف أو الرسوم أو طلب قبول ومراجعة..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-emerald-550/50 text-right"
                  />
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    disabled={loader}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3.5 rounded-xl text-xs transition duration-150 flex items-center gap-1.5 shadow-md"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{loader ? "جاري تحضير الرسالة للواتساب..." : "متابعة وإرسال الرسالة للإدارة عبر واتساب 💬"}</span>
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Immersive Google Map simulator widget */}
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-800 font-display text-sm justify-start flex items-center gap-2">
              <span>📍 موقع المدرسة الجغرافي عبر خرائط جوجل</span>
            </h3>

            {/* Simulated Interactive Map with coordinates */}
            <div className="w-full h-80 rounded-2xl bg-slate-100 border border-slate-200 relative overflow-hidden flex flex-col items-center justify-center text-center p-6 space-y-4 select-none">
              <div className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-multiply" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=800')` }}></div>
              
              <div className="relative z-10 bg-white/90 p-6 rounded-2xl border border-slate-200 shadow-xl max-w-sm space-y-3">
                <span className="inline-block bg-primary text-white text-[10px] font-bold px-2 py-0.5 rounded">مقر أمل المستقبل بالحديدة</span>
                <p className="text-xs font-bold text-slate-900">الشارع العام، مدينة باجل، اليمن</p>
                <p className="text-[10px] text-slate-500">يتضمن هذا الكروكي مباني مدرسة أمل المستقبل الأساسية والثانوية والمرافق الرياضية والعلمية بمدينة باجل العريقة.</p>
                <a 
                  href="https://maps.google.com/?q=باجل+الحديدة+اليمن" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-primary hover:bg-slate-850 text-white font-bold py-2 px-4 rounded-xl text-[11px] inline-block shadow transition"
                >
                  فتح في تطبيق الخرائط مباشرة 🗺️
                </a>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
