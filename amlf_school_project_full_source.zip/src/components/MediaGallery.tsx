import React, { useState } from "react";
import { GalleryItem } from "../types";
import { initialGallery, saveData, getSavedData } from "../data";
import { Image, Video, Eye, X, ZoomIn, Trash2, Edit } from "lucide-react";

export default function MediaGallery() {
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(() => {
    return getSavedData<GalleryItem[]>("school_gallery", initialGallery);
  });
  const [selectedTag, setSelectedTag] = useState<string>("all");
  const [zoomedImage, setZoomedImage] = useState<GalleryItem | null>(null);

  // Admin authentication (shared token)
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    return localStorage.getItem("news_gallery_authenticated") === "true";
  });
  const [passwordInput, setPasswordInput] = useState<string>("");
  const [passwordError, setPasswordError] = useState<string>("");

  // Editor states for photos
  const [editId, setEditId] = useState<string | null>(null);
  const [photoTitle, setPhotoTitle] = useState<string>("");
  const [photoCategory, setPhotoCategory] = useState<"أنشطة" | "حفلات" | "مرافق" | "فصول">("أنشطة");
  const [photoImage, setPhotoImage] = useState<string>("");
  const [photoSuccess, setPhotoSuccess] = useState<string>("");
  const [photoError, setPhotoError] = useState<string>("");

  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput.trim() === "64a93s") {
      setIsAdmin(true);
      localStorage.setItem("news_gallery_authenticated", "true");
      setPasswordError("");
      setPasswordInput("");
    } else {
      setPasswordError("كلمة المرور غير صحيحة، يرجى المحاولة مرة أخرى.");
    }
  };

  const handlePublishPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    setPhotoError("");
    setPhotoSuccess("");

    if (!photoTitle.trim()) {
      setPhotoError("يرجى إدخال عنوان أو وصف للصورة المرفوعة.");
      return;
    }

    const fallbackImg = "https://images.unsplash.com/photo-1576267423445-b2e0074d68a4?auto=format&fit=crop&q=80&w=600";
    const finalImage = photoImage.trim() || fallbackImg;

    if (editId) {
      const updated = galleryItems.map(item => {
        if (item.id === editId) {
          return {
            ...item,
            title: photoTitle.trim(),
            category: photoCategory,
            imageUrl: finalImage
          };
        }
        return item;
      });
      setGalleryItems(updated);
      saveData("school_gallery", updated);
      setPhotoSuccess("تم تعديل الصورة بنجاح وتثبيتها في البوم المعرض!");
      setEditId(null);
    } else {
      const newItem: GalleryItem = {
        id: "gallery-item-" + Date.now(),
        title: photoTitle.trim(),
        category: photoCategory,
        imageUrl: finalImage
      };
      const updated = [newItem, ...galleryItems];
      setGalleryItems(updated);
      saveData("school_gallery", updated);
      setPhotoSuccess("تمت إضافة الصورة بنجاح وتثبيتها في البوم المعرض!");
    }
    
    // Clear states
    setPhotoTitle("");
    setPhotoImage("");
    setTimeout(() => setPhotoSuccess(""), 4000);
  };

  const startEditPhoto = (item: GalleryItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAdmin) {
      alert("يرجى إدخال كلمة المرور الموحدة لتعديل الصور.");
      return;
    }
    setEditId(item.id);
    setPhotoTitle(item.title);
    setPhotoCategory(item.category);
    setPhotoImage(item.imageUrl);
    document.getElementById("admin-photo-editor-form")?.scrollIntoView({ behavior: "smooth" });
  };

  const handleDeletePhoto = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAdmin) {
      alert("يرجى إدخال كلمة المرور الموحدة لاتمام عملية حذف الصور.");
      return;
    }
    if (window.confirm("هل أنت متأكد من رغبتك في حذف هذه الصورة نهائياً من ألبوم المعرض؟")) {
      const updated = galleryItems.filter(item => item.id !== id);
      setGalleryItems(updated);
      saveData("school_gallery", updated);
    }
  };

  const filteredItems = selectedTag === "all"
    ? galleryItems
    : galleryItems.filter(item => item.category === selectedTag);

  return (
    <div id="media-gallery-view" className="space-y-12 pb-12 text-right">
      
      {/* Zoom Modal overlay */}
      {zoomedImage && (
        <div 
          onClick={() => setZoomedImage(null)}
          className="fixed inset-0 bg-black/85 z-50 flex flex-col items-center justify-center p-4 animate-fade-in"
        >
          <div className="absolute top-4 right-4 text-white">
            <button className="bg-white/10 p-3 rounded-full hover:bg-white/20 transition">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          <div 
            onClick={(e) => e.stopPropagation()}
            className="bg-slate-900 border border-white/10 rounded-2xl overflow-hidden max-w-3xl w-full p-2 space-y-4 shadow-2xl"
          >
            <img 
              src={zoomedImage.imageUrl} 
              alt={zoomedImage.title}
              className="w-full h-auto max-h-[70vh] object-contain rounded-xl"
              referrerPolicy="no-referrer"
            />
            <div className="p-4 text-right">
              <span className="bg-accent text-slate-950 font-bold px-3 py-1 rounded-md text-[10px] uppercase font-mono">{zoomedImage.category}</span>
              <h3 className="text-white font-bold text-lg mt-2 font-display">{zoomedImage.title}</h3>
            </div>
          </div>
        </div>
      )}

      {/* Intro Header */}
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <span className="bg-primary/10 text-primary text-xs font-bold px-4 py-1.5 rounded-full">
          ألبوم وذكريات أمل المستقبل
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 font-display">
          معرض الصور واللقطات الحية الفاتنة الكادر والأطفال
        </h1>
        <p className="text-slate-500 text-sm">
          جولة بصرية في معامل ومشاريع وحفلات التخرج وزيارات أبطال مدرستنا الأهلية لتبتسم بمستقبلهم معنا.
        </p>
      </div>

      {/* Categorized Filter bar and trigger lists */}
      <div className="flex flex-wrap items-center gap-3 justify-center border-b border-slate-100 pb-6">
        {[
          { id: "all", label: "كافة الألبومات" },
          { id: "أنشطة", label: "الأنشطة المدرسية" },
          { id: "حفلات", label: "حفلات التخرج والتكريم" },
          { id: "مرافق", label: "المختبرات والمرافق" },
          { id: "فصول", label: "فصول ذكية وتفاعلية" }
        ].map((tag) => (
          <button
            key={tag.id}
            onClick={() => setSelectedTag(tag.id)}
            className={`px-4.5 py-2 rounded-xl text-xs font-bold transition duration-200 font-display ${
              selectedTag === tag.id
                ? "bg-primary text-white shadow-md"
                : "bg-white text-slate-650 border border-slate-100 hover:bg-slate-50"
            }`}
          >
            {tag.label}
          </button>
        ))}
      </div>

      {/* Two-Column Responsive Split Layout */}
      <div className="grid lg:grid-cols-12 gap-8 items-start">
        
        {/* Right: Images listing block (8 columns) */}
        <div className="lg:col-span-8">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12 bg-white border border-dashed rounded-3xl">
              <p className="text-3xl">🖼️</p>
              <p className="text-sm font-bold text-slate-500 mt-2">لا توجد صور منشورة في هذا التصنيف حالياً.</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-6">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  id={`gallery-item-${item.id}`}
                  onClick={() => setZoomedImage(item)}
                  className="relative bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-md cursor-pointer group transition-all duration-300"
                >
                  <div className="h-56 overflow-hidden relative">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Admin Actions Overlay (Edit & Delete) */}
                    {isAdmin && (
                      <div className="absolute top-3 left-3 z-20 flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={(e) => startEditPhoto(item, e)}
                          title="تعديل تفاصيل الصورة"
                          className="p-1.5 bg-slate-900/85 hover:bg-amber-600 border border-white/10 text-white rounded-lg shadow-md hover:scale-105 transition duration-150 cursor-pointer"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleDeletePhoto(item.id, e)}
                          title="حذف هذه الصورة"
                          className="p-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg shadow-md hover:scale-105 transition duration-150 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* Blur Hover layer */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="bg-white/90 text-slate-900 p-3 rounded-full shadow-lg">
                        <ZoomIn className="w-5 h-5 text-slate-900" />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 flex items-center justify-between text-right">
                    <div className="space-y-1">
                      <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded font-bold">{item.category}</span>
                      <h4 className="font-bold text-slate-850 text-xs line-clamp-1">{item.title}</h4>
                    </div>
                    <p className="text-[11px] text-slate-400 font-medium whitespace-nowrap">تكبير 🔍</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Left: Photos Publisher Administrative Sidebar Panel (4 columns) */}
        <div className="lg:col-span-4">
          <div id="admin-photo-editor-form" className="bg-gradient-to-br from-slate-50 via-white to-indigo-50/10 border-2 border-slate-150 rounded-3xl p-6 shadow-sm space-y-5">
            <div className="border-b border-indigo-100 pb-3 text-right">
              <h3 className="font-extrabold text-slate-900 font-display text-base flex items-center gap-2 justify-start">
                <span className="text-lg">🖼️</span>
                <span>إدارة معرض الصور</span>
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">رفع اللقطات الحية وحذف الصور التي انتهت فعاليتها</p>
            </div>

            {!isAdmin ? (
              /* Password request form */
              <form onSubmit={handleVerifyPassword} className="space-y-4 text-right">
                <p className="text-xs text-slate-600 font-medium leading-relaxed">
                  هذه اللوحة محمية وتتطلب تصريح النشر. يرجى إدخال كلمة المرور للمتابعة:
                </p>
                <div className="space-y-1">
                  <input
                    type="password"
                    required
                    placeholder="أدخل رمز المرور الخاص لإدارة المعرض"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-center font-mono text-xs focus:outline-none focus:border-indigo-500 font-bold"
                  />
                  {passwordError && (
                    <p className="text-[10px] text-rose-600 bg-rose-50 p-2 rounded-lg text-center font-bold mt-1">{passwordError}</p>
                  )}
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-[#1e293b] hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition duration-150"
                >
                  تحقق وفك الإدارة
                </button>
              </form>
            ) : (
              /* Image Upload form */
              <form onSubmit={handlePublishPhoto} className="space-y-4 text-right text-xs">
                {photoSuccess && (
                  <p className="p-2.5 bg-emerald-50 text-emerald-805 rounded-xl text-center font-bold border border-emerald-250 mb-3">{photoSuccess}</p>
                )}
                {photoError && (
                  <p className="p-2.5 bg-rose-50 text-rose-805 rounded-xl text-center font-bold border border-rose-250 mb-3">{photoError}</p>
                )}

                <div className="space-y-1">
                  <label className="text-slate-705 font-bold block">عنوان أو وصف الصورة اللطيفة:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: طلاب العلمي أثناء تفعيل مشاريع الروبوتات"
                    value={photoTitle}
                    onChange={(e) => setPhotoTitle(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 text-right"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-705 font-bold block">تصنيف الألبوم (المجلد الفرعي):</label>
                  <select
                    value={photoCategory}
                    onChange={(e: any) => setPhotoCategory(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-right"
                  >
                    <option value="أنشطة">الأنشطة المدرسية</option>
                    <option value="حفلات">حفلات التخرج والتكريم</option>
                    <option value="مرافق">المختبرات والمرافق</option>
                    <option value="فصول">فصول ذكية وتفاعلية</option>
                  </select>
                </div>

                <div className="space-y-2 bg-slate-50/70 p-3 rounded-2xl border border-slate-100">
                  <label className="text-slate-705 font-bold block">المصدر أو الملف المرفوع:</label>
                  <div className="space-y-2">
                    {/* Device Upload */}
                    <label className="flex items-center justify-center gap-1.5 p-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-[10.5px] font-bold cursor-pointer transition">
                      <span>📁 اختيار وصورة لرفعها من الحاسوب</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              if (typeof reader.result === "string") {
                                setPhotoImage(reader.result);
                              }
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                    <input
                      type="text"
                      placeholder="أو إلصاق رابط لقطة ويب خارجي (URL)"
                      value={photoImage.startsWith("data:") ? "[صورة مرفوعة ومثبتة]" : photoImage}
                      onChange={(e) => setPhotoImage(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-xl text-left focus:outline-none focus:border-indigo-500 text-[10px] font-mono"
                    />
                  </div>
                  {photoImage && (
                    <div className="mt-1 border rounded-lg overflow-hidden h-16 bg-white relative">
                      <img src={photoImage} alt="Preview" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setPhotoImage("")}
                        className="absolute top-1 left-1 bg-rose-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded cursor-pointer"
                      >
                        إلغاء
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  {editId && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditId(null);
                        setPhotoTitle("");
                        setPhotoImage("");
                        setPhotoCategory("أنشطة");
                      }}
                      className="w-1/3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition duration-150 border border-slate-200"
                    >
                      إلغاء
                    </button>
                  )}
                  <button
                    type="submit"
                    className="flex-grow py-2.5 bg-indigo-600 hover:bg-[#1e293b] text-white rounded-xl font-bold text-xs transition duration-150"
                  >
                    {editId ? "حفظ التعديلات الحالية 💾" : "نشر وتثبيت لقطة المعرض المعجلة 🚀"}
                  </button>
                </div>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsAdmin(false);
                      localStorage.removeItem("news_gallery_authenticated");
                    }}
                    className="text-[9.5px] text-slate-400 hover:underline hover:text-rose-650 font-bold"
                  >
                    🔒 إقفال الجلسة الإدارية
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
