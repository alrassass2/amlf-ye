import React, { useState } from "react";
import { Parent, Student } from "../types";
import { initialParents, initialStudents, saveData, getSavedData } from "../data";
import { 
  CheckCircle, 
  AlertCircle, 
  Phone, 
  MessageSquare, 
  Send, 
  CreditCard, 
  Award, 
  Calendar, 
  ExternalLink,
  ShieldCheck,
  Download,
  Check,
  QrCode
} from "lucide-react";

export default function ParentPortal() {
  const [phoneQuery, setPhoneQuery] = useState<string>("");
  const [currentParent, setCurrentParent] = useState<Parent | null>(null);
  const [kidsList, setKidsList] = useState<Student[]>([]);
  const [hasLoggedIn, setHasLoggedIn] = useState<boolean>(false);
  const [errorText, setErrorText] = useState<string>("");

  // Payment module states
  const [payingInstallmentId, setPayingInstallmentId] = useState<string | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<"card" | "wallet" | "external">("card");
  const [selectedExternalProvider, setSelectedExternalProvider] = useState<string>("stripe_sandbox");
  const [selectedLocalWallet, setSelectedLocalWallet] = useState<string>("kuraimi_bank");
  const [walletPhone, setWalletPhone] = useState<string>("");
  const [cardNumber, setCardNumber] = useState<string>("");
  const [cardHolder, setCardHolder] = useState<string>("");
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [enteredOtp, setEnteredOtp] = useState<string>("");
  const [otpError, setOtpError] = useState<string>("");
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [paymentReceipt, setPaymentReceipt] = useState<{ id: string; amount: number; date: string; title: string; ref: string } | null>(null);

  // Administrative messages list Simulation
  const [adminMessages, setAdminMessages] = useState<{ sender: string; title: string; content: string; date: string }[]>([
    { sender: "إدارة القبول والتحويل", title: "تأكيد اعتماد نتائج الفصل الدراسي الثاني", content: "السادة أولياء الأمور الكرام، تم رفع وتدقيق كشوف درجات الطلاب بالكامل للعام الحالي، وبإمكانكم الآن استعراضها وتدقيقها طباعة.", date: "2026-05-19" },
    { sender: "مكتبة المحاسبة المالية", title: "إقرار الأقساط وتسهيلات الدفع المدرسي", content: "نحيطكم علماً بإتاحة خدمة تقسيط الرسوم الدراسية المتبقية لثلاث دفعات سهلة عبر الاستمارة الإلكترونية المتوفرة بصفحتكم.", date: "2026-05-18" }
  ]);

  const [parentMsgText, setParentMsgText] = useState<string>("");
  const [sentFeedback, setSentFeedback] = useState<boolean>(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText("");

    if (!phoneQuery.trim()) return;

    const savedParents = getSavedData<Parent[]>("school_parents", initialParents);
    const savedStudents = getSavedData<Student[]>("school_students", initialStudents);

    // Permit login via either Parent ID (PRN-XXXXX), phone number, or name matching
    const foundParent = savedParents.find(
      p => p.phone === phoneQuery.trim() || p.id === phoneQuery.trim() || p.name.includes(phoneQuery.trim())
    );

    if (foundParent) {
      setCurrentParent(foundParent);
      // Retrieve his children details
      const kids = savedStudents.filter(s => foundParent.students.includes(s.id));
      setKidsList(kids);
      setHasLoggedIn(true);
    } else {
      setErrorText("رقم الهاتف أو رقم ولي الأمر غير سجل في القيود المدرسية. يرجى إدخال الرقم الخاص المتسلّم (مثال: PRN-XXXXX) أو رقم هاتف ولي الأمر الموثق (مثال: 783711148).");
    }
  };

  const handleLogout = () => {
    setCurrentParent(null);
    setKidsList([]);
    setHasLoggedIn(false);
    setPhoneQuery("");
    setPaymentSuccess(false);
  };

  const startPayment = (txId: string, amount: number) => {
    setPayingInstallmentId(txId);
    setPayAmount(amount);
    setPaymentSuccess(false);
    setPaymentMethod("card");
    setOtpSent(false);
    setEnteredOtp("");
    setOtpError("");
    setWalletPhone("");
    setCardNumber("");
    setCardHolder("");
    setPaymentReceipt(null);
    setIsProcessingPayment(false);
  };

  const handleSendOTP = () => {
    if (!walletPhone.trim()) {
      setOtpError("يرجى إدخال رقم هاتف المحفظة أولاً");
      return;
    }
    setIsProcessingPayment(true);
    setOtpError("");
    setTimeout(() => {
      setIsProcessingPayment(false);
      setOtpSent(true);
    }, 1000);
  };

  const confirmSimulatedPayment = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentParent || !payingInstallmentId) return;

    if (paymentMethod === "wallet" && !otpSent) {
      handleSendOTP();
      return;
    }

    if (paymentMethod === "wallet" && enteredOtp.length < 4) {
      setOtpError("يرجى إدخال رمز التحقق المكون من 4 أرقام");
      return;
    }

    setIsProcessingPayment(true);
    setOtpError("");

    setTimeout(() => {
      // Load and update Parent financials database
      const savedParents = getSavedData<Parent[]>("school_parents", initialParents);
      const pIdx = savedParents.findIndex(p => p.id === currentParent.id);

      if (pIdx !== -1) {
        const parent = savedParents[pIdx];
        
        // Find which transaction is being paid
        const tx = parent.financials.transactions.find(t => t.id === payingInstallmentId);
        if (tx) {
          tx.status = "مقبول";
          // Recalculate fees
          parent.financials.paidFees += tx.amount;
          parent.financials.remainingFees = Math.max(0, parent.financials.remainingFees - tx.amount);
          
          // Generate an elegant, permanent receipt
          const referenceId = "TXN-" + Math.floor(100000 + Math.random() * 900000);
          const receiptInfo = {
            id: tx.id,
            amount: tx.amount,
            date: new Date().toISOString().split("T")[0] + " " + new Date().toTimeString().split(" ")[0],
            title: tx.title,
            ref: referenceId
          };
          setPaymentReceipt(receiptInfo);
        }

        saveData("school_parents", savedParents);
        setCurrentParent({ ...parent });
        setPaymentSuccess(true);
        setIsProcessingPayment(false);
      }
    }, 1200);
  };

  const handleSendDirectAdminMsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentMsgText.trim()) return;

    setSentFeedback(true);
    setParentMsgText("");
    setTimeout(() => {
      setSentFeedback(false);
    }, 4000);
  };

  return (
    <div id="parent-portal-section" className="space-y-12 pb-12 text-right">
      
      {!hasLoggedIn ? (
        <div className="max-w-md mx-auto bg-white p-8 rounded-3xl border border-slate-100 shadow-md space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-full flex items-center justify-center mx-auto text-2xl font-bold">
              👨‍👩‍👧‍👦
            </div>
            <h2 className="text-xl font-bold text-slate-900 font-display">بوابة ولي الأمر الإلكترونية</h2>
            <p className="text-xs text-slate-500">متابعة الأقساط والغياب واستلام الإشعارات المدرسية في ثوانٍ معدودة.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-705 block">أدخل رقم الهاتف أو الرقم الموحد لولي الأمر المولد:</label>
              <input
                id="parent-login-phone"
                type="text"
                required
                placeholder="مثال: PRN-48392 أو 783711148"
                value={phoneQuery}
                onChange={(e) => setPhoneQuery(e.target.value)}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-center font-mono focus:outline-none focus:border-indigo-500/50"
              />
            </div>

            {errorText && (
              <p className="text-xs text-rose-600 bg-rose-50 p-2.5 rounded-lg border border-rose-100">{errorText}</p>
            )}

            <button
              id="btn-login-parent"
              type="submit"
              className="w-full bg-primary hover:bg-slate-800 text-white font-bold py-3.5 rounded-xl text-xs transition duration-200 shadow-md"
            >
              تسجيل دخول ولي الأمر
            </button>
          </form>

          <div className="text-center border-t border-slate-50 pt-4 text-[10px] text-slate-400">
            <span>💡 أرقام تجريبية للتجربة السريعة: <strong>783711148</strong> (للطالب عمر) أو <strong>711114173</strong> (للمتفاعلين سارة ويوسف الكردي).</span>
          </div>
        </div>
      ) : (
        currentParent && (
          <div className="space-y-8 animate-fade-in">
            {/* Parent Welcomer */}
            <div className="bg-gradient-to-r from-slate-800 to-slate-950 text-white rounded-3xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4 text-right">
                <div className="w-14 h-14 bg-indigo-500/10 border border-indigo-500/20 rounded-full flex items-center justify-center text-xl font-bold text-orange-200">
                  🏠
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white font-display">أهلاً بك ولي الأمر الفاضل: {currentParent.name}</h2>
                  <p className="text-xs text-slate-400">رقم الاتصال الموثق: {currentParent.phone} | بريد: {currentParent.email}</p>
                </div>
              </div>

              <button
                onClick={handleLogout}
                className="bg-white/10 hover:bg-white/20 text-white border border-white/25 px-4 py-2 rounded-xl text-xs transition duration-200"
              >
                تسجيل الخروج
              </button>
            </div>

            {/* Content grids */}
            <div className="grid lg:grid-cols-12 gap-8">
              
              {/* Left sidebar: Kids dashboard statistics (8 cols) */}
              <div className="lg:col-span-8 space-y-8">
                
                {/* 1. Track kids grades and attendance cards */}
                <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-6">
                  <h3 className="font-bold text-lg text-slate-800 font-display pb-2 border-b border-slate-50 justify-start">متابعة الحضور والدرجات لأبنائكم وبناتكم</h3>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    {kidsList.map((kid) => (
                      <div key={kid.id} className="p-5 bg-slate-50/70 border border-slate-100 rounded-2xl space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-100/50 pb-3">
                          <div className="text-right">
                            <h4 className="font-bold text-sm text-slate-850">{kid.name}</h4>
                            <p className="text-[10px] text-slate-405">{kid.grade}</p>
                          </div>
                          <span className="text-xs bg-primary/10 text-primary font-bold px-3 py-1 rounded-full">الرقم: {kid.id}</span>
                        </div>

                        {/* Attendance details overview */}
                        <div className="grid grid-cols-3 gap-2 text-center text-xs">
                          <div className="bg-emerald-50 text-emerald-800 p-2.5 rounded-lg border border-emerald-100">
                            <p className="text-[10px] leading-none mb-1 text-emerald-600">أيام الحضور</p>
                            <span className="font-bold text-base">{kid.attendance.present} يوم</span>
                          </div>
                          
                          <div className="bg-rose-50 text-rose-800 p-2.5 rounded-lg border border-rose-100">
                            <p className="text-[10px] leading-none mb-1 text-rose-600">أيام الغياب</p>
                            <span className="font-bold text-base">{kid.attendance.absent} يوم</span>
                          </div>

                          <div className="bg-amber-50 text-amber-800 p-2.5 rounded-lg border border-amber-100">
                            <p className="text-[10px] leading-none mb-1 text-amber-600">إجازات مرخصة</p>
                            <span className="font-bold text-base">{kid.attendance.excused} يوم</span>
                          </div>
                        </div>

                        {/* Recent assignments submitted tracker */}
                        <div className="space-y-1 bg-white p-3 rounded-xl border border-slate-100">
                          <p className="text-[10px] text-slate-400 font-bold">آخر واجب مضاف في الجدول:</p>
                          {kid.assignments.length > 0 ? (
                            <div className="flex items-center justify-between text-xs pt-1">
                              <span className="text-slate-700 line-clamp-1">{kid.assignments[0].title}</span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                kid.assignments[0].status === "graded" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"
                              }`}>{kid.assignments[0].status === "graded" ? "مقيم" : "مستحق التقدير"}</span>
                            </div>
                          ) : (
                            <p className="text-xs text-slate-350 italic">لا توجد واجبات نشطة حالياً.</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. Financial payment center (Tuition Fees & Payments Tracker) */}
                <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-6">
                  <div className="flex items-center gap-3 justify-start pb-2 border-b border-slate-50">
                    <div className="p-2.5 bg-rose-50 text-rose-600 rounded-xl">
                      <CreditCard className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-800 font-display">لوحة متابعة الرسوم وحجوزات الباص المدرسي</h3>
                  </div>

                  {/* Pricing Bento status */}
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl">
                      <p className="text-xs text-slate-420 leading-none">إجمالي الرسوم المستحقة للعام</p>
                      <p className="font-black text-lg text-slate-800 mt-1">{currentParent.financials.totalFees} ريال</p>
                    </div>
                    <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl">
                      <p className="text-xs text-emerald-600 leading-none">رسوم الرسوم المدفوعة والمقرة</p>
                      <p className="font-black text-lg text-emerald-700 mt-1">{currentParent.financials.paidFees} ريال</p>
                    </div>
                    <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl">
                      <p className="text-xs text-rose-600 leading-none">مستحقات وأرصدة باقية</p>
                      <p className="font-black text-lg text-rose-700 mt-1">{currentParent.financials.remainingFees} ريال</p>
                    </div>
                  </div>

                  {/* Linked School Students Financial and Bus Reservation Table */}
                  {(() => {
                    try {
                      const saved = localStorage.getItem("school_student_fees");
                      if (saved) {
                        const list = JSON.parse(saved);
                        const parentKidsFees = list.filter((st: any) => kidsList.some(k => k.id === st.id));
                        if (parentKidsFees.length > 0) {
                          return (
                            <div className="space-y-3 pt-4 border-t border-slate-100">
                              <p className="text-xs font-black text-slate-700 flex items-center gap-1.5">
                                <span className="p-1 bg-sky-100 text-sky-700 rounded-md">🚌</span>
                                <span>تفاصيل كشوف تفنيد الرسوم ومقاعد الباص لأبنائكم بساحة النقل المدرسية:</span>
                              </p>
                              
                              <div className="overflow-x-auto rounded-xl border border-slate-100 bg-white">
                                <table className="w-full text-right text-xs table-auto border-collapse">
                                  <thead>
                                    <tr className="bg-slate-50 text-slate-500 font-extrabold border-b border-slate-100">
                                      <th className="p-3 text-right">الابن / الابنة</th>
                                      <th className="p-3 text-center">رسوم التعليم</th>
                                      <th className="p-3 text-center">خدمة النقل وباص</th>
                                      <th className="p-3 text-center">الزي والمناهج</th>
                                      <th className="p-3 text-center text-slate-800 font-black">إجمالي المطلوب</th>
                                      <th className="p-3 text-center text-emerald-700 font-black">كم سُدد</th>
                                      <th className="p-3 text-center text-rose-700 font-black">المتبقي المطلوب</th>
                                      <th className="p-3 text-center">موقع مقعد الباص المسفر الدراسي</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {parentKidsFees.map((st: any) => {
                                      const expectedTotal = st.tuitionFee + st.busFee + st.uniformFee + st.booksFee;
                                      const remaining = expectedTotal - st.amountPaid;
                                      return (
                                        <tr key={st.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50">
                                          <td className="p-3 text-right">
                                            <p className="font-extrabold text-slate-800 text-[11px]">{st.name}</p>
                                            <p className="text-[9.5px] text-slate-400 font-bold">{st.grade}</p>
                                          </td>
                                          <td className="p-3 text-center font-mono text-slate-600">{Number(st.tuitionFee).toLocaleString()} ريال</td>
                                          <td className="p-3 text-center font-mono text-sky-700 font-bold">
                                            {st.busFee > 0 ? `${Number(st.busFee).toLocaleString()} ريال` : "غير مشترك"}
                                          </td>
                                          <td className="p-3 text-center font-mono text-slate-600">{Number(st.uniformFee + st.booksFee).toLocaleString()} ريال</td>
                                          <td className="p-3 text-center font-mono text-slate-800 font-black">{expectedTotal.toLocaleString()} ريال</td>
                                          <td className="p-3 text-center font-mono text-emerald-800 font-black">{Number(st.amountPaid).toLocaleString()} ريال</td>
                                          <td className="p-3 text-center font-mono">
                                            {remaining <= 0 ? (
                                              <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded text-[9.5px] font-bold">تم السداد ✓</span>
                                            ) : (
                                              <span className="font-mono font-black text-rose-650 bg-rose-50/60 px-2 py-0.5 rounded text-[10px]">
                                                {remaining.toLocaleString()} ريال
                                              </span>
                                            )}
                                          </td>
                                          <td className="p-3 text-center">
                                            {st.busFee > 0 ? (
                                              <div className="space-y-0.5 inline-block text-[10px]">
                                                <p className="font-extrabold text-sky-850">📍 {st.busRoute}</p>
                                                <p className="text-slate-450 text-[9px]">رقم المقعد: <span className="font-bold text-slate-750">{st.seatNumber}</span></p>
                                              </div>
                                            ) : (
                                              <p className="text-slate-350 italic text-[10px]">نقل خاص مستقل</p>
                                            )}
                                          </td>
                                        </tr>
                                      );
                                    })}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          );
                        }
                      }
                    } catch (err) {
                      console.error("Error reading kids fees from parent portal:", err);
                    }
                    return null;
                  })()}

                  {/* Installments checkout table */}
                  <div className="space-y-4 pt-4">
                    <p className="text-xs font-bold text-slate-705">دفع ومراجعة الأقساط بشكل مباشر:</p>
                    {currentParent.financials.transactions.map((tx) => (
                      <div key={tx.id} className="p-4 bg-slate-50/60 rounded-xl border border-slate-100 flex items-center justify-between gap-4">
                        <div className="text-right space-y-1">
                          <h4 className="font-bold text-slate-800 text-xs">{tx.title}</h4>
                          <p className="text-[10px] text-slate-400 font-mono">التبويب: {tx.date} | المعرف: {tx.id}</p>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-xs font-black text-primary font-mono">{tx.amount} ريال</span>
                          {tx.status === "مقبول" ? (
                            <span className="bg-emerald-50 text-emerald-700 text-[11px] font-bold px-3 py-1 rounded-full">✓ تم الدفع والاعتماد</span>
                          ) : (
                            <div className="flex gap-2">
                              <span className="bg-amber-50 text-amber-700 text-[11px] font-medium px-2.5 py-1 rounded-full">قيد الانتظار</span>
                              <button
                                onClick={() => startPayment(tx.id, tx.amount)}
                                className="bg-primary hover:bg-slate-800 text-white font-bold px-3 py-1 rounded-lg text-[11px] transition"
                              >
                                دفع إلكتروني سريع
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Dynamic Multi-Channel Payment Sandbox Gateway */}
                  {payingInstallmentId && (
                    <div className="bg-gradient-to-br from-indigo-50/50 via-slate-50 to-blue-50/30 border-2 border-indigo-250/75 p-6 rounded-3xl text-right space-y-6 animate-fade-in relative overflow-hidden shadow-md">
                      {/* Security Header Badge */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/60 pb-4">
                        <div className="flex items-center gap-2 text-indigo-950">
                          <div className="p-1.5 bg-indigo-600 text-white rounded-lg">
                            <CreditCard className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-xs sm:text-sm">بوابة سداد الرسوم والأقساط الذكية 🔒</h4>
                            <p className="text-[10px] text-slate-500">مشفرة بالكامل بنظام حماية SSL مالي من مدرسة أمل المستقبل</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 bg-indigo-50 border border-indigo-100 text-indigo-805 text-[10px] font-bold px-2.5 py-1 rounded-lg self-start sm:self-center">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>سند معجل بقيمة: {payAmount} ريال</span>
                        </div>
                      </div>

                      {paymentSuccess && paymentReceipt ? (
                        /* Certified digital printed receipt design */
                        <div className="space-y-4 animate-fade-in">
                          <div className="bg-white border-2 border-emerald-400 p-6 rounded-2xl shadow-sm space-y-5 relative">
                            {/* Decorative stamp effect */}
                            <div className="absolute top-4 left-4 border-2 border-dashed border-emerald-500/60 text-emerald-600 text-[10px] font-black px-3 py-1.5 rounded-lg rotate-12 select-none uppercase tracking-wider">
                              ✓ مقرة ماليًا
                              <br />
                              AMAL SCHOOL
                            </div>

                            <div className="text-center space-y-2 border-b border-dashed border-slate-200 pb-4">
                              <p className="text-emerald-700 font-extrabold text-base flex items-center justify-center gap-1.5">
                                <ShieldCheck className="w-5 h-5" />
                                <span>تم سداد القسط بنجاح واعتماد المعاملة فوري!</span>
                              </p>
                              <p className="text-[10.5px] text-slate-500">تم تحديث كشف المالية وتصفير القسط المستحق بنجاح من سجل ولي الأمر.</p>
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-xs font-sans text-right">
                              <div className="space-y-2">
                                <p className="text-slate-400">اسم ولي الأمر المسدد:</p>
                                <p className="font-bold text-slate-900">{currentParent.name}</p>
                              </div>
                              <div className="space-y-2">
                                <p className="text-slate-400">رقم السند المرجعي:</p>
                                <p className="font-bold text-slate-900 font-mono tracking-wide">{paymentReceipt.ref}</p>
                              </div>
                              <div className="space-y-2">
                                <p className="text-slate-400">القسط المدفوع:</p>
                                <p className="font-extrabold text-[#111827]">{paymentReceipt.title}</p>
                              </div>
                              <div className="space-y-2">
                                <p className="text-slate-400">تاريخ ووقت المعاملة:</p>
                                <p className="font-bold text-slate-900 font-mono">{paymentReceipt.date}</p>
                              </div>
                              <div className="space-y-2">
                                <p className="text-slate-400 font-bold text-emerald-700">المبلغ المستقطع المعتمد:</p>
                                <p className="font-black text-emerald-800 text-sm font-mono">{paymentReceipt.amount} ريال</p>
                              </div>
                              <div className="space-y-2 font-mono text-[9px] text-slate-500 leading-tight">
                                <p className="text-slate-400 font-sans font-bold">طريقة السداد الموثقة:</p>
                                <p className="font-bold text-indigo-700">
                                  {paymentMethod === "card" ? "💳 بطاقة صراف ذكية" :
                                   paymentMethod === "wallet" ? "📱 محفظة جوال محلية" :
                                   "🌐 Stripe External Sandbox Gateway"}
                                </p>
                              </div>
                            </div>

                            {/* barcode simulated interface */}
                            <div className="border-t border-slate-100 pt-4 flex items-center justify-between gap-4">
                              <div className="flex items-center gap-2">
                                <QrCode className="w-10 h-10 text-slate-800" />
                                <div className="text-right">
                                  <p className="text-[9px] text-slate-400 font-mono">سند رقمي مشفر</p>
                                  <p className="text-[9px] text-slate-500">مسجل بوزارة المالية لعام 2026</p>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => alert("محاكاة: جاري تحميل وحفظ السند الرسمي بصيغة PDF على جهازكم لوقت الاستظهار الحسي.")}
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-250 text-slate-705 rounded-xl text-[10.5px] font-bold font-sans transition"
                              >
                                <Download className="w-3.5 h-3.5" />
                                <span>حفظ وتنزيل السند ومطابقتها</span>
                              </button>
                            </div>
                          </div>

                          <div className="flex justify-end gap-2 pt-2">
                            <button
                              type="button"
                              onClick={() => setPayingInstallmentId(null)}
                              className="px-5 py-2 hover:bg-slate-200 text-slate-700 bg-slate-100 rounded-xl text-xs font-bold transition duration-200"
                            >
                              إغلاق كشف الدفع الفوري
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-5">
                          {/* Channel/Method switching Tabs */}
                          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-200/70 rounded-2xl">
                            <button
                              type="button"
                              onClick={() => { setPaymentMethod("card"); setOtpSent(false); }}
                              className={`py-2 rounded-xl text-[11px] font-bold text-center transition ${
                                paymentMethod === "card" ? "bg-white text-indigo-950 shadow-sm" : "text-slate-600 hover:text-slate-900"
                              }`}
                            >
                              💳 بطاقة صراف (مدى/فيزا)
                            </button>
                            <button
                              type="button"
                              onClick={() => { setPaymentMethod("wallet"); setOtpSent(false); }}
                              className={`py-2 rounded-xl text-[11px] font-bold text-center transition ${
                                paymentMethod === "wallet" ? "bg-white text-indigo-950 shadow-sm" : "text-slate-600 hover:text-slate-900"
                              }`}
                            >
                              📱 محفظة محلية (الكريمي/جوال)
                            </button>
                            <button
                              type="button"
                              onClick={() => { setPaymentMethod("external"); setOtpSent(false); }}
                              className={`py-2 rounded-xl text-[11px] font-bold text-center transition ${
                                paymentMethod === "external" ? "bg-white text-indigo-950 shadow-sm" : "text-slate-600 hover:text-slate-900"
                              }`}
                            >
                              🌐 بوابة خارجية (Sandbox)
                            </button>
                          </div>

                          {/* 1. Credit Card Form */}
                          {paymentMethod === "card" && (
                            <form onSubmit={confirmSimulatedPayment} className="space-y-4 animate-fade-in text-xs text-right">
                              <p className="text-[11px] text-slate-500 leading-snug">بوابة مدى الآمنة تقبل بطاقات يونيون باي، فيزا، وماستركارد اليمنية والدولية.</p>
                              
                              <div className="grid sm:grid-cols-2 gap-3.5">
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-755 block">اسم حامل البطاقة (بالأحرف اللاتينية):</label>
                                  <input 
                                    type="text" 
                                    required
                                    placeholder="MOHAMMED AL-KURDI" 
                                    value={cardHolder}
                                    onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-left uppercase font-mono text-xs focus:outline-none focus:border-indigo-500" 
                                  />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-755 block">رقم البطاقة المكون من 16 خانة:</label>
                                  <input 
                                    type="text" 
                                    required
                                    placeholder="4000 1234 5678 9010" 
                                    maxLength={19}
                                    value={cardNumber}
                                    onChange={(e) => setCardNumber(e.target.value)}
                                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-center font-mono text-xs focus:outline-none focus:border-indigo-500" 
                                  />
                                </div>
                              </div>

                              <div className="grid grid-cols-3 gap-3">
                                <div className="space-y-1 col-span-2">
                                  <label className="text-[10px] font-bold text-slate-755 block">تاريخ تاريخ الانتهاء (شهر / سنة):</label>
                                  <div className="flex gap-2">
                                    <input type="text" placeholder="MM" maxLength={2} required className="w-1/2 p-2.5 bg-white border border-slate-200 rounded-xl text-center font-mono" />
                                    <input type="text" placeholder="YY" maxLength={2} required className="w-1/2 p-2.5 bg-white border border-slate-200 rounded-xl text-center font-mono" />
                                  </div>
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-755 block">رمز الأمان (CVV):</label>
                                  <input type="password" placeholder="***" maxLength={3} required className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-center font-mono" />
                                </div>
                              </div>

                              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200/60">
                                <button
                                  type="button"
                                  onClick={() => setPayingInstallmentId(null)}
                                  className="px-4 py-2 hover:bg-slate-200 text-slate-600 bg-slate-100 rounded-xl text-[11px] font-bold"
                                >
                                  إلغاء الأمر
                                </button>
                                <button
                                  type="submit"
                                  disabled={isProcessingPayment}
                                  className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:bg-slate-300 text-white font-bold rounded-xl text-[11px] transition shadow flex items-center gap-1.5"
                                >
                                  {isProcessingPayment ? (
                                    <>
                                      <span className="w-3.5 h-3.5 rounded-full border-2 border-white border-t-transparent animate-spin inline-block"></span>
                                      <span>جاري تأمين الرصيد...</span>
                                    </>
                                  ) : (
                                    <>
                                      <Check className="w-4 h-4" />
                                      <span>تأكيد سداد {payAmount} ريال</span>
                                    </>
                                  )}
                                </button>
                              </div>
                            </form>
                          )}

                          {/* 2. Wallet options form */}
                          {paymentMethod === "wallet" && (
                            <div className="space-y-4 animate-fade-in text-xs text-right">
                              <p className="text-[11px] text-slate-550 leading-snug">
                                سدد قسط المدرسة فوراً عبر المحافظ الإلكترونية اليمنية المعتمدة باستخدام رقم حسابك ورسالة الـ OTP.
                              </p>

                              <div className="grid sm:grid-cols-2 gap-3.5">
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-700 block">اختر مزود المحفظة المحلي:</label>
                                  <select
                                    value={selectedLocalWallet}
                                    onChange={(e) => {
                                      setSelectedLocalWallet(e.target.value);
                                      setOtpSent(false);
                                    }}
                                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-right font-sans"
                                  >
                                    <option value="kuraimi_bank">حساب بنك الكريمي الإسلامي (إم فلوس)</option>
                                    <option value="jawal_pay">جوال بي / محفظة باسوورد</option>
                                    <option value="yemen_mobile_wallet">محفظة موبايل موني (بنك اليمن والكويت)</option>
                                    <option value="one_cash">ون كاش الإلكتروني (ONE Cash)</option>
                                  </select>
                                </div>

                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-slate-700 block">رقم هاتف مشترك المحفظة الموثق:</label>
                                  <input
                                    type="text"
                                    required
                                    placeholder="770000000"
                                    value={walletPhone}
                                    onChange={(e) => setWalletPhone(e.target.value)}
                                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-center font-mono focus:outline-none focus:border-indigo-500"
                                  />
                                </div>
                              </div>

                              {otpSent ? (
                                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-3 animate-fade-in">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[10px] font-extrabold text-amber-900 block font-sans">✉️ تم إرسال رمز الأمان OTP لرقم هاتفك:</span>
                                    <span className="text-[9px] bg-amber-200 text-amber-950 font-bold px-2 py-0.5 rounded animate-pulse">ادخل الكود الاختباري: 6251</span>
                                  </div>
                                  <div className="flex gap-2 items-center justify-center">
                                    <input
                                      type="text"
                                      maxLength={4}
                                      placeholder="ادخل رمز التحقق المؤقت"
                                      value={enteredOtp}
                                      onChange={(e) => setEnteredOtp(e.target.value)}
                                      className="w-48 p-2.5 bg-white border border-slate-200 rounded-xl text-center font-mono font-bold tracking-widest text-sm"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => confirmSimulatedPayment()}
                                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition flex items-center gap-1.5 shrink-0"
                                    >
                                      {isProcessingPayment ? "جاري الخصم..." : "تحقق وتأكيد سداد الرسوم"}
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div className="flex justify-end gap-2 pt-2 border-t border-slate-200/60">
                                  <button
                                    type="button"
                                    onClick={() => setPayingInstallmentId(null)}
                                    className="px-4 py-2 hover:bg-slate-200 text-slate-600 bg-slate-100 rounded-xl text-[11px] font-bold"
                                  >
                                    إلغاء
                                  </button>
                                  <button
                                    type="button"
                                    onClick={handleSendOTP}
                                    disabled={isProcessingPayment}
                                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-[11px] transition"
                                  >
                                    {isProcessingPayment ? "جاري الإرسال..." : "أرسل رمز التحقق الهاتفي (OTP)"}
                                  </button>
                                </div>
                              )}

                              {otpError && (
                                <p className="text-[10px] text-rose-600 bg-rose-50/50 p-2 rounded-lg border border-rose-100 text-center">{otpError}</p>
                              )}
                            </div>
                          )}

                          {/* 3. External payment Sandbox link simulation */}
                          {paymentMethod === "external" && (
                            <div className="p-4 bg-slate-100/60 rounded-2xl border border-slate-250/50 space-y-4 animate-fade-in text-right">
                              <p className="text-[11px] text-slate-600 leading-relaxed">
                                بدلاً من إدخال رصيدك في فيزا أو مدى محلياً، يمكنك الانتقال المباشر لبوابة السداد الخارجية (بثوان معدودة) عبر الرابط المخصص للـ Sandbox المالي.
                              </p>

                              <div className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-between gap-4">
                                <div>
                                  <p className="font-extrabold text-xs text-slate-900">ساندبوكس الدفع الخارجي المعتمد (Stripe Connect)</p>
                                  <p className="text-[9.5px] text-[#2563eb] underline font-mono">https://checkout.sandbox.stripe.com/amal-school-pay/tx_{payingInstallmentId}</p>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setIsProcessingPayment(true);
                                    setTimeout(() => {
                                      confirmSimulatedPayment();
                                    }, 1000);
                                  }}
                                  className="flex items-center gap-1.5 px-3 py-2 bg-blue-650 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition cursor-pointer self-center"
                                >
                                  <span>الانتقال وتأكيد السداد الخارجي</span>
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </button>
                              </div>

                              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200/60">
                                <button
                                  type="button"
                                  onClick={() => setPayingInstallmentId(null)}
                                  className="px-4 py-2 hover:bg-slate-200 text-slate-605 bg-slate-100 rounded-xl text-[11px] font-bold"
                                >
                                  رجوع
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>

              </div>

              {/* Right Sidebar: Direct Messaging to Admin and school rules (4 cols) */}
              <div className="lg:col-span-4 space-y-6">
                
                {/* 1. Direct school administrative notifications feed */}
                <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
                  <h3 className="font-bold text-slate-800 font-display text-sm pb-2 border-b border-slate-50 justify-start">إخطارات ومراسلات الإدارة الهامة</h3>
                  
                  <div className="space-y-4 text-xs">
                    {adminMessages.map((msg, i) => (
                      <div key={i} className="space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-100 text-right">
                        <div className="flex justify-between items-center pb-1 border-b border-slate-100/40">
                          <strong className="text-primary">{msg.sender}</strong>
                          <span className="text-[9px] text-slate-400 font-mono">{msg.date}</span>
                        </div>
                        <h4 className="font-bold text-slate-850 pt-1 leading-snug">{msg.title}</h4>
                        <p className="text-slate-500 text-[10px] leading-relaxed">{msg.content}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. Chat/Contact school direct */}
                <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
                  <h4 className="font-bold text-slate-800 font-display text-sm pb-1 justify-start">مراسلة إدارة المدرسة فورياً</h4>
                  <p className="text-[10px] text-slate-450 leading-relaxed">بإمكانك إرسال طلب خاص بالغياب المبرر لولدك أو الاستعلام عن تفتيش الحافلات وتلقي رد خلال دقائق.</p>

                  {sentFeedback ? (
                    <p className="text-xs text-emerald-705 font-semibold bg-emerald-50 border border-emerald-100 p-3 rounded-xl">✓ تم إرسال رسالتكم للجنة شؤون أولياء الأمور بنجاح.</p>
                  ) : (
                    <form onSubmit={handleSendDirectAdminMsg} className="space-y-3">
                      <textarea
                        required
                        rows={3}
                        placeholder="اكتب هنا موضوع الاستعلام ليرتفع على لوحة الإدارة..."
                        value={parentMsgText}
                        onChange={(e) => setParentMsgText(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        type="submit"
                        className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded-xl text-xs transition border border-slate-150"
                      >
                        إرسال الطلب للتدقيق
                      </button>
                    </form>
                  )}
                </div>

              </div>

            </div>
          </div>
        )
      )}

    </div>
  );
}
