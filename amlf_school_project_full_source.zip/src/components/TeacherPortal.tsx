import React, { useState } from "react";
import { Teacher, Student } from "../types";
import { initialTeachers, initialStudents, saveData, getSavedData, saveDataWithServerSync } from "../data";
import { Award, BookOpen, Calendar, CheckCircle, Clock, FileText, Plus, Save, UserCheck, Users, Edit, Trash2, Lock, Settings, ArrowRight } from "lucide-react";

export const ALL_SCHOOL_GRADES = [
  "الصف الأول الابتدائي",
  "الصف الثاني الابتدائي",
  "الصف الثالث الابتدائي",
  "الصف الرابع الابتدائي",
  "الصف الخامس الابتدائي",
  "الصف السادس الابتدائي",
  "الصف الأول الإعدادي",
  "الصف الثاني الإعدادي",
  "الصف الثالث الإعدادي",
  "الصف الأول الثانوي",
  "الصف الثاني الثانوي",
  "الصف الثالث الثانوي"
];

export default function TeacherPortal() {
  const [teachersList, setTeachersList] = useState<Teacher[]>(() => 
    getSavedData<Teacher[]>("school_teachers", initialTeachers)
  );
  const [activeTeacher, setActiveTeacher] = useState<Teacher | null>(null);

  // Academic Supervisor Control Panel states
  const [isSupervisorMode, setIsSupervisorMode] = useState<boolean>(false);
  const [supervisorPassword, setSupervisorPassword] = useState<string>("64a93s"); // Default value to verify
  const [supervisorInputPass, setSupervisorInputPass] = useState<string>("");
  const [supervisorError, setSupervisorError] = useState<string>("");
  const [isSupervisorAuthenticated, setIsSupervisorAuthenticated] = useState<boolean>(false);

  // States for adding/editing a teacher in Supervisor mode
  const [supEditingTeacherId, setSupEditingTeacherId] = useState<string | null>(null);
  const [supTeacherName, setSupTeacherName] = useState<string>("");
  const [supTeacherSubject, setSupTeacherSubject] = useState<string>("");
  const [supTeacherGrades, setSupTeacherGrades] = useState<string[]>([]);
  const [supTeacherBio, setSupTeacherBio] = useState<string>("");
  const [supTeacherImageUrl, setSupTeacherImageUrl] = useState<string>("");
  const [supTeacherPhone, setSupTeacherPhone] = useState<string>("");
  const [supTeacherEmail, setSupTeacherEmail] = useState<string>("");
  const [supTeacherRole, setSupTeacherRole] = useState<string>("مدرس مادة");
  const [supSuccessMessage, setSupSuccessMessage] = useState<string>("");

  // Daily Temporary Homework logic (24-hour expiration)
  const [dailyGrade, setDailyGrade] = useState<string>("الصف السادس الابتدائي");
  const [dailySubject, setDailySubject] = useState<string>("");
  const [dailyTitle, setDailyTitle] = useState<string>("");
  const [dailyHomeworkAddedSuccess, setDailyHomeworkAddedSuccess] = useState<boolean>(false);
  const [dailyHomeworks, setDailyHomeworks] = useState<any[]>(() => {
    const raw = getSavedData<any[]>("school_daily_homeworks", []);
    const now = Date.now();
    const valid = raw.filter(hw => (now - hw.createdAt) < 24 * 60 * 60 * 1000);
    if (valid.length !== raw.length) {
      saveData("school_daily_homeworks", valid);
    }
    return valid;
  });

  // Load students database
  const [students, setStudents] = useState<Student[]>(() => 
    getSavedData<Student[]>("school_students", initialStudents)
  );

  // Classroom selection (for attendance or grading)
  const [selectedGrade, setSelectedGrade] = useState<string>("الصف السادس الابتدائي");

  // New Lesson form states
  const [lessonTitle, setLessonTitle] = useState<string>("");
  const [lessonDesc, setLessonDesc] = useState<string>("");
  const [lessonClass, setLessonClass] = useState<string>("الصف السادس الابتدائي");
  const [lessonAddedSuccess, setLessonAddedSuccess] = useState<boolean>(false);

  // New Assignment form states
  const [assignTitle, setAssignTitle] = useState<string>("");
  const [assignDueDate, setAssignDueDate] = useState<string>("");
  const [assignAddedSuccess, setAssignAddedSuccess] = useState<boolean>(false);

  // Attendance recording states (date and child status map)
  const [attendanceDate, setAttendanceDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [attendanceStatuses, setAttendanceStatuses] = useState<Record<string, "حاضر" | "غائب" | "إجازة">>({});
  const [attendanceSavedSuccess, setAttendanceSavedSuccess] = useState<boolean>(false);

  // Grading assignment state
  const [gradingStudentId, setGradingStudentId] = useState<string | null>(null);
  const [gradingAssignmentId, setGradingAssignmentId] = useState<string | null>(null);
  const [gradingMarks, setGradingMarks] = useState<string>("");
  const [gradingFeedback, setGradingFeedback] = useState<string>("");

  const handleSupervisorLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (supervisorInputPass === "64a93s") {
      setIsSupervisorAuthenticated(true);
      setSupervisorError("");
      setSupervisorInputPass("");
    } else {
      setSupervisorError("عذراً، كلمة المرور غير صحيحة للولوج بصلاحية مشرف أكاديمي!");
    }
  };

  const handleSupervisorLogout = () => {
    setIsSupervisorAuthenticated(false);
    setIsSupervisorMode(false);
    setSupEditingTeacherId(null);
    clearSupForm();
  };

  const clearSupForm = () => {
    setSupTeacherName("");
    setSupTeacherSubject("");
    setSupTeacherGrades([]);
    setSupTeacherBio("");
    setSupTeacherImageUrl("");
    setSupTeacherPhone("");
    setSupTeacherEmail("");
    setSupTeacherRole("مدرس مادة");
  };

  const handleSupAddOrEditTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supTeacherName.trim() || !supTeacherSubject.trim()) {
      alert("يرجى ملء الاسم ومادة التخصص.");
      return;
    }

    if (supEditingTeacherId) {
      // Edit Teacher
      const updated = teachersList.map(t => {
        if (t.id === supEditingTeacherId) {
          return {
            ...t,
            name: supTeacherName.trim(),
            subject: supTeacherSubject.trim(),
            grades: supTeacherGrades.length > 0 ? supTeacherGrades : ["الصف الأول الابتدائي"],
            bio: supTeacherBio.trim(),
            imageUrl: supTeacherImageUrl.trim() || t.imageUrl,
            phone: supTeacherPhone.trim(),
            email: supTeacherEmail.trim(),
            role: supTeacherRole
          };
        }
        return t;
      });
      setTeachersList(updated);
      saveDataWithServerSync("school_teachers", updated);
      setSupSuccessMessage("✓ تم تعديل بيانات المعلم بنجاح في قاعدة البيانات والخادم.");
    } else {
      // Add Teacher
      const newTeacherId = "teach-" + (teachersList.length + 101);
      const newTeacherObj: Teacher = {
        id: newTeacherId,
        name: supTeacherName.trim(),
        subject: supTeacherSubject.trim(),
        grades: supTeacherGrades.length > 0 ? supTeacherGrades : ["الصف الأول الابتدائي"],
        imageUrl: supTeacherImageUrl.trim() || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200",
        bio: supTeacherBio.trim() || "معلم متميز وذو خبرة أكاديمية تربوية.",
        role: supTeacherRole,
        phone: supTeacherPhone.trim(),
        email: supTeacherEmail.trim() || `${Date.now()}@amal.edu.ye`,
        academicId: "ACAD" + (teachersList.length + 9000),
        lessons: [],
        assignments: []
      };
      const updated = [...teachersList, newTeacherObj];
      setTeachersList(updated);
      saveDataWithServerSync("school_teachers", updated);
      setSupSuccessMessage("✓ تم تسجيل وإضافة المعلم الجديد بنجاح للكادر.");
    }

    clearSupForm();
    setSupEditingTeacherId(null);
    setTimeout(() => setSupSuccessMessage(""), 4000);
  };

  const handleSupStartEdit = (teacher: Teacher) => {
    setSupEditingTeacherId(teacher.id);
    setSupTeacherName(teacher.name);
    setSupTeacherSubject(teacher.subject);
    setSupTeacherGrades(teacher.grades);
    setSupTeacherBio(teacher.bio || "");
    setSupTeacherImageUrl(teacher.imageUrl || "");
    setSupTeacherPhone(teacher.phone || "");
    setSupTeacherEmail(teacher.email || "");
    setSupTeacherRole(teacher.role || "مدرس مادة");
  };

  const handleSupDeleteTeacher = (id: string) => {
    if (window.confirm("هل أنت متأكد تماماً من حذف هذا المعلم من الكادر المدرسي بصفة نهائية؟")) {
      const updated = teachersList.filter(t => t.id !== id);
      setTeachersList(updated);
      saveDataWithServerSync("school_teachers", updated);
      setSupSuccessMessage("✘ تم حذف المعلم المطلوب من قاعدة البيانات بنجاح.");
      setTimeout(() => setSupSuccessMessage(""), 4000);
    }
  };

  const handleSelectTeacher = (id: string) => {
    const teach = teachersList.find(t => t.id === id);
    if (teach) {
      setActiveTeacher(teach);
      // Initialize default attendance checkboxes
      const currentGradeStudents = students.filter(s => s.grade === selectedGrade);
      const defaultStatuses: Record<string, "حاضر" | "غائب" | "إجازة"> = {};
      currentGradeStudents.forEach(s => {
        defaultStatuses[s.id] = "حاضر";
      });
      setAttendanceStatuses(defaultStatuses);
    }
  };

  const handleCreateLesson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTeacher || !lessonTitle.trim() || !lessonDesc.trim()) return;

    const newLesson = {
      id: "l-" + (activeTeacher.lessons.length + 101),
      title: lessonTitle.trim(),
      grade: lessonClass,
      date: new Date().toISOString().split("T")[0],
      description: lessonDesc.trim()
    };

    // Update active teacher lessons list
    const updatedTeachers = teachersList.map(t => {
      if (t.id === activeTeacher.id) {
        return {
          ...t,
          lessons: [newLesson, ...t.lessons]
        };
      }
      return t;
    });

    setTeachersList(updatedTeachers);
    saveData("school_teachers", updatedTeachers);
    
    // Select updated teacher object for local state view
    const updatedActive = updatedTeachers.find(t => t.id === activeTeacher.id);
    if (updatedActive) setActiveTeacher(updatedActive);

    setLessonTitle("");
    setLessonDesc("");
    setLessonAddedSuccess(true);
    setTimeout(() => {
      setLessonAddedSuccess(false);
    }, 4000);
  };

  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTeacher || !assignTitle.trim() || !assignDueDate) return;

    const savedStudents = getSavedData<Student[]>("school_students", initialStudents);
    
    const newAssignment = {
      id: "as-teach-" + (activeTeacher.assignments.length + 201),
      subject: activeTeacher.subject,
      title: assignTitle.trim(),
      dueDate: assignDueDate,
      status: "pending" as const
    };

    // Broadcast assignments to ALL students under lessons/grade class!
    const updatedStudents = savedStudents.map(student => {
      if (activeTeacher.grades.includes(student.grade)) {
        return {
          ...student,
          assignments: [newAssignment, ...student.assignments]
        };
      }
      return student;
    });

    // Update teacher assignments log too
    const updatedTeachers = teachersList.map(t => {
      if (t.id === activeTeacher.id) {
        return {
          ...t,
          assignments: [
            ...t.assignments,
            {
              id: newAssignment.id,
              title: newAssignment.title,
              subject: newAssignment.subject,
              grade: studentGradeFilter(t),
              dueDate: newAssignment.dueDate,
              maxDegrees: 10
            }
          ]
        };
      }
      return t;
    });

    setStudents(updatedStudents);
    saveData("school_students", updatedStudents);

    setTeachersList(updatedTeachers);
    saveData("school_teachers", updatedTeachers);

    // Refresh teacher UI
    const updatedActive = updatedTeachers.find(t => t.id === activeTeacher.id);
    if (updatedActive) setActiveTeacher(updatedActive);

    setAssignTitle("");
    setAssignDueDate("");
    setAssignAddedSuccess(true);
    setTimeout(() => {
      setAssignAddedSuccess(false);
    }, 4000);
  };

  const studentGradeFilter = (t: Teacher) => {
    return t.grades.length > 0 ? t.grades[0] : "الصف السادس الابتدائي";
  };

  const recordAttendance = () => {
    if (!activeTeacher) return;

    const savedStudents = getSavedData<Student[]>("school_students", initialStudents);
    const updatedStudents = savedStudents.map(s => {
      if (s.grade === selectedGrade && attendanceStatuses[s.id]) {
        const currentStatus = attendanceStatuses[s.id];
        
        // Append history log
        const newHist = { date: attendanceDate, status: currentStatus };
        const pastHist = s.attendance.history.filter(h => h.date !== attendanceDate);
        
        // Compute new numbers
        let addedPresent = currentStatus === "حاضر" ? 1 : 0;
        let addedAbsent = currentStatus === "غائب" ? 1 : 0;
        let addedExcused = currentStatus === "إجازة" ? 1 : 0;

        return {
          ...s,
          attendance: {
            present: s.attendance.present + addedPresent,
            absent: s.attendance.absent + addedAbsent,
            excused: s.attendance.excused + addedExcused,
            history: [newHist, ...pastHist]
          }
        };
      }
      return s;
    });

    setStudents(updatedStudents);
    saveData("school_students", updatedStudents);
    
    setAttendanceSavedSuccess(true);
    setTimeout(() => {
      setAttendanceSavedSuccess(false);
    }, 3000);
  };

  const handleCreateDailyHomework = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTeacher || !dailyTitle.trim()) return;

    const raw = getSavedData<any[]>("school_daily_homeworks", []);
    const now = Date.now();
    
    const newDailyHw = {
      id: "dhw-" + Date.now() + "-" + Math.floor(Math.random() * 1000),
      teacherId: activeTeacher.id,
      teacherName: activeTeacher.name,
      subject: dailySubject.trim() || activeTeacher.subject,
      title: dailyTitle.trim(),
      targetGrade: dailyGrade,
      createdAt: now
    };

    const updated = [newDailyHw, ...raw.filter(hw => (now - hw.createdAt) < 24 * 60 * 60 * 1000)];
    setDailyHomeworks(updated);
    saveData("school_daily_homeworks", updated);

    setDailyTitle("");
    // We can also default or keep dailySubject
    setDailyHomeworkAddedSuccess(true);
    setTimeout(() => {
      setDailyHomeworkAddedSuccess(false);
    }, 4500);
  };

  const handleDeleteDailyHomework = (hwId: string) => {
    const raw = getSavedData<any[]>("school_daily_homeworks", []);
    const updated = raw.filter(hw => hw.id !== hwId);
    setDailyHomeworks(updated);
    saveData("school_daily_homeworks", updated);
  };

  const startGrading = (sId: string, aId: string) => {
    setGradingStudentId(sId);
    setGradingAssignmentId(aId);
    setGradingMarks("");
    setGradingFeedback("");
  };

  const submitGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gradingStudentId || !gradingAssignmentId || !gradingMarks.trim()) return;

    const savedStudents = getSavedData<Student[]>("school_students", initialStudents);
    const updatedStudents = savedStudents.map(student => {
      if (student.id === gradingStudentId) {
        const updatedAssigns = student.assignments.map(a => {
          if (a.id === gradingAssignmentId) {
            return {
              ...a,
              status: "graded" as const,
              grade: gradingMarks.trim(),
              feedback: gradingFeedback.trim()
            };
          }
          return a;
        });

        return {
          ...student,
          assignments: updatedAssigns
        };
      }
      return student;
    });

    setStudents(updatedStudents);
    saveData("school_students", updatedStudents);

    setGradingStudentId(null);
    setGradingAssignmentId(null);
  };

  return (
    <div id="teacher-portal-section" className="space-y-12 pb-12 text-right">
      
      {!activeTeacher ? (
        isSupervisorMode ? (
          isSupervisorAuthenticated ? (
            /* SUPERVISOR PANEL - ADMIN ACCOUNT MANAGEMENTS */
            <section className="space-y-8 animate-fade-in text-right">
              <div className="bg-gradient-to-r from-indigo-850 to-indigo-700 bg-indigo-900 border border-indigo-950 text-white rounded-3xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4 text-right">
                  <div className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center text-xl font-bold">
                    🛡️
                  </div>
                  <div>
                    <h2 className="text-xl font-bold font-display">لوحة تحكم المشرفين الأكاديميين وإدارة الكادر</h2>
                    <p className="text-xs text-indigo-200">إضافة وتعديل وحذف بيانات المعلمين بالمنصة والتحكم بقوائم التدريس</p>
                  </div>
                </div>

                <button
                  onClick={handleSupervisorLogout}
                  className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-4 py-2 rounded-xl text-xs font-bold transition duration-150"
                >
                  الخروج من لوحة الإشراف
                </button>
              </div>

              {supSuccessMessage && (
                <div className="bg-emerald-50 border border-emerald-250 text-emerald-800 p-3.5 rounded-xl text-xs font-bold text-center">
                  {supSuccessMessage}
                </div>
              )}

              <div className="grid lg:grid-cols-12 gap-8 items-start">
                {/* Form (5 cols) */}
                <div className="lg:col-span-12 xl:col-span-5 bg-white border border-slate-100 p-6 rounded-3xl shadow-sm space-y-4">
                  <h3 className="font-bold text-slate-800 font-display text-sm border-b border-slate-150 pb-2">
                    {supEditingTeacherId ? "✏️ تعديل بيانات المعلم النشط" : "➕ إضافة معلم جديد للكادر"}
                  </h3>

                  <form onSubmit={handleSupAddOrEditTeacher} className="space-y-4 text-right">
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">اسم المعلم رباعياً:</label>
                      <input
                        type="text"
                        required
                        value={supTeacherName}
                        onChange={(e) => setSupTeacherName(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-right"
                        placeholder="مثال: أ. محمد عبدالله اليماني"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">مادة التخصص الكبرى:</label>
                      <input
                        type="text"
                        required
                        value={supTeacherSubject}
                        onChange={(e) => setSupTeacherSubject(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-right"
                        placeholder="مثال: الرياضيات، العلوم والأحياء"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">الصفة الوظيفية التربوية:</label>
                      <input
                        type="text"
                        value={supTeacherRole}
                        onChange={(e) => setSupTeacherRole(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-right"
                        placeholder="مثال: مدرس مادة، مشرف أكاديمي، وكيل"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">رقم هاتف المعلم:</label>
                      <input
                        type="text"
                        value={supTeacherPhone}
                        onChange={(e) => setSupTeacherPhone(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-left font-mono"
                        placeholder="+967770000000"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">صورة المعلم (عبر رابط URL):</label>
                      <input
                        type="text"
                        value={supTeacherImageUrl}
                        onChange={(e) => setSupTeacherImageUrl(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-left font-mono"
                        placeholder="https://images.unsplash.com/photo-..."
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">البريد الإلكتروني المهني:</label>
                      <input
                        type="email"
                        value={supTeacherEmail}
                        onChange={(e) => setSupTeacherEmail(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-left font-mono"
                        placeholder="teacher@amal-ye.com"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 font-bold block">نبذة مختصرة من سيرة المعلم:</label>
                      <textarea
                        rows={3}
                        value={supTeacherBio}
                        onChange={(e) => setSupTeacherBio(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                        placeholder="مستوى التعليم، عدد سنوات الخبرة، المهارات الأساسية..."
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-[11px] text-slate-600 font-bold block">الفصول والصفوف المسند تدريسها:</label>
                      <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200 max-h-44 overflow-y-auto text-right">
                        {ALL_SCHOOL_GRADES.map(grade => {
                          const checked = supTeacherGrades.includes(grade);
                          return (
                            <label key={grade} className="flex items-center gap-2 text-[10px] text-slate-700 font-bold cursor-pointer hover:bg-slate-150 p-1 rounded">
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => {
                                  if (checked) {
                                    setSupTeacherGrades(prev => prev.filter(g => g !== grade));
                                  } else {
                                    setSupTeacherGrades(prev => [...prev, grade]);
                                  }
                                }}
                                className="rounded border-slate-300 text-primary h-3 w-3"
                              />
                              <span>{grade}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        type="submit"
                        className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-xl text-xs transition"
                      >
                        {supEditingTeacherId ? "تطبيق تعديلات الحساب" : "إضافة المعلم للكادر"}
                      </button>
                      {supEditingTeacherId && (
                        <button
                          type="button"
                          onClick={() => {
                            setSupEditingTeacherId(null);
                            clearSupForm();
                          }}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-2.5 px-4 rounded-xl text-xs transition"
                        >
                          إلغاء التعديل
                        </button>
                      )}
                    </div>
                  </form>
                </div>

                {/* Teachers Database Table/Cards List (7 cols) */}
                <div className="lg:col-span-12 xl:col-span-7 bg-white border border-slate-100 p-6 rounded-3xl shadow-sm space-y-4">
                  <h3 className="font-bold text-slate-800 font-display text-sm border-b border-slate-150 pb-2 flex items-center gap-1.5 justify-start">
                    <Users className="w-5 h-5 text-indigo-600" />
                    <span>قائمة المعلمين المدرجين حالياً بالرصيد ({teachersList.length} معلم)</span>
                  </h3>

                  <div className="space-y-4 max-h-[550px] overflow-y-auto pr-1">
                    {teachersList.map(teacher => (
                      <div key={teacher.id} className="p-4 bg-slate-50 hover:bg-slate-100/50 rounded-2xl border border-slate-100 flex items-center justify-between gap-4 transition">
                        <div className="flex items-center gap-3 text-right">
                          <img
                            src={teacher.imageUrl || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200"}
                            alt={teacher.name}
                            referrerPolicy="no-referrer"
                            className="w-11 h-11 rounded-full object-cover border border-slate-200 shrink-0"
                          />
                          <div className="space-y-1">
                            <h4 className="font-bold text-slate-800 text-xs leading-none">{teacher.name}</h4>
                            <p className="text-[10px] text-indigo-600 font-bold">{teacher.role || "مدرس مادة"} | مادة: {teacher.subject}</p>
                            <p className="text-[10px] text-slate-400 font-mono">الرمز: {teacher.academicId || teacher.id}</p>
                            <p className="text-[10px] text-slate-500 max-w-sm line-clamp-1">الفصول: {teacher.grades.join("، ")}</p>
                          </div>
                        </div>

                        <div className="flex gap-2 shrink-0">
                          <button
                            onClick={() => handleSupStartEdit(teacher)}
                            className="p-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl transition"
                            title="تعديل البيانات"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleSupDeleteTeacher(teacher.id)}
                            className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl transition"
                            title="حذف نهائي"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          ) : (
            /* PASSWORD CHECKER FOR ACADEMIC SUPERVISORS BLOCK */
            <section className="max-w-md mx-auto bg-white border border-slate-100 p-8 rounded-3xl shadow-sm space-y-6">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                  🛡️
                </div>
                <h3 className="font-bold text-slate-805 font-display">منطقة المشرفين الأكاديميين المعتمدين</h3>
                <p className="text-[11px] text-slate-400">يرجى تأكيد الرقم السري للتحكم في شؤون المعلمين</p>
              </div>

              <form onSubmit={handleSupervisorLogin} className="space-y-4 text-right">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-600 font-bold block text-right">كلمة مرور لوحة تحكم المشرفين:</label>
                  <input
                    type="password"
                    value={supervisorInputPass}
                    onChange={(e) => setSupervisorInputPass(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-center text-sm font-mono tracking-widest focus:outline-none focus:border-indigo-400"
                    required
                    placeholder="••••••"
                  />
                </div>

                {supervisorError && (
                  <p className="text-xs text-rose-600 bg-rose-50 p-2.5 rounded-lg text-center font-bold">{supervisorError}</p>
                )}

                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 bg-slate-900 hover:bg-slate-805 text-white font-bold py-2.5 rounded-xl text-xs transition"
                  >
                    التحقق والدخول
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsSupervisorMode(false)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-2.5 px-4 rounded-xl text-xs transition"
                  >
                    إلغاء الرجوع
                  </button>
                </div>
              </form>
            </section>
          )
        ) : (
          /* TRADITIONAL TEACHER SELECTION */
          <section className="max-w-xl mx-auto space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-blue-50 text-blue-700 border border-blue-100 rounded-full flex items-center justify-center mx-auto text-2xl font-bold">
                👨‍🏫
              </div>
              <h2 className="text-xl font-bold text-slate-900 font-display">منصة المعلمين والمشرفين الأكاديميين</h2>
              <p className="text-xs text-slate-500">اختر المعلم للولوج السريع ورصد الحضور، وضع الواجبات ووضع العلامات للطلاب.</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {teachersList.map((teacher) => (
                <div 
                  key={teacher.id}
                  onClick={() => handleSelectTeacher(teacher.id)}
                  className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm cursor-pointer hover:border-primary/40 hover:-translate-y-0.5 transition text-right"
                >
                  <div className="space-y-3">
                    <span className="bg-primary/10 text-primary text-[10px] font-bold px-2.5 py-1 rounded">مادة: {teacher.subject}</span>
                    <h3 className="font-bold text-slate-800 text-sm leading-none">{teacher.name}</h3>
                    <p className="text-slate-400 text-xs line-clamp-1 leading-none">الصفوف: {teacher.grades.join("، ")}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-slate-100 flex justify-center">
              <button
                onClick={() => setIsSupervisorMode(true)}
                className="text-[11px] font-extrabold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 border border-indigo-200/55 px-5 py-2.5 rounded-2xl transition flex items-center gap-1.5 shadow-sm"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>الولوج إلى لوحة إدارة المشرفين الأكاديميين 🛡️</span>
              </button>
            </div>
          </section>
        )
      ) : (
        <div className="space-y-8 animate-fade-in">
          {/* Welcome teacher banner */}
          <div className="bg-gradient-to-r from-teal-750 to-emerald-700 bg-primary text-white rounded-3xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-right">
              <div className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center text-xl font-bold">
                🏫
              </div>
              <div>
                <h2 className="text-xl font-bold font-display">{activeTeacher.name}</h2>
                <p className="text-xs text-blue-150">تخصص: {activeTeacher.subject} | الكادر التعليمي</p>
              </div>
            </div>

            <button
              onClick={() => setActiveTeacher(null)}
              className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-4 py-2 rounded-xl text-xs font-bold transition duration-150"
            >
              الرجوع لاختيار معلم آخر
            </button>
          </div>

          <div className="grid lg:grid-cols-12 gap-8">
            {/* Left panels (8 cols) */}
            <div className="lg:col-span-8 space-y-8">
              
              {/* 1. Register Student Daily Attendance */}
              <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-6">
                <div className="flex items-center gap-3 justify-start pb-2 border-b border-slate-50">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                    <UserCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 font-display">رصد غياب وحضور الطلاب اليومي</h3>
                    <p className="text-[10px] text-slate-400">اختر الفصل واليوم لتحديث سجلاتهم بنقرة واحدة</p>
                  </div>
                </div>

                {/* Filters */}
                <div className="grid sm:grid-cols-2 gap-4 text-xs font-semibold">
                  <div className="space-y-1">
                    <label className="text-slate-600">الصف المستهدَف رصده اليوم:</label>
                    <select
                      value={selectedGrade}
                      onChange={(e) => setSelectedGrade(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    >
                      {activeTeacher.grades.map((gr, idx) => (
                        <option key={idx} value={gr}>{gr}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-600">تاريخ اليوم لرصد الحضور:</label>
                    <input
                      type="date"
                      value={attendanceDate}
                      onChange={(e) => setAttendanceDate(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-left"
                    />
                  </div>
                </div>

                {/* Kids Attendance Grid table */}
                <div className="space-y-3 pt-2">
                  {students.filter(s => s.grade === selectedGrade).map(student => (
                    <div key={student.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs font-semibold">
                      <span className="text-slate-800">{student.name}</span>
                      
                      <div className="flex gap-2">
                        {(["حاضر", "غائب", "إجازة"] as const).map((status) => (
                          <button
                            key={status}
                            type="button"
                            onClick={() => setAttendanceStatuses(prev => ({
                              ...prev,
                              [student.id]: status
                            }))}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                              (attendanceStatuses[student.id] || "حاضر") === status
                                ? status === "حاضر" ? "bg-emerald-600 text-white" : status === "غائب" ? "bg-rose-600 text-white" : "bg-amber-600 text-white"
                                : "bg-white text-slate-500 border border-slate-200 hover:bg-slate-100"
                            }`}
                          >
                            {status}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {attendanceSavedSuccess && (
                  <p className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-100 p-2.5 rounded-lg">✓ تم تحديث الغياب والحضور بجدول تاريخ {attendanceDate} بنجاح.</p>
                )}

                <div className="flex justify-end">
                  <button
                    onClick={recordAttendance}
                    className="bg-primary hover:bg-slate-850 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>حفظ الحضور ورصد الغيابات</span>
                  </button>
                </div>
              </div>

              {/* 2. Grading Task Center */}
              <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-6">
                <div className="flex items-center gap-3 justify-start pb-2 border-b border-slate-50">
                  <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 font-display">مراجعة الواجبات المرفوعة ووضع العلامات</h3>
                    <p className="text-[10px] text-slate-400">تقييم حلول الطلاب وكتابة ملاحظات تربوية مشجعة</p>
                  </div>
                </div>

                {/* List of submitted student homework */}
                <div className="space-y-4">
                  {students.filter(student => activeTeacher.grades.includes(student.grade)).some(s => s.assignments.some(a => a.status === "submitted" || a.status === "graded")) ? (
                    students.filter(student => activeTeacher.grades.includes(student.grade)).map(student => 
                      student.assignments.filter(a => a.status === "submitted" || a.status === "graded").map(assign => (
                        <div key={assign.id} className="p-4 bg-slate-50/60 rounded-xl border border-slate-100 flex flex-col sm:flex-row justify-between gap-4 text-xs font-semibold">
                          <div className="space-y-1">
                            <span className="bg-indigo-50 text-indigo-750 text-[10px] px-2 py-0.5 rounded font-black">{student.name}</span>
                            <h4 className="font-bold text-slate-800 pt-1">الواجب المرفوع: {assign.title}</h4>
                            {assign.feedback && <p className="text-[10px] text-amber-800 bg-amber-50 p-2 rounded mt-2">{assign.feedback}</p>}
                          </div>

                          <div className="shrink-0 flex items-center gap-2">
                            {assign.status === "submitted" ? (
                              <button
                                onClick={() => startGrading(student.id, assign.id)}
                                className="bg-primary text-white hover:bg-slate-800 px-4 py-2 rounded-lg text-xs transition"
                              >
                                تقييم ووضع علامة
                              </button>
                            ) : (
                              <span className="bg-emerald-50 text-emerald-800 font-bold px-3 py-1.5 rounded-full block text-xs">العلامة: {assign.grade}</span>
                            )}
                          </div>
                        </div>
                      ))
                    )
                  ) : (
                    <p className="text-xs text-slate-400 italic">لا توجد واجبات مرفوعة تنتظر التقييم حالياً من طلابك.</p>
                  )}
                </div>

                {/* Grading panel */}
                {gradingStudentId && gradingAssignmentId && (
                  <form onSubmit={submitGrade} className="bg-amber-50/20 border-2 border-amber-200 p-5 rounded-2xl text-right space-y-4 animate-fade-in">
                    <h4 className="font-extrabold text-[13px] text-amber-800">وضع درجة وعلامة واجب الطالب:</h4>
                    
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-705 block">الدرجة النهائية (مثال: 9/10 أو 15/15):</label>
                        <input
                          type="text"
                          required
                          placeholder="مثال: 10/10"
                          value={gradingMarks}
                          onChange={(e) => setGradingMarks(e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded-lg text-center"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-705 block">تقديم تلميحات/ملاحظات توجيهية:</label>
                        <input
                          type="text"
                          placeholder="مثال: جهد متميز ورسم دقيق جداً للمجسم!"
                          value={gradingFeedback}
                          onChange={(e) => setGradingFeedback(e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded-lg"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2 justify-end">
                      <button 
                        type="button" 
                        onClick={() => { setGradingStudentId(null); setGradingAssignmentId(null); }}
                        className="bg-white border rounded-lg px-3 py-1 text-xs"
                      >
                        إلغاء
                      </button>
                      <button 
                        type="submit" 
                        className="bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg px-4 py-1 text-xs"
                      >
                        اعتماد الدرجة وإرسالها للطالب
                      </button>
                    </div>
                  </form>
                )}
              </div>

            </div>

            {/* Right Form Panels (4 cols) */}
            <div className="lg:col-span-4 space-y-6">
              
              {/* Add interactive dynamic Lesson overview */}
              <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
                <h4 className="font-bold text-slate-800 font-display text-sm pb-1 border-b border-slate-50 flex items-center gap-1">
                  <Plus className="w-5 h-5 text-emerald-600" />
                  <span>رفع وتعميم درس تعليمي جديد</span>
                </h4>

                <form onSubmit={handleCreateLesson} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-600 font-bold">عنوان الدرس مفسراً:</label>
                    <input
                      type="text"
                      required
                      placeholder="الأفعال الخمسة، الكسور العشرية..."
                      value={lessonTitle}
                      onChange={(e) => setLessonTitle(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-250 rounded-lg text-xs"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-600 font-bold">الفصل الدراسي المتلقي:</label>
                    <select
                      value={lessonClass}
                      onChange={(e) => setLessonClass(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                    >
                      {activeTeacher.grades.map((cl, i) => (
                        <option key={i} value={cl}>{cl}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-600 font-bold">شرح وتلخيص وبوابات المذاكرة المفتوحة:</label>
                    <textarea
                      required
                      rows={3}
                      placeholder="اكتب خلاصة محتويات الدرس أو تلميحات المذاكرة المفيدة..."
                      value={lessonDesc}
                      onChange={(e) => setLessonDesc(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-250 rounded-lg text-xs"
                    />
                  </div>

                  {lessonAddedSuccess && (
                    <p className="text-xs text-emerald-800 bg-emerald-50 p-2 rounded">✓ تم رفع الدرس وتعميمه بنجاح.</p>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-xs transition"
                  >
                    بث ونشر الدرس للطلاب
                  </button>
                </form>
              </div>

              {/* 24h Temporary Daily Homework System */}
              <div className="bg-gradient-to-br from-[#0284c7]/5 to-sky-50 border border-[#0ea5e9]/40 p-6 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center gap-2 justify-start pb-1.5 border-b border-sky-100">
                  <div className="p-1.5 bg-[#0284c7]/15 text-[#0284c7] rounded-lg">
                    <Clock className="w-5 h-5 text-[#0284c7] animate-pulse" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-[#0369a1] font-display text-sm">بث واجب يومي مؤقت (صلاحية 24 ساعة)</h4>
                    <p className="text-[10px] text-sky-700">تختفي تلقائياً فور فوات زمن الصلاحية الكامل (24 ساعة بتقدير رقمي)</p>
                  </div>
                </div>

                <form onSubmit={handleCreateDailyHomework} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-705 font-bold">1. اختر الصف الدراسي (الفصل المستهدف):</label>
                    <select
                      value={dailyGrade}
                      onChange={(e) => setDailyGrade(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-[#0284c7]/50"
                    >
                      {ALL_SCHOOL_GRADES.map((cl, i) => (
                        <option key={i} value={cl}>{cl}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-705 font-bold">2. مادة التكليف بالواجب:</label>
                    <input
                      type="text"
                      placeholder="امثلة: الرياضيات، الإملاء، العلوم المقارنة..."
                      value={dailySubject}
                      onChange={(e) => setDailySubject(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-[#0284c7]/50"
                    />
                    <p className="text-[9px] text-slate-400">تلقائياً سيتم اعتماد مادة تخصصكم: <strong>{activeTeacher.subject}</strong></p>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-705 font-bold">3. نص وتفاصيل الواجب المطلوبة:</label>
                    <textarea
                      required
                      rows={3}
                      placeholder="اكتب التوجيهات والواجب، مثال: قراءة سورة الملك وحل أسئلة الشرح صفحة 15 كاملة..."
                      value={dailyTitle}
                      onChange={(e) => setDailyTitle(e.target.value)}
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-[#0284c7]/50"
                    />
                  </div>

                  {dailyHomeworkAddedSuccess && (
                     <p className="text-xs text-emerald-800 bg-emerald-50 p-2.5 rounded-lg border border-emerald-100 font-bold">✓ تم بث التكليف اليومي للصف {dailyGrade} بنجاح! متاح 24 ساعة.</p>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-[#0284c7] hover:bg-[#0369a1] text-white font-bold py-2.5 rounded-xl text-xs transition-all duration-150 flex items-center justify-center gap-1 shadow-sm shrink-0 cursor-pointer"
                  >
                    <span>بث تفاصيل الواجب المؤقت فوريًا</span>
                    <Clock className="w-4 h-4 text-white" />
                  </button>
                </form>
              </div>

              {/* Monitor Active Published Temporary Daily Homeworks */}
              <div className="bg-white border border-slate-150 p-6 rounded-2xl shadow-sm space-y-4">
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-50">
                  <h4 className="font-extrabold text-slate-800 font-display text-xs flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                    <span>الواجبات اليومية النشطة بالمدرسة</span>
                  </h4>
                  <span className="bg-slate-100 text-slate-650 text-[9px] font-bold px-2 py-0.5 rounded-full">
                    فوات &lt; 24 ساعة
                  </span>
                </div>

                <div className="space-y-3 max-h-[290px] overflow-y-auto">
                  {dailyHomeworks.length === 0 ? (
                    <div className="text-center py-4 text-slate-400 text-xs italic">
                      لا توجد واجبات مؤقتة نشطة تم بثها حالياً.
                    </div>
                  ) : (
                    dailyHomeworks.map((hw) => {
                      const elapsed = Date.now() - hw.createdAt;
                      const hoursLeft = Math.max(0, 24 - elapsed / (1000 * 60 * 60));
                      const formattedHours = Math.floor(hoursLeft);
                      const formattedMinutes = Math.floor((hoursLeft % 1) * 60);

                      return (
                        <div key={hw.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 text-right space-y-2 relative">
                          <button
                            type="button"
                            onClick={() => handleDeleteDailyHomework(hw.id)}
                            className="absolute left-2.5 top-2.5 text-rose-500 hover:text-rose-700 text-[10px] font-extrabold flex items-center gap-0.5 cursor-pointer"
                            title="حذف الواجب من العرض تلقائياً"
                          >
                            <span>حذف 🗑️</span>
                          </button>
                          
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="bg-emerald-50 text-emerald-800 text-[9px] font-extrabold px-1.5 py-0.5 rounded border border-emerald-150">
                                {hw.targetGrade}
                              </span>
                              <span className="bg-sky-50 text-[#0284c7] text-[9px] font-extrabold px-1.5 py-0.5 rounded border border-sky-100">
                                {hw.subject}
                              </span>
                            </div>
                            
                            <p className="font-bold text-slate-850 text-xs leading-normal pt-1">{hw.title}</p>
                            
                            <div className="flex items-center justify-between pt-1 text-[9.5px] text-slate-450">
                              <span>المعلم: {hw.teacherName}</span>
                              <span className="text-amber-600 font-extrabold flex items-center gap-0.5 bg-amber-50 px-1.5 py-0.5 rounded">
                                ⏱️ متبقي: {formattedHours}س و {formattedMinutes}د
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Add homework assignment */}
              <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
                <h4 className="font-bold text-slate-800 font-display text-sm pb-1 border-b border-slate-50 flex items-center gap-1">
                  <Plus className="w-5 h-5 text-indigo-600" />
                  <span>تأطير وتعميم واجب جديد</span>
                </h4>

                <form onSubmit={handleCreateAssignment} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-600 font-bold">تفاصيل الواجب المطلوبة:</label>
                    <input
                      type="text"
                      required
                      placeholder="اسم الفرض وجمل الإعراب أو المسائل المطلوبة..."
                      value={assignTitle}
                      onChange={(e) => setAssignTitle(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-600 font-bold">تاريخ الاستحقاق النهائي:</label>
                    <input
                      type="date"
                      required
                      value={assignDueDate}
                      onChange={(e) => setAssignDueDate(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-250 rounded-lg text-xs font-mono text-left"
                    />
                  </div>

                  {assignAddedSuccess && (
                    <p className="text-xs text-indigo-800 bg-indigo-50 p-2 rounded">✓ تم تعميم ونشر الواجب على الطلاب بنجاح.</p>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-primary hover:bg-slate-800 text-white font-bold py-2 rounded-xl text-xs transition duration-150"
                  >
                    بث ونشر الواجب النشط
                  </button>
                </form>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
