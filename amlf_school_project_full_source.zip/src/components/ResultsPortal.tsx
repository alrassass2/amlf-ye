import React, { useState, useEffect, useRef } from "react";
import { 
  Search, 
  Award, 
  Printer, 
  Download, 
  BookOpen, 
  AlertCircle, 
  Sparkles, 
  Upload, 
  FileSpreadsheet, 
  CheckCircle,
  QrCode,
  X,
  Camera,
  RefreshCw,
  Lock,
  Unlock,
  Trash2,
  Plus,
  Clipboard,
  Check,
  Settings,
  Database,
  Grid,
  Image as ImageIcon,
  Link as LinkIcon,
  ArrowUp,
  ArrowDown
} from "lucide-react";
import * as XLSX from "xlsx";
import jsQR from "jsqr";

// 12 Grades corresponding to the 12 sheets required
const GRADE_NAMES = [
  "الصف الأول الأساسي",
  "الصف الثاني الأساسي",
  "الصف الثالث الأساسي",
  "الصف الرابع الأساسي",
  "الصف الخامس الأساسي",
  "الصف السادس الأساسي",
  "الصف السابع الأساسي",
  "الصف الثامن الأساسي",
  "الصف التاسع الأساسي",
  "الصف الأول الثانوي",
  "الصف الثاني الثانوي",
  "الصف الثالث الثانوي"
];

interface ResultRow {
  [key: string]: string | number;
}

const DEFAULT_RESULTS: Record<string, ResultRow[]> = {
  "الصف الأول الأساسي": [
    { "رقم الطالب": "103", "اسم الطالب": "يوسف محمد الكردي", "اللغة العربية": 85, "الرياضيات والعد": 90, "الاستكشاف والرسم": 98, "المجموع": 273, "التقدير العام": "ممتاز" }
  ],
  "الصف الثاني الأساسي": [
    { "رقم الطالب": "201", "اسم الطالب": "خالد وليد العامري", "اللغة العربية": 92, "الرياضيات": 88, "العلوم المبسطة": 90, "المجموع": 270, "التقدير العام": "ممتاز" }
  ],
  "الصف الثالث الأساسي": [
    { "رقم الطالب": "301", "اسم الطالب": "نورة سالم الهاشمي", "اللغة العربية": 95, "الرياضيات": 94, "العلوم": 92, "المجموع": 281, "التقدير العام": "ممتاز مرتفع" }
  ],
  "الصف الرابع الأساسي": [
    { "رقم الطالب": "401", "اسم الطالب": "علي حسن غانم", "اللغة العربية": 78, "الرياضيات": 82, "العلوم": 80, "المجموع": 240, "التقدير العام": "جيد جداً" }
  ],
  "الصف الخامس الأساسي": [
    { "رقم الطالب": "501", "اسم الطالب": "منيرة عبد الله صالح", "اللغة العربية": 89, "الرياضيات": 91, "العلوم": 87, "المجموع": 267, "التقدير العام": "ممتاز" }
  ],
  "الصف السادس الأساسي": [
    { "رقم الطالب": "101", "اسم الطالب": "عمر أحمد اليوسف", "اللغة العربية": 100, "الرياضيات": 94, "العلوم العامة": 92, "اللغة الإنجليزية": 87, "المجموع": 373, "التقدير العام": "ممتاز مرتفع" }
  ],
  "الصف السابع الأساسي": [
    { "رقم الطالب": "701", "اسم الطالب": "فيصل أحمد العتيبي", "اللغة العربية": 88, "الرياضيات": 85, "العلوم": 84, "المجموع": 257, "التقدير العام": "جيد جداً" }
  ],
  "الصف الثامن الأساسي": [
    { "رقم الطالب": "801", "اسم الطالب": "شهد عبد الرحمن الشهري", "اللغة العربية": 94, "الرياضيات": 89, "العلوم": 91, "المجموع": 274, "التقدير العام": "ممتاز" }
  ],
  "الصف التاسع الأساسي": [
    { "رقم الطالب": "102", "اسم الطالب": "سارة محمد الكردي", "اللغة العربية": 103, "الرياضيات": 101, "الفيزياء والكيمياء": 96, "اللغة الإنجليزية": 100, "المجموع": 400, "التقدير العام": "ممتاز مرتفع (A+)" }
  ],
  "الصف الأول الثانوي": [
    { "رقم الطالب": "1001", "اسم الطالب": "عبد الرحمن خالد السعدي", "اللغة العربية": 90, "الرياضيات العامة": 92, "الفيزياء": 89, "الكيمياء": 91, "المجموع": 362, "التقدير العام": "ممتاز" }
  ],
  "الصف الثاني الثانوي": [
    { "رقم الطالب": "1101", "اسم الطالب": "جود محمد اليامي", "اللغة العربية": 96, "الرياضيات العلمية": 95, "الأحياء": 92, "الفيزياء": 93, "المجموع": 376, "التقدير العام": "ممتاز مرتفع" }
  ],
  "الصف الثالث الثانوي": [
    { "رقم الطالب": "1201", "اسم الطالب": "ماجد فيصل العتيبي", "اللغة العربية": 99, "الرياضيات المكثفة": 98, "الفيزياء": 97, "الكيمياء العضوية": 100, "المجموع": 394, "التقدير العام": "ممتاز مع مرتبة الشرف" }
  ]
};

export default function ResultsPortal() {
  const [searchGrade, setSearchGrade] = useState<string>(GRADE_NAMES[0]);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [studentResultRow, setStudentResultRow] = useState<ResultRow | null>(null);
  const [studentResultGrade, setStudentResultGrade] = useState<string>("");
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  // Results Management State
  const [resultsSheets, setResultsSheets] = useState<Record<string, ResultRow[]>>({});
  const [currentEditGrade, setCurrentEditGrade] = useState<string>(GRADE_NAMES[0]);
  const [isResultsAuth, setIsResultsAuth] = useState<boolean>(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState<boolean>(false);
  const [passwordInput, setPasswordInput] = useState<string>("");
  const [authError, setAuthError] = useState<string>("");
  const [forgotMessage, setForgotMessage] = useState<string>("");
  const [forgotEmailInput, setForgotEmailInput] = useState<string>("");
  const [showForgotForm, setShowForgotForm] = useState<boolean>(false);
  
  // Directly Edit Sheet Mode States
  const [newColumnName, setNewColumnName] = useState<string>("");
  const [pasteText, setPasteText] = useState<string>("");

  // QR Scanning State Variables
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [scannerMode, setScannerMode] = useState<"live" | "upload" | "demo">("demo");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraLoading, setIsCameraLoading] = useState<boolean>(false);
  const [simulatedScanningIndex, setSimulatedScanningIndex] = useState<number | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const animationFrameIdRef = useRef<number | null>(null);
  const activeStreamRef = useRef<MediaStream | null>(null);

  // Column Designer & Record Editor States
  const [editingColumns, setEditingColumns] = useState<string[]>([]);
  const [recordFormValues, setRecordFormValues] = useState<Record<string, string | number>>({});
  const [editingRowIndex, setEditingRowIndex] = useState<number | null>(null);
  const [saveStatus, setSaveStatus] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // External Excel Link State
  const [linkedExcelUrl, setLinkedExcelUrl] = useState<string>(() => {
    return localStorage.getItem("linked_excel_url") || "";
  });
  const [isRemoteLoading, setIsRemoteLoading] = useState<boolean>(false);

  // Drag-and-drop Handlers for Dynamic Column Designer
  const handleDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.setData("text/plain", String(index));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    const sourceIndexStr = e.dataTransfer.getData("text/plain");
    if (sourceIndexStr === "") return;
    const sourceIndex = parseInt(sourceIndexStr, 10);
    if (isNaN(sourceIndex) || sourceIndex === targetIndex) return;
    
    const updated = [...editingColumns];
    const [removed] = updated.splice(sourceIndex, 1);
    updated.splice(targetIndex, 0, removed);
    setEditingColumns(updated);
  };

  const handleShiftColumn = (index: number, direction: "left" | "right") => {
    const targetIndex = direction === "left" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= editingColumns.length) return;
    
    const updated = [...editingColumns];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;
    setEditingColumns(updated);
  };

  // Auto-calculation of totals & grades
  const recalculateTotalAndGrade = (currentFormValues: Record<string, string | number>) => {
    const updated = { ...currentFormValues };
    
    // Find subject columns: anything that isn't name, id, grade/ghead, group, total, or grade rating
    const subjectCols = Object.keys(updated).filter(col => {
      const c = col.toLowerCase();
      return !c.includes("اسم") &&
             !c.includes("رقم") &&
             !c.includes("كود") &&
             !c.includes("الشعبة") &&
             !c.includes("شعبة") &&
             !c.includes("id") &&
             !c.includes("المجموع") &&
             !c.includes("مجموع") &&
             !c.includes("التقدير") &&
             !c.includes("النسبة") &&
             !c.includes("النسبة العامة") &&
             !c.includes("النسبة %") &&
             !c.includes("الصف");
    });

    let sum = 0;
    let hasActiveSubjects = false;
    let count = 0;

    subjectCols.forEach(col => {
      const val = Number(updated[col]);
      if (!isNaN(val) && updated[col] !== "") {
        sum += val;
        hasActiveSubjects = true;
        count++;
      }
    });

    if (hasActiveSubjects) {
       // Find column for total
       const totalColKey = Object.keys(updated).find(k => k.includes("المجموع") || k.includes("مجموع"));
       if (totalColKey) {
         updated[totalColKey] = sum;
       } else {
         const definedTotalCol = editingColumns.find(k => k.includes("المجموع") || k.includes("مجموع"));
         if (definedTotalCol) {
           updated[definedTotalCol] = sum;
         }
       }

       // Calculate percentage (assuming 100 max per subject)
       const maxPossible = count * 100;
       const percentage = maxPossible > 0 ? (sum / maxPossible) * 100 : 0;

       // Assign percentage
       const pctColKey = Object.keys(updated).find(k => k.includes("النسبة") || k.includes("النسبة %"));
       if (pctColKey) {
         updated[pctColKey] = `${Math.round(percentage)}%`;
       } else {
         const definedPctCol = editingColumns.find(k => k.includes("النسبة") || k.includes("النسبة %"));
         if (definedPctCol) {
           updated[definedPctCol] = `${Math.round(percentage)}%`;
         }
       }

       let estimatedGrade = "مقبول";
       if (percentage >= 90) estimatedGrade = "ممتاز";
       else if (percentage >= 80) estimatedGrade = "جيد جداً";
       else if (percentage >= 65) estimatedGrade = "جيد";
       else estimatedGrade = "ضعيف";

       const gradeColKey = Object.keys(updated).find(k => k.includes("التقدير") || k.includes("التقدير العام"));
       if (gradeColKey) {
         updated[gradeColKey] = estimatedGrade;
       } else {
         const definedGradeCol = editingColumns.find(k => k.includes("التقدير") || k.includes("التقدير العام"));
         if (definedGradeCol) {
           updated[definedGradeCol] = estimatedGrade;
         }
       }
    }
    return updated;
  };

  // Load results from Backend (Active server-side persistence)
  const loadFromBackend = async () => {
    try {
      const response = await fetch("/api/results");
      if (response.ok) {
        const data = await response.json();
        setResultsSheets(data);
        localStorage.setItem("school_results_by_grade", JSON.stringify(data));
      } else {
        const saved = localStorage.getItem("school_results_by_grade");
        if (saved) {
          setResultsSheets(JSON.parse(saved));
        } else {
          setResultsSheets(DEFAULT_RESULTS);
        }
      }
    } catch (e) {
      console.error("Backend fetch error, falling back to cache:", e);
      const saved = localStorage.getItem("school_results_by_grade");
      if (saved) {
        setResultsSheets(JSON.parse(saved));
      } else {
        setResultsSheets(DEFAULT_RESULTS);
      }
    }
  };

  // Save results to Backend (Active server-side persistence)
  const saveToBackend = async (newData: Record<string, ResultRow[]>) => {
    try {
      setResultsSheets(newData);
      localStorage.setItem("school_results_by_grade", JSON.stringify(newData));
      const response = await fetch("/api/results", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newData)
      });
      if (!response.ok) {
        console.error("Failed to commit results DB on server status:", response.status);
      }
    } catch (e) {
      console.error("Error sending results DB to Express server:", e);
    }
  };

  useEffect(() => {
    loadFromBackend();
  }, []);

  // Synchronize design columns state when active grade changes
  useEffect(() => {
    const cols = getColumns(currentEditGrade);
    setEditingColumns(cols);
    
    // Reset editing record form
    const initialForm: Record<string, string | number> = {};
    cols.forEach(c => {
      initialForm[c] = "";
    });
    setRecordFormValues(initialForm);
    setEditingRowIndex(null);
  }, [currentEditGrade, resultsSheets]);

  // Sound feedback using Web Audio API
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.type = "sine";
      oscillator.frequency.value = 880; // A5 tone
      gainNode.gain.setValueAtTime(0.12, audioCtx.currentTime);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.15);
    } catch (e) {
      console.log("Audio feedback not supported or blocked by user engagement", e);
    }
  };

  const startCamera = async () => {
    setCameraError(null);
    setIsCameraLoading(true);
    
    if (activeStreamRef.current) {
      activeStreamRef.current.getTracks().forEach(track => track.stop());
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }
      });
      activeStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true");
        videoRef.current.play();
        setIsCameraLoading(false);
        animationFrameIdRef.current = requestAnimationFrame(scanFrame);
      }
    } catch (err: any) {
      console.error("Camera access failed:", err);
      setCameraError("لم نتمكن من الوصول لكاميرا جهازكم. يرجى استخدام خيار 'رفع صورة بطاقة' أو 'البطاقات الجريبية'.");
      setIsCameraLoading(false);
    }
  };

  const scanFrame = () => {
    if (!videoRef.current || videoRef.current.readyState !== videoRef.current.HAVE_ENOUGH_DATA) {
      animationFrameIdRef.current = requestAnimationFrame(scanFrame);
      return;
    }

    try {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (ctx) {
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "dontInvert",
        });

        if (code && code.data) {
          handleAutoSearchScannedId(code.data.trim());
          return;
        }
      }
    } catch (error) {
      console.error("QR Decoding frame error:", error);
    }
    animationFrameIdRef.current = requestAnimationFrame(scanFrame);
  };

  const stopCameraAndClose = () => {
    setIsScannerOpen(false);
    if (activeStreamRef.current) {
      activeStreamRef.current.getTracks().forEach((track) => track.stop());
      activeStreamRef.current = null;
    }
    if (animationFrameIdRef.current) {
      cancelAnimationFrame(animationFrameIdRef.current);
      animationFrameIdRef.current = null;
    }
  };

  const handleAutoSearchScannedId = (scannedId: string) => {
    playBeep();
    setSearchQuery(scannedId);
    triggerSearch(scannedId);
    stopCameraAndClose();
  };

  const handleQRImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const img = new Image();
    img.src = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (ctx) {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        try {
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: "dontInvert",
          });

          if (code && code.data) {
            handleAutoSearchScannedId(code.data.trim());
          } else {
            alert("⚠️ عذراً، لم نتمكن من العثور على رمز الاستجابة السريعة (QR).");
          }
        } catch (err) {
          alert("خطأ أثناء تحليل ملف الصورة.");
        }
      }
    };
  };

  const handleManualSimulateScan = (idStr: string, idx: number) => {
    setSimulatedScanningIndex(idx);
    setTimeout(() => {
      setSimulatedScanningIndex(null);
      handleAutoSearchScannedId(idStr);
    }, 1500);
  };

  // Search function triggered via Form
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    triggerSearch(searchQuery, searchGrade);
  };

  // Helper to extract proper headers from an Excel worksheet maintaining order
  const getSheetHeaders = (sheet: any): string[] => {
    const headers: string[] = [];
    if (!sheet || !sheet['!ref']) return [];
    const range = XLSX.utils.decode_range(sheet['!ref']);
    for (let col = range.s.c; col <= range.e.c; ++col) {
      const cellAddress = { c: col, r: range.s.r };
      const cellRef = XLSX.utils.encode_cell(cellAddress);
      const cell = sheet[cellRef];
      if (cell && cell.v !== undefined) {
        headers.push(String(cell.v).trim());
      } else {
        headers.push(`درجة_المادة_${col + 1}`);
      }
    }
    return headers;
  };

  // Fetch and search inside the linked external Excel sheet URL
  const searchExternalExcel = async (query: string, url: string): Promise<boolean> => {
    try {
      setIsRemoteLoading(true);
      // Fetch the file
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("فشل الوصول إلى رابط ملف إكسل. تأكد من صحة الرابط.");
      }
      const arrayBuffer = await response.arrayBuffer();
      // Read data
      const data = new Uint8Array(arrayBuffer);
      const workbook = XLSX.read(data, { type: "array" });
      
      const trimmedQuery = query.trim();

      // Search across all sheets in the excel
      for (const sheetName of workbook.SheetNames) {
        const sheet = workbook.Sheets[sheetName];
        if (!sheet) continue;

        const jsonRows: any[] = XLSX.utils.sheet_to_json(sheet);
        const headers = getSheetHeaders(sheet);

        const match = jsonRows.find(row => {
          const idCol = Object.keys(row).find(
            k => k.includes("رقم") || k.includes("كود") || k.includes("id") || k.includes("الرقم")
          );
          if (idCol) {
            return String(row[idCol]).trim() === trimmedQuery;
          }
          return false;
        });

        if (match) {
          // Found! Ignore empty values from the row and preserve column sorting.
          const cleanedRow: ResultRow = {};
          
          headers.forEach(header => {
            const val = match[header];
            if (val !== undefined && val !== null && String(val).trim() !== "") {
              cleanedRow[header] = isNaN(Number(val)) || String(val).trim() === "" ? val : Number(val);
            }
          });

          // Set result card states
          setStudentResultRow(cleanedRow);
          setStudentResultGrade(sheetName);
          setHasSearched(true);
          setIsRemoteLoading(false);
          return true;
        }
      }
      setIsRemoteLoading(false);
      return false;
    } catch (err) {
      console.error("خطأ أثناء جلب الملف الخارجي:", err);
      setIsRemoteLoading(false);
      return false;
    }
  };

  // Core Search By Number logic - Strictly relative to the chosen grade class page or external linked sheet
  const triggerSearch = async (query: string, preferredGrade?: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;

    setStudentResultRow(null);
    setHasSearched(false);

    // If an external Excel Sheet is linked, search in it first!
    if (linkedExcelUrl.trim()) {
      const foundInRemote = await searchExternalExcel(trimmed, linkedExcelUrl.trim());
      if (foundInRemote) {
        playBeep();
        return;
      }
    }

    let foundRow: ResultRow | null = null;
    let foundGrade: string = preferredGrade || searchGrade || GRADE_NAMES[0];

    // Search strictly within the designated sheet for this grade class
    const rows = resultsSheets[foundGrade] || [];
    const match = rows.find((r) => {
      const idCol = Object.keys(r).find(
        k => k.includes("رقم") || k.includes("كود") || k.includes("id") || k.includes("رقم الطالب")
      );
      if (idCol) {
        return String(r[idCol]).trim() === trimmed;
      }
      return false;
    });

    if (match) {
      foundRow = match;
    }

    if (foundRow) {
      setStudentResultRow(foundRow);
      setStudentResultGrade(foundGrade);
      playBeep();
    } else {
      setStudentResultRow(null);
      setStudentResultGrade("");
    }
    setHasSearched(true);
  };

  // Admin login check
  const handleAdminResultsLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const SECRET_KEY = "64a93s";
    if (passwordInput === SECRET_KEY) {
      setIsResultsAuth(true);
      setAuthError("");
      setPasswordInput("");
    } else {
      setAuthError("رمز مرور قسم النتائج غير صحيح. يرجى إعادة المحاولة.");
    }
  };

  // Admin forgot password triggers and verified email check amlf.yen@gmail.com
  const handleRequestPasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    const targetEmail = "amlf.yen@gmail.com";
    const SECRET_KEY = "64a93s";
    
    if (forgotEmailInput.trim().toLowerCase() === targetEmail) {
      const subject = encodeURIComponent("📦 طلب استعادة كلمة مرور بوابة قسم النتائج - مدرسة أمل المستقبل");
      const body = encodeURIComponent(`مرحباً بكم الهيئة الإدارية الموقرة،\n\nلقد تلقينا طلباً لاستعادة كلمة المرور لولوج قسم تعديل ورصد النتائج والكشوفات المدرسية لمدرسة أمل المستقبل الأهلية.\n\nكلمة المرور الرسمية للقسم هي:\n${SECRET_KEY}\n\nيرجى استخدامها بأمان ومسؤولية تامة لتأمين وحماية درجات الطلاب.\n\nتمنياتنا لكم بدوام التوفيق والنجاح مكللاً.`);
      
      setForgotMessage("تم التحقق بنجاح وتجهيز رسالة استرداد كلمة المرور! سيتم الآن توجيهكم فورياً لتأكيد إرسالها إلى البريد الإلكتروني الرسمي للإدارة amlf.yen@gmail.com...");
      setAuthError("");
      
      // Navigate utilizing standard mailto structure
      window.location.href = `mailto:${targetEmail}?subject=${subject}&body=${body}`;
      
      setTimeout(() => {
        setForgotMessage("");
        setShowForgotForm(false);
        setForgotEmailInput("");
      }, 7000);
    } else {
      setAuthError("عذراً، البريد الإلكتروني الذي قمت بإدخاله غير صحيح أو غير مصرح له باستلام كود الإدارة! يرجى إدخال البريد الرسمي للإدارة: amlf.yen@gmail.com");
    }
  };

  // Excel workbook multi-sheet generator based on current state
  const handleDownloadExcelTemplate = () => {
    const workbook = XLSX.utils.book_new();

    GRADE_NAMES.forEach((gradeName) => {
      const rows = resultsSheets[gradeName] || [];
      const safeRows = rows.length > 0 ? rows : [
        { "رقم الطالب": "مثال_100", "اسم الطالب": "اسم تجريبي هنا", "اللغة العربية": 95, "الرياضيات": 90, "المجموع": 185, "التقدير العام": "ممتاز" }
      ];
      const worksheet = XLSX.utils.json_to_sheet(safeRows);
      XLSX.utils.book_append_sheet(workbook, worksheet, gradeName.substring(0, 31)); // sheet names restricted to 31 chars in Excel
    });

    XLSX.writeFile(workbook, "شيت_درجات_مستند_أمل_المستقبل_12_صفحة.xlsx");
  };

  // Excel workbook multi-sheet ingestion
  const handleUploadExcelFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });

        const newSheetsHash: Record<string, ResultRow[]> = { ...resultsSheets };

        workbook.SheetNames.forEach((sheetName) => {
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json<any>(worksheet);

          let matchedGradeName = GRADE_NAMES.find(g => g.includes(sheetName) || sheetName.includes(g));
          if (!matchedGradeName) {
            const index = workbook.SheetNames.indexOf(sheetName);
            if (index >= 0 && index < GRADE_NAMES.length) {
              matchedGradeName = GRADE_NAMES[index];
            }
          }

          if (matchedGradeName && json.length > 0) {
            // Clean empty columns: only process keys with non-empty values
            const cleanedRows = json.map(row => {
              const cleaned: ResultRow = {};
              Object.keys(row).forEach(key => {
                const val = row[key];
                if (val !== undefined && val !== null && String(val).trim() !== "") {
                  cleaned[key] = isNaN(Number(val)) || String(val).trim() === "" ? val : Number(val);
                }
              });
              return cleaned;
            });
            newSheetsHash[matchedGradeName] = cleanedRows;
          }
        });

        await saveToBackend(newSheetsHash);
        alert("تم تفريغ وربط درجات شيت الإكسل لجميع الصفوف المعتمدة وتخزينها بأمان على الخادم! 💾📊");
      } catch (err) {
        alert("عذراً، حدث خطأ في معالجة ملف الإكسل. يرجى التأكد من توافق الأعمدة والصفوف.");
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = ""; // Reset
  };

  // Get current columns for selected grade sheet
  const getColumns = (grade: string): string[] => {
    const rows = resultsSheets[grade] || [];
    if (rows.length === 0) {
      return ["رقم الطالب", "اسم الطالب", "اللغة العربية", "الالرياضيات", "العلوم", "التقدير العام"];
    }
    const keysSet = new Set<string>();
    rows.forEach(r => Object.keys(r).forEach(k => keysSet.add(k)));
    const keys = Array.from(keysSet);

    // Order appropriately: Student ID, Student Name first
    const primaryKeys = keys.filter(k => k.includes("رقم") || k.includes("كود") || k.includes("id") || k.includes("اسم") || k.includes("الاسم"));
    const secondaryKeys = keys.filter(k => !primaryKeys.includes(k));
    return [...primaryKeys, ...secondaryKeys];
  };

  // Update specific cell inside internal sheet
  const handleCellChange = (grade: string, rowIndex: number, column: string, val: string | number) => {
    const sheetData = [...(resultsSheets[grade] || [])];
    if (sheetData[rowIndex]) {
      const parsedVal = isNaN(Number(val)) || val === "" ? val : Number(val);
      sheetData[rowIndex] = { ...sheetData[rowIndex], [column]: parsedVal };
      const updated = { ...resultsSheets, [grade]: sheetData };
      setResultsSheets(updated);
      localStorage.setItem("school_results_by_grade", JSON.stringify(updated));
    }
  };

  // Add blank row
  const handleAddBlankRow = (grade: string) => {
    const sheetData = [...(resultsSheets[grade] || [])];
    const columns = getColumns(grade);
    const newRow: ResultRow = {};
    columns.forEach(col => {
      newRow[col] = col.includes("رقم") ? "جديد" : "";
    });
    sheetData.push(newRow);
    const updated = { ...resultsSheets, [grade]: sheetData };
    setResultsSheets(updated);
    localStorage.setItem("school_results_by_grade", JSON.stringify(updated));
  };

  // Delete row
  const handleDeleteRow = (grade: string, index: number) => {
    const sheetData = [...(resultsSheets[grade] || [])];
    sheetData.splice(index, 1);
    const updated = { ...resultsSheets, [grade]: sheetData };
    setResultsSheets(updated);
    localStorage.setItem("school_results_by_grade", JSON.stringify(updated));
  };

  // Add new column to selected class sheet
  const handleAddColumn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColumnName.trim()) return;
    const colName = newColumnName.trim();
    
    const sheetData = (resultsSheets[currentEditGrade] || []).map(row => {
      return { ...row, [colName]: "" };
    });

    const updated = { ...resultsSheets, [currentEditGrade]: sheetData };
    setResultsSheets(updated);
    localStorage.setItem("school_results_by_grade", JSON.stringify(updated));
    setNewColumnName("");
    alert(`تم إضافة عمود جديد باسم: "${colName}" للصف المحدد بنجاح.`);
  };

  // Paste results directly (TSV format from Excel sheet copier)
  const handleImportPasteText = () => {
    if (!pasteText.trim()) {
      alert("يرجى إدخال الخلايا المنسوخة في المربع أولاً للقيام بقسمتها ولصقها.");
      return;
    }

    const lines = pasteText.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length === 0) return;

    const parsedRows: ResultRow[] = [];
    const firstLineCells = lines[0].split("\t").map(cell => cell.trim());

    // Guess if the first line holds headers
    const hasHeaders = firstLineCells.some(
      cell => cell.includes("رقم") || cell.includes("اسم") || cell.includes("كود") || cell.includes("مادة") || cell.includes("تقدير")
    );

    let headers: string[] = [];
    let dataStartIdx = 0;

    if (hasHeaders) {
      headers = firstLineCells;
      dataStartIdx = 1;
    } else {
      headers = getColumns(currentEditGrade);
    }

    for (let i = dataStartIdx; i < lines.length; i++) {
      const cells = lines[i].split("\t").map(cell => cell.trim());
      const row: ResultRow = {};
      
      headers.forEach((headerName, cellIdx) => {
        const val = cells[cellIdx] !== undefined ? cells[cellIdx] : "";
        row[headerName] = isNaN(Number(val)) || val === "" ? val : Number(val);
      });

      // Verification fallbacks to ensure core fields exist
      const val0 = cells[0] !== undefined ? cells[0] : "";
      const val1 = cells[1] !== undefined ? cells[1] : "";
      
      const hasIdColName = Object.keys(row).find(k => k.includes("رقم") || k.includes("كود"));
      if (!hasIdColName) {
        row["رقم الطالب"] = val0;
      }
      const hasNameColName = Object.keys(row).find(k => k.includes("اسم") || k.includes("الاسم"));
      if (!hasNameColName) {
        row["اسم الطالب"] = val1;
      }

      parsedRows.push(row);
    }

    const updated = { ...resultsSheets, [currentEditGrade]: parsedRows };
    setResultsSheets(updated);
    localStorage.setItem("school_results_by_grade", JSON.stringify(updated));
    setPasteText("");
    alert(`تم رصد وإدراج عدد (${parsedRows.length}) صفوف من البيانات المنسوخة للصف "${currentEditGrade}" بنجاح!`);
  };

  const handleClearGradeSheet = () => {
    if (window.confirm(`هل أنت متأكد من تصفير وحذف جميع نتائج طلاب صف [${currentEditGrade}] بالكامل؟`)) {
      const updated = { ...resultsSheets, [currentEditGrade]: [] };
      setResultsSheets(updated);
      localStorage.setItem("school_results_by_grade", JSON.stringify(updated));
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handlePdfDownload = () => {
    alert("📄 لحفظ النتيجة بصيغة PDF معتمدة ومقاومة للتزييف:\nالرجاء اختيار 'حفظ بتنسيق PDF' أو 'Save as PDF' من قائمة خيارات الطابعة (Destination) التي ستظهر لك الآن.");
    window.print();
  };

  return (
    <div id="results-portal-view" className="space-y-12 pb-12 text-right">
      
      {/* Header View */}
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <span className="bg-amber-100 text-amber-700 text-xs font-bold px-4 py-1.5 rounded-full border border-amber-200 uppercase tracking-widest inline-flex items-center gap-1.5 shadow-sm">
          <span>بوابة استعلام النتائج الرسمية المحدثة</span>
          <Award className="w-3.5 h-3.5" />
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 font-display">
          نظام الاستعلام عن نتائج الطلاب للفصل الدراسي الثاني
        </h1>
        <p className="text-slate-600 text-sm font-semibold">
          ادخل رقم الطالب للحصول على النتائج
        </p>
      </div>

      {/* Main Public Student Number Lookup Search Bar Card */}
      <div className="max-w-xl mx-auto bg-white p-6.5 rounded-3xl border border-slate-200/60 shadow-md relative overflow-visible space-y-4">
        <form onSubmit={handleSearch} className="space-y-4">
          
          {/* Grade selection dropdown with icon */}
          <div className="space-y-1 text-right">
            <label className="block text-xs font-black text-slate-700 flex items-center justify-start gap-1.5 pb-1">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span>1. اختر الصف الدراسي للطالب:</span>
            </label>
            <div className="relative">
              <select
                value={searchGrade}
                onChange={(e) => setSearchGrade(e.target.value)}
                className="w-full p-3.5 pr-10 bg-slate-50 hover:bg-slate-100/40 border border-slate-200 rounded-xl text-xs font-extrabold focus:outline-none focus:border-indigo-550 focus:bg-white text-right transition cursor-pointer"
              >
                {GRADE_NAMES.map((name) => (
                  <option key={name} value={name} className="font-extrabold text-slate-800">
                    {name}
                  </option>
                ))}
              </select>
              <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-indigo-600">
                <Settings className="w-4 h-4 text-indigo-600" />
              </div>
            </div>
          </div>

          {/* Student ID input block */}
          <div className="space-y-1 text-right">
            <label className="block text-xs font-black text-slate-700 flex items-center justify-start gap-1.5 pb-1">
              <Award className="w-4 h-4 text-indigo-600" />
              <span>2. أدخل الرقم الامتحاني / الأكاديمي:</span>
            </label>
            <div className="relative">
              <input
                id="result-search-input"
                type="text"
                required
                placeholder="اكتب رقم الطالب واستعلم فوراً (مثال: 101, 102, 103)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full p-3.5 pr-4 pl-12 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-indigo-550 text-right focus:bg-white transition-all duration-150 font-black tracking-wider"
              />
              {/* QR Code scanner trigger */}
              <button
                type="button"
                onClick={() => {
                  setIsScannerOpen(true);
                  setScannerMode("demo");
                }}
                title="مسح كود الطالب بالـ QR أو الكاميرا"
                className="absolute left-3 top-1/2 -translate-y-1/2 p-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-600 hover:text-white rounded-lg transition-all duration-150 cursor-pointer flex items-center justify-center border border-indigo-100"
              >
                <QrCode className="w-4 h-4" />
              </button>
            </div>
          </div>

          <button
            id="btn-search-result"
            type="submit"
            disabled={isRemoteLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-750 text-white font-black py-3.5 rounded-xl text-xs transition-all duration-150 flex items-center justify-center gap-1.5 shadow-sm cursor-pointer select-none border border-slate-200 pt-3 mt-4"
          >
            {isRemoteLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>جاري قراءة وفرز الشيت الرقمي الخارجي...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>بحث واستعلام النتيجة الفورية 🔍</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-4 flex flex-wrap items-center gap-3 text-[11px] text-slate-400 justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-slate-50 px-2 py-0.5 rounded font-medium">💡 أرقام تجريبية سريعة:</span>
            <button type="button" onClick={() => { setSearchQuery("101"); triggerSearch("101"); }} className="underline font-bold text-slate-500 hover:text-indigo-600">101</button>
            <button type="button" onClick={() => { setSearchQuery("102"); triggerSearch("102"); }} className="underline font-bold text-slate-500 hover:text-indigo-600">102</button>
            <button type="button" onClick={() => { setSearchQuery("103"); triggerSearch("103"); }} className="underline font-bold text-slate-500 hover:text-indigo-600">103</button>
          </div>

          <button
            type="button"
            onClick={() => setIsAdminPanelOpen(!isAdminPanelOpen)}
            className="text-[10.5px] text-slate-400 hover:text-indigo-700 font-bold flex items-center gap-1.5 underline transition"
          >
            <Lock className="w-3 h-3" />
            <span>بوابة رصد وتعديل النتائج للكنترول</span>
          </button>
        </div>

        {/* ALRASSASS Design Badge */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          <span className="text-[10px] text-slate-400 font-bold">بوابة نظام خدمات الكنترول والمدرسة الرقمية</span>
          <a
            href="https://wa.me/967774632249"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-l from-[#25D366]/10 to-emerald-50 text-[#075e54] hover:from-[#25D366]/20 hover:to-emerald-100 font-black text-[10.5px] rounded-lg border border-[#25D366]/20 transition-all duration-200 cursor-pointer shadow-3xs"
            title="تواصل مع المطور عبر واتساب"
          >
            <span className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />
            <span>تصميم ALRASSASS 📞💬</span>
          </a>
        </div>
      </div>

      {/* Admin Panel Password Auth & Spreadsheet Manager Section (Completely Hidden unless AdminPanel is toggled) */}
      {isAdminPanelOpen && (
        <div className="max-w-5xl mx-auto bg-slate-55 border border-slate-200 rounded-3xl p-6 md:p-8 space-y-8 animate-fade-in text-right">
          
          {/* Admin Section Control Top bar */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-indigo-100 text-indigo-700 rounded-xl flex items-center justify-center font-bold">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-800 text-sm md:text-base">بوابة التحكم في الكشف السري لقسم النتائج</h3>
                <p className="text-[10.5px] text-slate-400">إدخال، حذف، نسخ، لصق لـ 12 صفاً دراسياً والرفع المعتمد</p>
              </div>
            </div>
            
            <button
              onClick={() => {
                setIsResultsAuth(false);
                setIsAdminPanelOpen(false);
              }}
              className="text-xs text-slate-400 hover:text-slate-700 font-bold flex items-center gap-1"
            >
              <span>إغلاق اللوحة ✖</span>
            </button>
          </div>

          {/* STEP A: Password Verification or Reset */}
          {!isResultsAuth ? (
            <div className="max-w-md mx-auto bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
              {!showForgotForm ? (
                <form onSubmit={handleAdminResultsLogin} className="space-y-4">
                  <p className="text-xs text-slate-500 leading-relaxed text-right">
                    هذا القسم محمي بقسم النتائج لرصد الدرجات وكشوف الطلاب، يرجى إدخال كلمة المرور المصرحة لمتابعة العمليات:
                  </p>
                  
                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold text-slate-600">رمز مرور الكنترول وقسم النتائج:</label>
                    <input
                      type="password"
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      placeholder="أدخل رمز المرور السري..."
                      className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/20 text-xs py-3 px-3.5 rounded-xl font-bold"
                    />
                    
                    {authError && (
                      <p className="text-[10.5px] text-rose-650 font-bold flex items-center gap-1 mt-1.5">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{authError}</span>
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setShowForgotForm(true);
                        setAuthError("");
                        setForgotMessage("");
                      }}
                      className="text-xs text-rose-600 font-extrabold hover:underline"
                    >
                      نسيت كلمة المرور؟ 🔑
                    </button>

                    <button
                      type="submit"
                      className="bg-indigo-650 hover:bg-indigo-750 text-white font-black px-5 py-2.5 rounded-xl text-xs transition flex items-center gap-1.5 shadow cursor-pointer"
                    >
                      <Unlock className="w-3.5 h-3.5" />
                      <span>تأكيد المرور والتحكم 🔓</span>
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleRequestPasswordReset} className="space-y-4">
                  <h3 className="text-xs font-black text-slate-800 border-b pb-2">🔐 استرداد وتأكيد هوية إدارة المدرسة</h3>
                  <p className="text-xs text-slate-500 leading-relaxed text-right">
                    لاستلام رمز المرور السري، يرجى إدخال البريد الإلكتروني المعتمد الخاص بالإدارة المدرسية الموقرة ليتم إرساله وتحديده فوراً ومباشرة:
                  </p>

                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold text-slate-600">البريد الإلكتروني للإدارة المدرسية:</label>
                    <input
                      type="email"
                      required
                      value={forgotEmailInput}
                      onChange={(e) => setForgotEmailInput(e.target.value)}
                      placeholder="amlf.yen@gmail.com..."
                      dir="ltr"
                      className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/20 text-xs py-3 px-3.5 rounded-xl font-bold text-left"
                    />

                    {authError && (
                      <p className="text-[10.5px] text-rose-650 font-bold flex items-center gap-1 mt-1.5">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{authError}</span>
                      </p>
                    )}

                    {forgotMessage && (
                      <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl text-[10.5px] text-indigo-900 font-extrabold leading-relaxed mt-2 text-right">
                        {forgotMessage}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setShowForgotForm(false);
                        setAuthError("");
                        setForgotMessage("");
                      }}
                      className="text-xs text-slate-500 font-extrabold hover:underline"
                    >
                      الرجوع لتسجيل الدخول ⬅
                    </button>

                    <button
                      type="submit"
                      className="bg-[#00a651] hover:bg-emerald-700 text-white font-black px-5 py-2.5 rounded-xl text-xs transition flex items-center gap-1.5 shadow cursor-pointer"
                    >
                      <span>استرداد وإرسال الكود 📬</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          ) : (
            
            // STEP B: Logged In Admin Dashboard
            <div className="space-y-8 animate-fade-in text-right">
              
              {/* Top bar with Upload Excel & Download templates */}
              <div className="bg-white p-6 rounded-3xl border border-slate-105 shadow-md flex flex-col md:flex-row items-center justify-between gap-5">
                <div className="text-right space-y-1">
                  <span className="text-[10.5px] text-emerald-600 font-extrabold bg-emerald-50 px-3.5 py-1.5 rounded-full border border-emerald-100 inline-flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>تم التوثيق والربط بالكنترول السري للخادم بنجاح ✓</span>
                  </span>
                  <p className="text-xs text-slate-500 font-bold">يتم الآن حفظ جميع تعديلات وهياكل الكشوفات مباشرة بملف خادم المدرسة لدوام ثبات البيانات.</p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                  <label className="bg-indigo-600 hover:bg-indigo-720 text-white font-extrabold px-4 py-2.5 rounded-xl text-xs cursor-pointer flex items-center gap-1.5 transition shadow-sm">
                    <Upload className="w-4 h-4" />
                    <span>رفع شيت إكسل للمدرسة لجميع الصفوف (.xlsx)</span>
                    <input 
                      type="file" 
                      accept=".xlsx, .xls" 
                      onChange={handleUploadExcelFile}
                      className="hidden" 
                    />
                  </label>

                  <button
                    onClick={handleDownloadExcelTemplate}
                    className="bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-205 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer shadow-xs"
                    title="تحميل كاف كشوفات الصفوف الـ 12 المنسقة لإعدادها وإعادة الرفع الفوري"
                  >
                    <Download className="w-4 h-4 text-indigo-650" />
                    <span>تنزيل النموذج الكشفي الجاهز</span>
                  </button>
                </div>
              </div>

              {saveStatus && (
                <div className={`p-4 rounded-xl text-xs font-black border text-center animate-bounce ${
                  saveStatus.type === "success" 
                    ? "bg-[#e6fff0] text-[#00a651] border-[#c2f0d5]" 
                    : "bg-[#ffeaea] text-[#e53935] border-[#fbc4c4]"
                }`}>
                  {saveStatus.text}
                </div>
              )}

               {/* Linked External Excel Sheet Configuration Card inside the Admin Dashboard */}
              <div className="bg-gradient-to-l from-emerald-50 to-white p-6 rounded-3xl border border-emerald-100 shadow-xs space-y-3.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-emerald-100 rounded-lg text-emerald-700">
                    <LinkIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-slate-800">ربط ومزامنة شيت إكسل أو جوجل شيت خارجي (مباشر ومشارك):</h4>
                    <p className="text-[10px] text-slate-500 font-bold mt-0.5">يمكنك لصق رابط مشاركة ملف إكسل من جوجل شيت (بصيغة .xlsx مباشر أو منشور على الويب للتنقيب والبحث التلقائي فيه مجاوراً للبيانات المحلية).</p>
                  </div>
                </div>

                <div className="relative">
                  <input
                    type="text"
                    placeholder="ضع هنا رابط المشاركة المباشر لملف جوجل شيت أو إكسل (.xlsx)..."
                    value={linkedExcelUrl}
                    onChange={(e) => {
                      const val = e.target.value;
                      setLinkedExcelUrl(val);
                      localStorage.setItem("linked_excel_url", val);
                    }}
                    className="w-full p-3 bg-white border border-slate-205 rounded-xl text-xs text-right font-semibold focus:outline-none focus:border-indigo-500 pr-3"
                  />
                  {linkedExcelUrl && (
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] text-[#00a651] font-extrabold bg-[#e6fff0] border border-emerald-100 px-2.5 py-1 rounded-md flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>متصل ومربوط بنجاح ✓</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Class Selection Tabs for the 12 Classes */}
              <div className="space-y-3 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-5 bg-indigo-650 rounded-full" />
                  <p className="text-xs font-black text-slate-800">يرجى تحديد الفصل الدراسي والصف المستهدف لإدارة وتعديل كشوفاته الخاصة:</p>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
                  {GRADE_NAMES.map((className) => {
                    const rowLength = (resultsSheets[className] || []).length;
                    const isActive = currentEditGrade === className;
                    return (
                      <button
                        key={className}
                        type="button"
                        onClick={() => {
                          setCurrentEditGrade(className);
                        }}
                        className={`p-3 text-xs rounded-xl font-black text-center transition duration-150 border cursor-pointer ${
                          isActive 
                            ? "bg-indigo-600 text-white border-indigo-600 shadow-md" 
                            : "bg-white text-slate-705 border-slate-200 hover:bg-slate-50"
                        }`}
                      >
                        <div>{className}</div>
                        <div className={`text-[9.5px] font-mono mt-0.5 ${isActive ? "text-indigo-200" : "text-slate-400"}`}>
                          ({rowLength} طالب مرصود)
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* SpreadSheet Customization & Ingestion Interface */}
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-8">
                
                {/* Visual Header */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-indigo-50 pb-5">
                  <div className="text-right space-y-1">
                    <h4 className="font-black text-slate-900 text-sm sm:text-base flex items-center gap-2 justify-start">
                      <Grid className="w-5 h-5 text-indigo-650 animate-pulse" />
                      <span>كنترول رصد وتصميم نتائج : [ {currentEditGrade} ]</span>
                    </h4>
                    <p className="text-xs text-slate-400">تقوم البوابة الحالية بفلترة وجلب الشيت الخاص بـ ({currentEditGrade}) فقط وتجاهل الفصول الأخرى.</p>
                  </div>

                  <button
                    onClick={async () => {
                      if (window.confirm(`⚠️ تحذير إداري صارم: هل أنت متأكد من رغبتك في تفريغ وحذف شيت [ ${currentEditGrade} ] بالكامل؟ سيقوم ذلك بمسح كافة الأسماء والعلامات على الخادم.`)) {
                        const updated = { ...resultsSheets, [currentEditGrade]: [] };
                        await saveToBackend(updated);
                        setSaveStatus({
                          type: "success",
                          text: `تم تصفير ومسح كامل بيانات شيت ${currentEditGrade} بنجاح من الخادم.`
                        });
                        setTimeout(() => setSaveStatus(null), 4000);
                      }
                    }}
                    className="bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>حذف الشيت بالكامل 🧼</span>
                  </button>
                </div>

                {/* 1. DYNAMIC COLUMN SCHEMATIC DESIGNER */}
                <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-150 space-y-4">
                  <div className="border-b border-slate-150 pb-3 flex items-center justify-between">
                    <div>
                      <h5 className="font-extrabold text-xs text-slate-800 flex items-center gap-1">
                        <Settings className="w-4 h-4 text-indigo-650 animate-spin" style={{ animationDuration: '6s' }} />
                        <span>أولاً: محرر ومصمم خانات الشيت وتسميتها ونشرها 📊</span>
                      </h5>
                      <p className="text-[10px] text-slate-400 mt-0.5">اكتب التسمية لكل خانة (عمود) ترغب في تأسيسه لهذا الشيت، ثم انقر على زر النشر لاعتاد الهيكل وتعميمه.</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setEditingColumns([...editingColumns, `خانة جديدة ${editingColumns.length + 1}`]);
                      }}
                      className="bg-white hover:bg-slate-100 text-indigo-700 border border-indigo-200 font-extrabold px-3 py-1.5 rounded-lg text-[11px] flex items-center gap-1 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>إضافة خانة جديدة</span>
                    </button>
                  </div>

                  {/* List of custom columns inside designer with Drag-and-Drop and Shift Arrows */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {editingColumns.map((colName, cIdx) => (
                      <div 
                        key={cIdx} 
                        draggable="true"
                        onDragStart={(e) => handleDragStart(e, cIdx)}
                        onDragOver={handleDragOver}
                        onDrop={(e) => handleDrop(e, cIdx)}
                        className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-2 cursor-grab hover:bg-slate-50/50 active:cursor-grabbing transition"
                        title="اسحب للتنقل والترتيب"
                      >
                        {/* Shifter Arrows */}
                        <div className="flex flex-col gap-0.5 shrink-0 select-none">
                          <button
                            type="button"
                            disabled={cIdx === 0}
                            onClick={() => handleShiftColumn(cIdx, "left")}
                            className="p-0.5 text-slate-400 hover:text-indigo-600 disabled:opacity-25 transition"
                            title="نقل لليمين"
                          >
                            <ArrowUp className="w-3 h-3 text-indigo-500" />
                          </button>
                          <button
                            type="button"
                            disabled={cIdx === editingColumns.length - 1}
                            onClick={() => handleShiftColumn(cIdx, "right")}
                            className="p-0.5 text-slate-400 hover:text-indigo-600 disabled:opacity-25 transition"
                            title="نقل لليسار"
                          >
                            <ArrowDown className="w-3 h-3 text-indigo-500" />
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={async () => {
                            if (window.confirm(`⚠️ تحذير: هل أنت متأكد من رغبتك في حذف خانة "${colName}" بالكامل؟ سيتم مسحها حتى من سجلات ودرجات الطلاب لشيت هذا الصف الموقر.`)) {
                              const nextCols = editingColumns.filter((_, idx) => idx !== cIdx);
                              setEditingColumns(nextCols);

                              // Delete columns dynamically from sheet rows
                              const sheetRows = [...(resultsSheets[currentEditGrade] || [])];
                              const cleanedRows = sheetRows.map(row => {
                                const nextRow = { ...row };
                                delete nextRow[colName];
                                return nextRow;
                              });

                              const updated = { ...resultsSheets, [currentEditGrade]: cleanedRows };
                              await saveToBackend(updated);

                              setSaveStatus({
                                type: "success",
                                text: `تم مسح وحذف العمود [ ${colName} ] وتطبيقه بالكامل على شيت الكنترول 📡✨`
                              });
                              setTimeout(() => setSaveStatus(null), 4000);
                            }
                          }}
                          className="p-1 text-rose-500 hover:bg-rose-50 rounded"
                          title="حذف هذه المادة/الخانة"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                        
                        <input
                          type="text"
                          value={colName}
                          onChange={(e) => {
                            const updated = [...editingColumns];
                            updated[cIdx] = e.target.value;
                            setEditingColumns(updated);
                          }}
                          placeholder="اسم المادة/الخانة..."
                          className="w-full text-right bg-transparent text-xs font-black text-slate-850 border-b border-dashed border-slate-200 focus:border-indigo-500 focus:outline-none"
                        />
                        <span className="text-[9px] font-mono text-slate-400 shrink-0">#{cIdx + 1}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="button"
                      onClick={async () => {
                        const filteredCols = editingColumns.map(c => c.trim()).filter(Boolean);
                        if (filteredCols.length === 0) {
                          alert("يرجى إدخال اسم عمود واحد على الأقل قبل النشر!");
                          return;
                        }
                        
                        // Refactor original sheet rows to matching only published ones
                        const originalRows = resultsSheets[currentEditGrade] || [];
                        const refactoredRows = originalRows.map(row => {
                          const cleaned: ResultRow = {};
                          filteredCols.forEach(col => {
                            cleaned[col] = (row[col] !== undefined && row[col] !== null && String(row[col]).trim() !== "") ? row[col] : "";
                          });
                          return cleaned;
                        });

                        const updated = { ...resultsSheets, [currentEditGrade]: refactoredRows };
                        await saveToBackend(updated);

                        setSaveStatus({
                          type: "success",
                          text: `تم نشر هيكل خلايا شيت (${currentEditGrade}) بنجاح! تم تطبيق الخانات الـ (${filteredCols.length}) على سجلات الكنترول 📡✨`
                        });
                        setTimeout(() => setSaveStatus(null), 5000);
                      }}
                      className="bg-indigo-650 hover:bg-indigo-750 text-white font-black px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition shadow"
                    >
                      <CheckCircle className="w-4 h-4 animate-bounce" />
                      <span>نشر وتطبيق هيكل الخلايا على الشيت 📡</span>
                    </button>
                  </div>
                </div>

                {/* 2. COMPACT MANUALLY RECORD INSERT & EDITING FORM BOX */}
                <div id="student-record-form-section" className="bg-indigo-50/45 p-6 rounded-2xl border border-indigo-100/60 space-y-4">
                  <div className="border-b border-indigo-100 pb-3 flex items-center justify-between">
                    <div>
                      <h5 className="font-extrabold text-xs text-indigo-950 flex items-center gap-1.5">
                        <Plus className="w-4 h-4 text-indigo-600" />
                        <span>ثانياً: بوابة إدخال طالب جديد أو تعديل بياناته السريعة 📝</span>
                      </h5>
                      <p className="text-[10px] text-slate-400 mt-0.5">تقوم هذه الواجهة بشكل آلي ومختصر بجلب الخانات المعتمدة بالشيت المختار حالياً لتسهيل الرصد دون خلل.</p>
                    </div>

                    {editingRowIndex !== null && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingRowIndex(null);
                          const reset: Record<string, string | number> = {};
                          editingColumns.forEach(c => { reset[c] = ""; });
                          setRecordFormValues(reset);
                        }}
                        className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-3 py-1 rounded-lg text-[10px] font-bold"
                      >
                        إلغاء التعديل والبدء من جديد
                      </button>
                    )}
                  </div>

                  <form onSubmit={async (e) => {
                    e.preventDefault();
                    const idKey = editingColumns.find(c => c.includes("رقم") || c.includes("كود") || c.includes("id"));
                    const nameKey = editingColumns.find(c => c.includes("اسم") || c.includes("الاسم"));
                    
                    const recordId = String(recordFormValues[idKey || "رقم الطالب"] || "").trim();
                    const recordName = String(recordFormValues[nameKey || "اسم الطالب"] || "").trim();

                    if (!recordId || !recordName) {
                      alert("⚠️ يرجى تعبئة حقل (رقم الطالب) و (اسم الطالب) كحد أدنى لتسجيل كارت الطالب!");
                      return;
                    }

                    // Strict clean values filtering empty ones
                    const studentRecord: ResultRow = {};
                    editingColumns.forEach(col => {
                      const v = recordFormValues[col];
                      if (v !== undefined && v !== null && String(v).trim() !== "") {
                        studentRecord[col] = (isNaN(Number(v)) || String(v).trim() === "") ? v : Number(v);
                      }
                    });

                    const sheetRows = [...(resultsSheets[currentEditGrade] || [])];
                    if (editingRowIndex !== null && editingRowIndex >= 0) {
                      sheetRows[editingRowIndex] = studentRecord;
                    } else {
                      sheetRows.push(studentRecord);
                    }

                    const updated = { ...resultsSheets, [currentEditGrade]: sheetRows };
                    await saveToBackend(updated);

                    setSaveStatus({
                      type: "success",
                      text: editingRowIndex !== null 
                        ? "تم تحديث وحفظ بيانات الطالب بنجاح على الخادم الموحد! 🛡️" 
                        : "تم إدراج الطالب آلياً بداخل شيت الكنترول وتحديث الخادم بنجاح! 🚀"
                    });

                    // Reset
                    const reset: Record<string, string | number> = {};
                    editingColumns.forEach(c => { reset[c] = ""; });
                    setRecordFormValues(reset);
                    setEditingRowIndex(null);

                    setTimeout(() => setSaveStatus(null), 5000);
                  }} className="space-y-4">
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {editingColumns.map((colName) => {
                        const isMainKey = colName.includes("رقم") || colName.includes("اسم") || colName.includes("كود");
                        return (
                          <div key={colName} className="space-y-1">
                            <label className="block text-[10.5px] font-black text-slate-700">
                              {colName} {isMainKey && <span className="text-indigo-600 font-bold">*</span>}
                            </label>
                            <input
                              type="text"
                              value={recordFormValues[colName] !== undefined ? recordFormValues[colName] : ""}
                              onChange={(ev) => {
                                const val = ev.target.value;
                                const updatedValues = {
                                  ...recordFormValues,
                                  [colName]: val
                                };
                                const recalculated = recalculateTotalAndGrade(updatedValues);
                                setRecordFormValues(recalculated);
                              }}
                              placeholder={`القيمة للـ ${colName}...`}
                              className="w-full bg-white border border-slate-205 text-xs p-2.5 rounded-xl font-bold focus:ring-1 focus:ring-indigo-500 focus:outline-none focus:border-indigo-500"
                            />
                          </div>
                        );
                      })}
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="bg-indigo-600 hover:bg-indigo-720 text-white font-extrabold px-6 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition shadow"
                      >
                        <Plus className="w-4 h-4" />
                        <span>{editingRowIndex !== null ? "حفظ التعديلات المدخلة للطالب ⚙️" : "إدراج سجل الطالب آلياً في الكشف لعام 2026 ⚡"}</span>
                      </button>
                    </div>

                  </form>
                </div>

                {/* 3. INTERACTIVE RENDERING GRID TABLE (ACTIVE SHEET ROWS) WITH INDIVIDUAL EDIT/DELETE */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-800">ثالثاً: كشف رصد علامات الطلاب الحالي والشبكة النشطة 📋</span>
                    <span className="text-[10px] text-indigo-650 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-100 font-bold">
                      تم رصد { (resultsSheets[currentEditGrade] || []).length } طالب إجمالياً
                    </span>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-2xl shadow-inner bg-white">
                    <table className="w-full border-collapse text-right text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-slate-700 font-black border-b border-slate-200">
                          <th className="p-3 text-center border-l border-slate-150 w-12">الترتيب</th>
                          {getColumns(currentEditGrade).map((col) => (
                            <th key={col} className="p-3 border-l border-slate-150 font-black text-slate-800 text-center min-w-[120px]">{col}</th>
                          ))}
                          <th className="p-3 text-center w-24">العمليات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-150 text-[#0f172a]">
                        {(resultsSheets[currentEditGrade] || []).length === 0 ? (
                          <tr>
                            <td colSpan={getColumns(currentEditGrade).length + 2} className="p-10 text-center text-slate-400 font-bold bg-slate-50/20">
                              الكشف كافته فارغ حالياً لهذا الفصل الدراسي. تفضل بإنشاء الخانات والدرجات أو جرب لصق الخلايا بالأسفل.
                            </td>
                          </tr>
                        ) : (
                          (resultsSheets[currentEditGrade] || []).map((row, rIdx) => (
                            <tr key={rIdx} className="hover:bg-indigo-50/15 transition-colors">
                              <td className="p-2.5 text-center text-[10.5px] border-l border-slate-150 bg-slate-50 font-mono font-bold text-slate-500">{rIdx + 1}</td>
                              
                              {getColumns(currentEditGrade).map((col) => (
                                <td key={col} className="p-2 border-l border-slate-150 text-center text-[11px] font-bold">
                                  {row[col] !== undefined && row[col] !== null && String(row[col]).trim() !== "" ? String(row[col]) : "-"}
                                </td>
                              ))}

                              <td className="p-2 text-center flex items-center justify-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingRowIndex(rIdx);
                                    const formed: Record<string, string | number> = {};
                                    editingColumns.forEach(c => {
                                      formed[c] = row[c] !== undefined ? row[c] : "";
                                    });
                                    setRecordFormValues(formed);
                                    
                                    const el = document.getElementById("student-record-form-section");
                                    if (el) el.scrollIntoView({ behavior: "smooth" });
                                  }}
                                  className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded transition"
                                  title="تعديل بيانات ورقة دراسات الطالب المفرزة"
                                >
                                  <Settings className="w-4 h-4" />
                                </button>
                                
                                <button
                                  type="button"
                                  onClick={async () => {
                                    if (window.confirm("هل أنت متأكد من رغبتك في حذف هذا الطالب وسجلاته بالكامل على خادم الكنترول؟")) {
                                      const updatedRows = [...(resultsSheets[currentEditGrade] || [])];
                                      updatedRows.splice(rIdx, 1);
                                      const updated = { ...resultsSheets, [currentEditGrade]: updatedRows };
                                      await saveToBackend(updated);
                                      setSaveStatus({
                                        type: "success",
                                        text: "تم حذف الطالب وسجلاته بنجاح من شيت الكنترول."
                                      });
                                      setTimeout(() => setSaveStatus(null), 4000);
                                    }
                                  }}
                                  className="p-1.5 text-rose-600 hover:bg-rose-50 rounded transition"
                                  title="حذف الطالب تماماً من الكشوفات"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* FAST COPY-PASTE BLOCK INGESTION SECTION */}
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-150 space-y-4">
                  <div className="text-right">
                    <h5 className="font-extrabold text-xs text-slate-800 flex items-center gap-1 justify-start">
                      <Clipboard className="w-4 h-4 text-indigo-700" />
                      <span>رابعاً: بوابة لصق خلايا شيتات إكسل المكتملة لسهولة الرصد والنسخ 📋</span>
                    </h5>
                    <p className="text-[10px] text-slate-400">انسخ عدة صفوف من جدول إكسل المدرسي والصقها بالصندوق، سيتكفل الكنترول بتقسيمها وتعبئة الصف بشكل فوري.</p>
                  </div>

                  <textarea
                    rows={4}
                    value={pasteText}
                    onChange={(e) => setPasteText(e.target.value)}
                    placeholder="قم بنسخ الخلايا ولصقها هنا (الصف الأول يمكن أن يحمل أسماء الأعمدة مثل: رقم الطالب، اسم الطالب، اللغة العربية... إلخ)..."
                    className="w-full p-3.5 bg-white border border-slate-200 rounded-xl text-xs font-mono text-right focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={async () => {
                        if (!pasteText.trim()) {
                          alert("يرجى إدخال الخلايا المنسوخة أولاً.");
                          return;
                        }

                        const lines = pasteText.split(/\r?\n/).filter(line => line.trim().length > 0);
                        if (lines.length === 0) return;

                        const parsedRows: ResultRow[] = [];
                        const firstLineCells = lines[0].split("\t").map(cell => cell.trim());

                        // Guess if first line is a header
                        const hasHeaders = firstLineCells.some(
                          cell => cell.includes("رقم") || cell.includes("اسم") || cell.includes("كود") || cell.includes("مادة") || cell.includes("تقدير")
                        );

                        let headers: string[] = [];
                        let dataStartIdx = 0;

                        if (hasHeaders) {
                          headers = firstLineCells;
                          dataStartIdx = 1;
                        } else {
                          headers = getColumns(currentEditGrade);
                        }

                        for (let i = dataStartIdx; i < lines.length; i++) {
                          const cells = lines[i].split("\t").map(cell => cell.trim());
                          const row: ResultRow = {};
                          
                          headers.forEach((headerName, cellIdx) => {
                            const val = cells[cellIdx] !== undefined ? cells[cellIdx] : "";
                            if (val !== "") {
                              row[headerName] = isNaN(Number(val)) || val === "" ? val : Number(val);
                            }
                          });

                          // Ensure ID & Name maps cleanly
                          const val0 = cells[0] !== undefined ? cells[0] : "";
                          const val1 = cells[1] !== undefined ? cells[1] : "";
                          
                          const idCol = Object.keys(row).find(k => k.includes("رقم") || k.includes("كود"));
                          if (!idCol) row["رقم الطالب"] = val0;
                          
                          const nameCol = Object.keys(row).find(k => k.includes("اسم") || k.includes("الاسم"));
                          if (!nameCol) row["اسم الطالب"] = val1;

                          parsedRows.push(row);
                        }

                        const updated = { ...resultsSheets, [currentEditGrade]: parsedRows };
                        await saveToBackend(updated);

                        setPasteText("");
                        alert(`نجح الكنترول في فرز ورصد عدد (${parsedRows.length}) صفاً لطلاب الصف "${currentEditGrade}" وحفظها ببيانات الخادم! 🛰️📊`);
                      }}
                      className="bg-indigo-650 hover:bg-indigo-750 text-white font-extrabold px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-sm cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>فرز واستيراد الخلايا الملصقة مباشرة للكنترول 📥</span>
                    </button>
                  </div>
                </div>

                <div className="p-4 bg-indigo-50 text-indigo-950 rounded-2xl text-[10.5px] font-bold text-center leading-relaxed border border-indigo-100/55">
                  🛡️ <strong>إشعار الكنترول الآمن:</strong> كافة العلميات المنفذة هنا مرتبطة بقناة اتصال مغلقة مباشرة بملف قاعدة بيانات الخادم (JSON Database API) ليتسنى حفظ الدرجات بصورة ثابتة ودائمة غير قابلة للتلف.
                </div>

              </div>
            </div>
          )}

        </div>
      )}

      {/* Advanced QR Scanning Module Center */}
      {isScannerOpen && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto animate-fade-in text-right">
          <div className="bg-white rounded-3xl w-full max-w-2xl border border-slate-100 shadow-2xl overflow-hidden flex flex-col">
            
            <div className="p-6 bg-gradient-to-r from-indigo-750 to-[#0284c7] text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-white/20 rounded-xl">
                  <QrCode className="w-5 h-5 text-white animate-pulse" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-white">مركز الاستعلام المعتمد للمسح والبطاقات الذكية</h3>
                  <p className="text-[10px] text-sky-100">امسح الكود عبر الكاميرا أو جرب كروكيات الطلاب التجريبية</p>
                </div>
              </div>
              <button
                type="button"
                onClick={stopCameraAndClose}
                className="p-1 px-2.5 hover:bg-white/20 transition rounded-lg text-white font-bold cursor-pointer text-sm flex items-center gap-1"
              >
                <span>إغلاق البوابة</span>
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 border-b border-slate-100 p-2 grid grid-cols-3 gap-1">
              <button
                type="button"
                onClick={() => {
                  setScannerMode("live");
                  startCamera();
                }}
                className={`py-2 rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1.5 ${
                  scannerMode === "live" ? "bg-white text-indigo-700 shadow-sm border border-slate-150" : "text-slate-500 hover:text-slate-900"
                }`}
              >
                <Camera className="w-4 h-4" />
                <span>شاشة الكاميرا</span>
              </button>
              
              <button
                type="button"
                onClick={() => {
                  setScannerMode("upload");
                  if (activeStreamRef.current) {
                    activeStreamRef.current.getTracks().forEach(track => track.stop());
                    activeStreamRef.current = null;
                  }
                }}
                className={`py-2 rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1 text-slate-700 ${
                  scannerMode === "upload" ? "bg-white text-indigo-700 shadow-sm border border-slate-150" : "text-slate-500 hover:text-slate-900"
                }`}
              >
                <ImageIcon className="w-4 h-4 text-emerald-600" />
                <span>رفع كود QR</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setScannerMode("demo");
                  if (activeStreamRef.current) {
                    activeStreamRef.current.getTracks().forEach(track => track.stop());
                    activeStreamRef.current = null;
                  }
                }}
                className={`py-2 rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1.5 ${
                  scannerMode === "demo" ? "bg-white text-indigo-700 shadow-sm border border-slate-150" : "text-slate-500 hover:text-slate-900"
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>البطاقات المعتمدة</span>
              </button>
            </div>

            <div className="p-6 flex-1 bg-slate-50/50">
              
              {scannerMode === "live" && (
                <div className="space-y-4 text-center">
                  {cameraError ? (
                    <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl text-rose-700 text-xs text-right space-y-2">
                      <p className="font-extrabold text-sm">⚠️ تعذر تشغيل الكاميرا المباشرة</p>
                      <p>{cameraError}</p>
                    </div>
                  ) : (
                    <div className="relative mx-auto w-full max-w-sm aspect-square bg-slate-950 rounded-2xl overflow-hidden border-4 border-slate-800 shadow-inner flex items-center justify-center">
                      
                      {isCameraLoading && (
                        <div className="absolute inset-0 z-10 bg-slate-950 flex flex-col items-center justify-center gap-3 text-slate-400">
                          <span className="w-10 h-10 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin"></span>
                          <span className="text-xs font-bold">جاري تشغيل ميزان الكاميرا...</span>
                        </div>
                      )}

                      <video 
                        ref={videoRef}
                        className="w-full h-full object-cover transform -scale-x-100"
                        playsInline
                        muted
                      />

                      <div className="absolute inset-0 border-[32px] border-slate-950/40 pointer-events-none flex items-center justify-center">
                        <div className="w-56 h-56 border-2 border-indigo-500 rounded-xl relative flex items-center justify-center animate-pulse">
                          <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-indigo-650 -mt-1 -mr-1 rounded-tr-lg"></div>
                          <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-indigo-650 -mt-1 -ml-1 rounded-tl-lg"></div>
                          <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-indigo-650 -mb-1 -mr-1 rounded-br-lg"></div>
                          <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-indigo-650 -mb-1 -ml-1 rounded-tl-lg"></div>
                          <div className="absolute left-0 right-0 h-0.5 bg-emerald-500 shadow-[0_0_10px_2px_rgba(16,185,129,0.8)] animate-bounce top-1/4"></div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {scannerMode === "upload" && (
                <div className="space-y-6 text-center max-w-sm mx-auto py-4">
                  <div className="border-2 border-dashed border-slate-300 rounded-2xl p-8 hover:border-indigo-500 hover:bg-indigo-50/5 transition-all text-center relative group">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleQRImageUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <div className="space-y-3 pointer-events-none">
                      <div className="w-12 h-12 bg-indigo-55 text-indigo-700 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition duration-150">
                        <Upload className="w-6 h-6" />
                      </div>
                      <div className="space-y-1">
                        <p className="font-extrabold text-xs text-slate-800 font-display">اسحب كود الطالب أو انقر للتحميل</p>
                        <p className="text-[10px] text-slate-400">يدعم تحميل صور هويات الطلاب بترميز الباركود والـ QR</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {scannerMode === "demo" && (
                <div className="space-y-6 text-right">
                  <div className="p-4 bg-amber-50 text-amber-900 rounded-2xl text-[11px] border border-amber-200 leading-relaxed">
                    🌟 <strong>المحاكاة الذكية السريعة:</strong> انقر أدناه على أي طالب لتجربة مسح الباركود الفوري وتفريغ درجته وكشف شهادته منسقة في كسر من الثانية:
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { id: "101", name: "عمر أحمد اليوسف", class: "الصف السادس الأساسي", color: "from-sky-700 to-indigo-600" },
                      { id: "102", name: "سارة محمد الكردي", class: "الصف التاسع الأساسي", color: "from-rose-600 to-pink-500" },
                      { id: "103", name: "يوسف محمد الكردي", class: "الصف الأول الأساسي", color: "from-slate-700 to-slate-800" }
                    ].map((card, idx) => (
                      <div 
                        key={idx}
                        className="bg-white rounded-2xl border border-slate-200 p-3 shadow-sm relative overflow-hidden flex flex-col justify-between hover:shadow-md transition duration-200"
                      >
                        {simulatedScanningIndex === idx && (
                          <div className="absolute inset-0 bg-slate-950/80 z-20 flex flex-col items-center justify-center text-white p-2 text-center">
                            <span className="w-5 h-5 rounded-full border-2 border-white border-t-transparent animate-spin mb-2"></span>
                            <span className="text-[9px] font-bold text-sky-200">جاري مسح الـ QR...</span>
                            <div className="absolute left-0 right-0 h-1 bg-emerald-400 top-0 animate-bounce"></div>
                          </div>
                        )}

                        <div className="space-y-1 text-right">
                          <span className={`text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-gradient-to-r ${card.color}`}>
                            هوية طالب ذكية
                          </span>
                          <p className="font-extrabold text-[#111827] text-[11px] truncate mt-1">{card.name}</p>
                          <p className="text-[9.5px] text-slate-400 font-mono font-bold">كود ID: {card.id}</p>
                        </div>

                        <div className="my-2 py-1 bg-slate-50 rounded-xl flex items-center justify-center border border-slate-100">
                          <img 
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${card.id}&color=1e1b4b&bgcolor=f8fafc`} 
                            alt={`QR for student ${card.id}`}
                            className="w-16 h-16 object-contain"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => handleManualSimulateScan(card.id, idx)}
                          className="w-full py-1.5 bg-[#0ea5e9] hover:bg-indigo-650 text-white rounded-lg text-[9px] font-black transition flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <span>محاكاة السيرة</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <span className="text-[9px] text-slate-550 font-bold">بوابة أمن وحفظ البيانات الكودية لعام 2026</span>
              <button
                type="button"
                onClick={stopCameraAndClose}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                إغلاق
              </button>
            </div>

          </div>
        </div>
      )}

      {/* STEP C: Render Results Card if Searched and Found */}
      {hasSearched && studentResultRow && (() => {
        const subjectKeys = Object.keys(studentResultRow).filter(
          (k) =>
            !k.includes("اسم الطالب") &&
            !k.includes("رقم الطالب") &&
            !k.includes("الصف الدراسي") &&
            !k.includes("رقم") &&
            !k.includes("اسم") &&
            !k.includes("كود") &&
            !k.includes("مجموع") &&
            !k.includes("المجموع") &&
            !k.includes("التقدير العام") &&
            !k.includes("التقدير") &&
            !k.includes("النسبة") &&
            !k.includes("شعبة") &&
            !k.includes("الشعبة") &&
            studentResultRow[k] !== undefined &&
            studentResultRow[k] !== null &&
            String(studentResultRow[k]).trim() !== ""
        );

        let computedTotal = 0;
        let maxPossibleTotal = 0;
        subjectKeys.forEach((k) => {
          const val = Number(studentResultRow[k]);
          if (!isNaN(val)) {
            computedTotal += val;
            maxPossibleTotal += 100;
          }
        });

        const explicitTotalVal = studentResultRow["المجموع"] || studentResultRow["مجموع"];
        const totalScore = explicitTotalVal !== undefined ? Number(explicitTotalVal) : computedTotal;

        const explicitPercentageVal = studentResultRow["النسبة"] || studentResultRow["النسبة العامة"] || studentResultRow["النسبة %"];
        let overallPercentage = 0;
        if (explicitPercentageVal !== undefined) {
          overallPercentage = Number(String(explicitPercentageVal).replace("%", ""));
        } else if (maxPossibleTotal > 0) {
          overallPercentage = Math.round((computedTotal / maxPossibleTotal) * 100);
        } else {
          overallPercentage = 87;
        }

        const explicitGradeVal = studentResultRow["التقدير العام"] || studentResultRow["التقدير"];
        let generalGrade = String(explicitGradeVal || "");
        if (!generalGrade) {
          if (overallPercentage >= 90) generalGrade = "ممتاز";
          else if (overallPercentage >= 80) generalGrade = "جيد جداً";
          else if (overallPercentage >= 70) generalGrade = "جيد";
          else if (overallPercentage >= 50) generalGrade = "مقبول";
          else generalGrade = "ضعيف / راسب";
        }

        const classRows = resultsSheets[studentResultGrade] || [];
        let computedRank = 1;
        if (classRows.length > 1) {
          const totalsWithIds = classRows.map(row => {
            let rowTotal = 0;
            subjectKeys.forEach((k) => {
              const val = Number(row[k]);
              if (!isNaN(val)) rowTotal += val;
            });
            const expTotal = row["المجموع"] || row["مجموع"];
            return {
              id: String(row["رقم الطالب"] || row["رقم"] || ""),
              total: expTotal !== undefined ? Number(expTotal) : rowTotal
            };
          });
          totalsWithIds.sort((a, b) => b.total - a.total);
          const currentStudentId = String(studentResultRow["رقم الطالب"] || studentResultRow["رقم"] || searchQuery);
          const foundIndex = totalsWithIds.findIndex(item => item.id === currentStudentId);
          if (foundIndex !== -1) {
            computedRank = foundIndex + 1;
          }
        }

        const studentDivision = String(studentResultRow["الشعبة"] || studentResultRow["شعبة"] || "أ");
        const studentName = String(studentResultRow["اسم الطالب"] || studentResultRow["اسم"] || "غير متوفر");
        const studentExamId = String(studentResultRow["رقم الطالب"] || studentResultRow["رقم"] || searchQuery);
        const isSuccess = overallPercentage >= 50 && !generalGrade.includes("راسب") && !generalGrade.includes("ضعيف");

        const getArabicOrdinal = (rank: number) => {
          if (rank === 1) return "الأول 🥇";
          if (rank === 2) return "الثاني 🥈";
          if (rank === 3) return "الثالث 🥉";
          if (rank === 4) return "الرابع";
          if (rank === 5) return "الخامس";
          if (rank === 6) return "السادس";
          if (rank === 7) return "السابع";
          if (rank === 8) return "الثامن";
          if (rank === 9) return "التاسع";
          if (rank === 10) return "العاشر";
          return `${rank}`;
        };

        return (
          <section
            id="academic-report-card"
            className="bg-white border border-slate-205/60 rounded-3xl overflow-hidden shadow-2xl max-w-4xl mx-auto relative print:border-0 print:shadow-none print:m-0 animate-fade-in text-right"
          >
            {/* Header styled with School Logo, Name, Barcode/QR, and Date both for screen and print */}
            <div className="bg-gradient-to-r from-[#0066cc] to-[#0099ff] text-white p-6 sm:p-8 text-center space-y-4 relative overflow-hidden print:bg-none print:text-black print:border-b-2 print:border-slate-800 print:pb-6 print:pt-4">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.15),transparent)] pointer-events-none print:hidden"></div>
              
              <div className="flex flex-col md:flex-row items-center justify-between gap-6 print:flex-row print:justify-between print:items-center">
                
                {/* School Info (Logo and Name) */}
                <div className="flex items-center gap-4 text-right print:gap-4 print:text-right">
                  <img 
                    src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEipjHQjY9879jbv-7v6nkpdpZnwIcN4KwMuS7_W9nyOS7VfXa8fY49HFUpCiV7TYVjA_CcV5MVFYB8LpKebe_E08xvKBFv7fx7rT1C5IWYxegX_m5vmqET99D__sU2tfAibIWCkfJch1LEmBzMrWc4VBkop_Cxyp4fTTq6TqQK9l97IIOYjRt2ORZDRdQ/s1600/%D8%A7%D9%84%D8%B5%D9%88%D8%B1%D8%A9%20%D8%A7%D9%84%D8%B1%D9%85%D8%B2%D9%8A%D8%A9.jpg" 
                    alt="School Logo" 
                    className="w-20 h-20 object-cover bg-white rounded-full p-1 border-2 border-indigo-200 shadow-md transform hover:scale-105 transition duration-200"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h2 className="text-xl md:text-2xl font-black text-white print:text-slate-900">مدرسة أمل المستقبل الأهلية</h2>
                    <p className="text-xs font-semibold opacity-95 print:text-slate-600">كنترول ورصد النتائج العام المعتمد</p>
                    <p className="text-[10px] opacity-80 print:text-slate-500 mt-1">تاريخ طباعة واعتماد المستند: {new Date().toLocaleDateString('ar-YE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                  </div>
                </div>

                {/* Barcode/QR code container visible in print and on screen */}
                <div className="flex flex-col items-center justify-center space-y-1 bg-white/10 print:bg-slate-50 p-2.5 rounded-2xl border border-white/20 print:border-slate-300 shadow">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(
                      `مدرسة أمل المستقبل الأهلية\n=========================\nالاسم: ${studentName}\nالرقم الامتحاني: ${studentExamId}\nالصف: ${studentResultGrade}\nالنتيجة: ${isSuccess ? "ناجح" : "راسب / دور ثاني"}\nالمجموع: ${totalScore}\nالنسبة: ${overallPercentage}%\nالتقدير: ${generalGrade}\n=========================\nتم التحقق والاعتماد بنجاح من الكنترول العام لعام 2026`
                    )}&color=1e1b4b&bgcolor=ffffff`}
                    alt="Student Barcode"
                    className="w-16 h-16 object-contain"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-[9px] text-white print:text-slate-700 font-extrabold pb-0.5">البوابة الرقمية / الباركود الرسمي للطالب</span>
                </div>

              </div>

              <div className="pt-4 border-t border-white/20 print:border-slate-300 text-center">
                <p className="text-xs md:text-sm font-bold opacity-90 text-white print:text-slate-800">بطاقة درجات الطالب المعتمدة لـ [ {studentResultGrade} ] - العام الدراسي 2025 / 2026 م</p>
              </div>
            </div>

            {/* Profile Details (formatted dynamic/specific per sheet) */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-[#f8fbff] border-b border-[#e5eaf3]">
              <div className="bg-white p-4 rounded-xl border border-[#e5eaf3] shadow-sm flex flex-col justify-center space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">اسم الطالب</span>
                <strong className="text-xs sm:text-sm text-slate-800 font-extrabold truncate">{studentName}</strong>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#e5eaf3] shadow-sm flex flex-col justify-center space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">الرقم الامتحاني</span>
                <strong className="text-xs sm:text-sm text-indigo-950 font-black font-mono">{studentExamId}</strong>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#e5eaf3] shadow-sm flex flex-col justify-center space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">الصف</span>
                <strong className="text-xs sm:text-sm text-slate-800 font-extrabold">{studentResultGrade}</strong>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#e5eaf3] shadow-sm flex flex-col justify-center space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">الشعبة</span>
                <strong className="text-xs sm:text-sm text-slate-800 font-extrabold">{studentDivision}</strong>
              </div>
            </div>

            {/* Table section */}
            <div className="p-6 md:p-8 space-y-4">
              <h3 className="text-base font-black text-[#0066cc] flex items-center gap-1.5 justify-start">
                <BookOpen className="w-5 h-5 animate-pulse" />
                <span>تفاصيل الدرجات والتحصيل الدراسي</span>
              </h3>

              <div className="overflow-x-auto border border-[#e5eaf3] rounded-2xl shadow-sm">
                <table className="w-full border-collapse text-center text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-[#0066cc] text-white font-bold">
                      <th className="p-4 text-right pr-6 font-bold">المادة</th>
                      <th className="p-4 font-bold">درجة الطالب</th>
                      <th className="p-4 font-bold">النهاية الكبرى</th>
                      <th className="p-4 font-bold">النسبة %</th>
                      <th className="p-4 font-bold pl-6">التقدير</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700 font-semibold">
                    {subjectKeys.map((subName) => {
                      const rowVal = studentResultRow[subName];
                      const markNum = Number(rowVal);
                      const isNumeric = !isNaN(markNum);

                      const subjectPercentage = isNumeric ? Math.min(100, Math.max(0, markNum)) : 0;
                      
                      let subjGrade = "مستوفي ✓";
                      if (isNumeric) {
                        if (markNum >= 90) subjGrade = "ممتاز";
                        else if (markNum >= 80) subjGrade = "جيد جداً";
                        else if (markNum >= 70) subjGrade = "جيد";
                        else if (markNum >= 50) subjGrade = "مقبول";
                        else subjGrade = "ضعيف / راسب";
                      } else {
                        subjGrade = String(rowVal);
                      }

                      return (
                        <tr key={subName} className="hover:bg-[#f9fbff] transition duration-150">
                          <td className="p-4 text-right pr-6 text-slate-800 font-extrabold">{subName}</td>
                          <td className="p-4 font-black text-slate-900 font-mono text-xs sm:text-sm">{rowVal}</td>
                          <td className="p-4 text-slate-400 font-mono">100</td>
                          <td className="p-4 font-black text-[#0066cc] font-mono">{isNumeric ? `${subjectPercentage}%` : "-"}</td>
                          <td className="p-4 pl-6">
                            <span className={`inline-block px-3.5 py-1 rounded-full text-[10px] font-black ${
                              subjGrade === "ممتاز" ? "bg-[#e6fff0] text-[#00a651] border border-emerald-100" :
                              subjGrade === "جيد جداً" ? "bg-indigo-50 text-indigo-700 border border-indigo-100" :
                              subjGrade === "جيد" ? "bg-amber-50 text-amber-700 border border-amber-100" :
                              subjGrade.includes("ضعيف") || subjGrade.includes("راسب") ? "bg-rose-50 text-[#e53935] border border-rose-100" :
                              "bg-slate-50 text-slate-750 border border-slate-100"
                            }`}>
                              {subjGrade}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Summary Section */}
            <div className="p-6 md:p-8 bg-[#fafcff] border-t border-slate-100 space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-[#e7edf5] text-center space-y-1 shadow-sm">
                  <h4 className="text-[10px] text-slate-400 font-black">المجموع الكلي</h4>
                  <p className="text-xl sm:text-2xl font-black text-[#0066cc] font-mono">{totalScore}</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-[#e7edf5] text-center space-y-1 shadow-sm">
                  <h4 className="text-[10px] text-slate-400 font-black">النسبة العامة</h4>
                  <p className="text-xl sm:text-2xl font-black text-[#0066cc] font-mono">{overallPercentage}%</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-[#e7edf5] text-center space-y-1 shadow-sm">
                  <h4 className="text-[10px] text-slate-400 font-black">الترتيب بالفصل</h4>
                  <p className="text-xl sm:text-2xl font-black text-[#0066cc]">{getArabicOrdinal(computedRank)}</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-[#e7edf5] text-center space-y-1 shadow-sm">
                  <h4 className="text-[10px] text-slate-400 font-black">التقدير العام</h4>
                  <p className="text-xl sm:text-2xl font-black text-[#0066cc]">{generalGrade}</p>
                </div>
              </div>

              {/* Status block and ribbon */}
              <div className="text-center pt-2">
                <span className={`inline-block px-12 py-3.5 rounded-full text-base sm:text-lg font-bold shadow-sm ${
                  isSuccess 
                    ? "bg-[#e6fff0] text-[#00a651] border border-emerald-150" 
                    : "bg-[#ffeaea] text-[#e53935] border border-rose-150"
                }`}>
                  {isSuccess ? "✅ النتيجة : ناجح" : "❌ النتيجة : راسب / دور ثاني"}
                </span>
              </div>
            </div>

            {/* Success progress visual */}
            <div className="px-6 md:px-8 pb-6 text-right space-y-2">
              <p className="text-xs font-black text-slate-600">نسبة النجاح العامة</p>
              <div className="w-full h-6 bg-[#e5e5e5] rounded-full overflow-hidden shadow-inner border border-slate-200">
                <div 
                  className="h-full bg-gradient-to-r from-[#00b09b] to-[#96c93d] flex items-center justify-center text-white font-mono text-2xs sm:text-xs font-bold transition-all duration-500"
                  style={{ width: `${overallPercentage}%` }}
                >
                  {overallPercentage}%
                </div>
              </div>
            </div>

            {/* Print and Save PDF Styling injection */}
            <style>{`
              @media print {
                body {
                  background: white !important;
                  color: black !important;
                }
                #results-portal-view > *:not(#academic-report-card),
                header, footer, nav, aside,
                .print\\:hidden,
                button,
                form {
                  display: none !important;
                  visibility: hidden !important;
                }
                #academic-report-card {
                  position: absolute !important;
                  left: 0 !important;
                  top: 0 !important;
                  width: 100% !important;
                  border: none !important;
                  box-sizing: border-box !important;
                  box-shadow: none !important;
                }
              }
            `}</style>

            {/* Action Triggers */}
            <div className="p-6 border-t border-slate-100 flex flex-wrap items-center justify-center gap-4 print:hidden bg-slate-50/50">
              <button 
                onClick={handlePrint}
                className="bg-[#0066cc] hover:bg-[#004f9e] text-white font-black px-8 py-3.5 rounded-xl text-xs flex items-center gap-2 shadow whitespace-nowrap transition-all duration-150 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة النتيجة 🖨️</span>
              </button>

              <button 
                onClick={handlePdfDownload}
                className="bg-[#00a651] hover:bg-[#008944] text-white font-black px-8 py-3.5 rounded-xl text-xs flex items-center gap-2 shadow whitespace-nowrap transition-all duration-150 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>حفظ كملف PDF رقمي 📄</span>
              </button>
            </div>

            {/* Official Stamps and Signatures with QR containing Name, ID and grades */}
            <div className="bg-[#f7f9fc] p-6 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-right space-y-1 text-slate-600">
                <p className="text-[11px] font-bold text-slate-700">جميع الحقوق محفوظة © مدرسة أمل المستقبل الأهلية</p>
                <p className="text-[9.5px] text-slate-400 font-mono">التحقق والاعتماد الالكتروني لكود الكنترول العام لعام 2026</p>
              </div>

              <div className="shrink-0 flex items-center gap-4">
                <div className="inline-block rounded-full border-4 border-dashed border-red-500/20 p-1 transform rotate-2 select-none">
                  <div className="bg-red-500/10 text-red-650 font-black text-[9px] uppercase tracking-wider px-3 py-1 rounded-full border border-red-500/10">
                    مدرسة أمل المستقبل الأهلية
                  </div>
                </div>

                <div className="bg-white p-2 rounded-xl border border-[#e5eaf3] shadow-inner flex flex-col items-center justify-center space-y-1">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(
                      `مدرسة أمل المستقبل الأهلية\n=========================\nالاسم: ${studentName}\nالرقم الامتحاني: ${studentExamId}\nالصف: ${studentResultGrade}\nالنتيجة: ${isSuccess ? "ناجح" : "راسب / دور ثاني"}\nالمجموع: ${totalScore}\nالنسبة: ${overallPercentage}%\nالتقدير: ${generalGrade}\n=========================\nتم التحقق والاعتماد بنجاح من الكنترول العام لعام 2026`
                    )}&color=1e1b4b&bgcolor=ffffff`}
                    alt="Verification QR"
                    className="w-16 h-16 object-contain"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-[8px] text-slate-400 font-bold">تحقق الكنترول</span>
                </div>
              </div>
            </div>
          </section>
        );
      })()}

      {/* STEP D: Render Alert If Searched and Not Found */}
      {hasSearched && !studentResultRow && (
        <div className="max-w-xl mx-auto bg-rose-50 border border-rose-100 text-rose-700 p-6 rounded-2xl flex items-start gap-3 text-right">
          <AlertCircle className="w-5 h-5 shrink-0 pt-0.5 text-rose-500" />
          <div className="space-y-1">
            <h4 className="font-extrabold text-sm">عذراً، لم نتمكن من العثور على أي نتائج مطابقة</h4>
            <p className="text-xs text-slate-600 leading-relaxed font-semibold">
              لم نعثر على نتيجة مطابقة لـ "<strong>{searchQuery}</strong>". يرجى التأكد من إدخال رقم الطالب بشكل صحيح (أرقام فقط كأرقام الهوية مثل 101 أو 102 أو 103). في حال عدم رصد الدرجات بعد، يرجى التواصل مع إدارة كنترول المدرسة.
            </p>
          </div>
        </div>
      )}

    </div>
  );
}
