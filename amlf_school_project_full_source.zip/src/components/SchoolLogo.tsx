import React from "react";

export default function SchoolLogo({ className = "w-12 h-12" }: { className?: string }) {
  return (
    <div className={`relative ${className} flex items-center justify-center select-none`}>
      <svg
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-sm"
      >
        {/* Gradients */}
        <defs>
          <linearGradient id="goldGradient" x1="10" y1="10" x2="110" y2="110" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#D4AF37" />
            <stop offset="30%" stopColor="#FFFDD0" />
            <stop offset="70%" stopColor="#C5A021" />
            <stop offset="100%" stopColor="#996515" />
          </linearGradient>
          <linearGradient id="blueGradient" x1="20" y1="100" x2="100" y2="20" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#0B4C8C" />
            <stop offset="50%" stopColor="#1e40af" />
            <stop offset="100%" stopColor="#3b82f6" />
          </linearGradient>
        </defs>

        {/* Golden "M" Left Wing */}
        <path
          d="M 25,95 C 15,80 15,45 35,35 C 45,30 52,42 55,55 C 47,75 35,88 25,95 Z"
          fill="url(#goldGradient)"
        />

        {/* Golden "M" Right Wing */}
        <path
          d="M 95,95 C 105,80 105,45 85,35 C 75,30 68,42 65,55 C 73,75 85,88 95,95 Z"
          fill="url(#goldGradient)"
        />

        {/* Central rising progress Arrow in gradient Blue */}
        <path
          d="M 40,90 L 80,35 L 72,30 L 98,22 L 95,50 L 88,43 L 48,97 Z"
          fill="url(#blueGradient)"
        />

        {/* Gold Accent Connecting Arch on M */}
        <path
          d="M 33,68 C 50,85 70,85 87,68 C 76,55 44,55 33,68 Z"
          fill="#C5A021"
          opacity="0.8"
        />

        {/* Small Academic Graduation Cap on Top center */}
        <g transform="translate(48, 12) scale(0.45)">
          {/* Cap Diamond */}
          <path
            d="M 25,2 L 48,12 L 25,22 L 2,12 Z"
            fill="#1E293B"
            stroke="#C5A021"
            strokeWidth="2"
          />
          {/* Cap Base */}
          <path
            d="M 12,17 L 12,24 C 12,28 38,28 38,24 L 38,17"
            fill="#1E293B"
            stroke="#C5A021"
            strokeWidth="2"
          />
          {/* Hanging Tassel */}
          <path
            d="M 38,17 L 44,28 L 44,34"
            stroke="#D4AF37"
            strokeWidth="1.5"
            fill="none"
          />
        </g>

        {/* Book "العلم نور" Concept banner at the inside of M center */}
        <path
          d="M 40,75 Q 60,70 80,75 L 78,81 Q 60,76 42,81 Z"
          fill="white"
          stroke="#996515"
          strokeWidth="1"
        />
        {/* Arabic Text "العلم نور" */}
        <text
          x="60"
          y="79"
          fill="#1E293B"
          fontSize="5"
          fontWeight="bold"
          textAnchor="middle"
          fontFamily="Cairo, sans-serif"
        >
          العلم نور
        </text>
      </svg>
    </div>
  );
}
