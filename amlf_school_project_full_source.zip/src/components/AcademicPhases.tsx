import React, { useState, useEffect } from "react";
import { 
  Book, 
  Award, 
  Calendar, 
  Users, 
  Activity, 
  FileText, 
  Lock, 
  Unlock, 
  Upload, 
  Plus, 
  Trash2, 
  Check, 
  Sparkles, 
  Clock, 
  ChevronRight, 
  FileUp, 
  ShieldAlert, 
  CheckCircle,
  RotateCcw,
  Clipboard,
  Download,
  Table,
  FileSpreadsheet
} from "lucide-react";
import * as XLSX from "xlsx";

const EXCEL_GRADE_NAMES = [
  "الصف الأول الأساسي",
  "الصف الثاني الأساسي",
  "الصف الثالث الأساسي",
  "الصف الرابع الأساسي",
  "الصف الخامس الأساسي",
  "الصف السادس الأساسي",
  "الصف السابع الأساسي",
  "الصف الثامن الأساسي",
  "الصف التاسع الأساسي",
  "الصف الأول الثانوي",
  "الصف الثاني الثانوي",
  "الصف الثالث الثانوي"
];

interface HomeworkItem {
  id: string;
  subject: string;
  task: string;
  status: "pending" | "done";
  date: string;
}

interface GradeData {
  id: string;
  name: string;
  curriculum: string[];
  homework: HomeworkItem[];
  schedule: { day: string; lessons: string[] }[];
  customSchedule?: string; // Base64 encoding
  customScheduleName?: string;
  customScheduleType?: "image" | "pdf";
}

// Generate fallback metadata so all requested classes are fully integrated
function generateDefaultGrade(phaseId: string, gradeNum: number): GradeData {
  if (phaseId === "elementary") {
    const arabNames = ["الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس"];
    const name = `الصف ${arabNames[gradeNum - 1]} الابتدائي`;
    return {
      id: `e${gradeNum}`,
      name,
      curriculum: [
        `منهج اللغة العربية (المستوى ${gradeNum}): القراءة والمحادثة والقواعد الإملائية الأساسية والخط العربي.`,
        `الرياضيات والحساب (المستوى ${gradeNum}): العمليات الحسابية المتدرجة والمسائل اللفظية والهندسية المبسطة.`,
        `التربية الإسلامية والقرآن الكريم: المأثورات السلوكية ومكارم الأخلاق وسير الأنبياء وحفظ قصار السور الكريمة.`,
        `العلوم المتكاملة (المستوى ${gradeNum}): الملاحظة والتجريب واستنباط طبائع الكون والمياه والبيئات الحية.`,
        `اللغة الإنجليزية التأسيسية: الكلمات والمفردات والحوارات الأولية الممتعة لتنمية مهارات التحدث واللفظ.`
      ],
      homework: [
        { id: `e${gradeNum}-h1`, subject: "لغة عربية", task: `تحضير وحل تمارين الصفحة رقم ${gradeNum * 10} بخط نسخي جميل بنشاط`, status: "pending", date: "2026-05-21" },
        { id: `e${gradeNum}-h2`, subject: "الرياضيات", task: `مراجعة وحل المسائل الفردية بجدول الأرقام بالصفحة المقابلة`, status: "pending", date: "2026-05-22" }
      ],
      schedule: [
        { day: "الأحد", lessons: ["قرآن كريم", "لغة عربية", "رياضيات", "علوم"] },
        { day: "الإثنين", lessons: ["لغة إنجليزية", "رياضيات", "لغة عربية", "تربية فنية"] },
        { day: "الثلاثاء", lessons: ["تربية إسلامية", "علوم", "رياضيات", "رياضة بدنية"] },
        { day: "الأربعاء", lessons: ["لغة عربية", "قرآن كريم", "لغة إنجليزية", "عالم الأحياء"] },
        { day: "الخميس", lessons: ["تقييم إملائي", "نشاط حر متميز", "إذاعة الصف", "مذاكرة موجهة"] }
      ]
    };
  } else if (phaseId === "prep") {
    const arabNames: Record<number, string> = { 7: "السابع الأساسي", 8: "الثامن الأساسي", 9: "التاسع الأساسي" };
    const name = `الصف ${arabNames[gradeNum] || `${gradeNum} الأساسي`}`;
    return {
      id: `p${gradeNum}`,
      name,
      curriculum: [
        `قواعد لغتنا العربية المتكاملة للصف ${arabNames[gradeNum]} (نحو، صرف، تذوق بلاغي، وبحور عروض الشظايا).`,
        `الرياضيات المعمقة (الجبر، الهندسة التحليليّة والمستوية، الإحصاء، مبرهنات ومثلثات فيثاغورث).`,
        `العلوم التفاعلية والفيزياء (أسس الحركة والميكانيكا وقوانين الكيمياء ومسائل الكائنات الجزيئية المكتملة).`,
        `الدراسات والتربية الوطنية والأخلاقية وتاريخ اليمن والوطن العربي والإسلامي ومسارات التجارة والخيرات.`
      ],
      homework: [
        { id: `p${gradeNum}-h1`, subject: "الرياضيات والمنهج", task: `حل تمارين الجبر والهندسة ص ${gradeNum * 12} بدقة ومراجعتها مع المشرف`, status: "pending", date: "2026-05-21" },
        { id: `p${gradeNum}-h2`, subject: "علوم ومعامل", task: `كتابة تقرير معملي لنتائج تجربة الأسبوع بالدفتر مبيناً الفرضية والبرهان`, status: "pending", date: "2026-05-22" }
      ],
      schedule: [
        { day: "الأحد", lessons: ["جبر وهندسة", "علوم طبيعية", "قواعد لغة", "تاريخ معاصر"] },
        { day: "الإثنين", lessons: ["لغة إنجليزية", "تربية إسلامية", "تقنية حاسوب", "جبر وهندسة"] },
        { day: "الثلاثاء", lessons: ["علوم طبيعية", "قواعد لغة", "جغرافيا وطنية", "رياضة بدنية"] },
        { day: "الأربعاء", lessons: ["قرآن وحديث", "لغة إنجليزية", "جبر وهندسة", "معمل العلوم"] },
        { day: "الخميس", lessons: ["حل نماذج أسئلة", "مسابقات مهارية", "إذاعة التميز", "مشاريع تقنية"] }
      ]
    };
  } else {
    const arabNames: Record<number, string> = { 10: "الأول الثانوي", 11: "الثاني الثانوي", 12: "الثالث الثانوي" };
    const name = `الصف ${arabNames[gradeNum] || `${gradeNum} الثانوي`}`;
    return {
      id: `s${gradeNum}`,
      name,
      curriculum: [
        `اللغة العربية المعيارية المتقدمة (بلاغة كلاسيكية نقدية، نصوص أدبية وقصائد العصور العريقة والبيان الشامل).`,
        `الرياضيات الأكاديمية العالية (الدوال، التفاضل والتكامل، اللوغاريتمات، حساب المصفوفات والمحددات والأعداد المركبة).`,
        `الفيزياء الصلبة والذرية المتقدمة، تفاعلات الكيمياء العضوية الشاملة، وعلوم الأحياء الجزيئية وحركية الفلزات.`,
        `مسارات ريادة الأعمال وصناعة المشاريع والتوجيه المهني المتقدم والتحضير الراقي للاختبارات التحصيلية والقبول الجامعي.`
      ],
      homework: [
        { id: `s${gradeNum}-h1`, subject: "تفاضل وتكامل", task: `حل وتفنيذ النموذج التفاضلي للدوال المعقدة بالصفحة المحددة بالملزمة الموحدة`, status: "pending", date: "2026-05-21" },
        { id: `s${gradeNum}-h2`, subject: "كيمياء عضوية", task: `رسم الصيغ البنائية وتسمية الهيدروكربونات الموصوفة بورقة العمل الأسبوعية`, status: "pending", date: "2026-05-22" }
      ],
      schedule: [
        { day: "الأحد", lessons: ["تفاضل وتكامل", "فيزياء حديثة", "كيمياء معقدة", "بلاغة ونصوص"] },
        { day: "الإثنين", lessons: ["لغة إنجليزية", "تكنولوجيا الويب", "تربية إسلامية", "تفاضل وتكامل"] },
        { day: "الثلاثاء", lessons: ["أحياء جزيئية", "تطوير مهني", "كيمياء معقدة", "رياضة بدنية"] },
        { day: "الأربعاء", lessons: ["فيزياء حديثة", "لغة إنجليزية", "بلاغة ونصوص", "مشاريع ريادية"] },
        { day: "الخميس", lessons: ["تدريب القدرات", "مشروع تخرج", "كرة سلة وبدنية", "ندوات وجلسات"] }
      ]
    };
  }
}

// Global initialized default grades map
const INITIAL_MAP: Record<string, GradeData[]> = {
  elementary: [1, 2, 3, 4, 5, 6].map(n => generateDefaultGrade("elementary", n)),
  prep: [7, 8, 9].map(n => generateDefaultGrade("prep", n)),
  secondary: [10, 11, 12].map(n => generateDefaultGrade("secondary", n))
};

export default function AcademicPhases() {
  // Fetch from localStorage if exists to preserve user updates
  const [gradesData, setGradesData] = useState<Record<string, GradeData[]>>(() => {
    const saved = localStorage.getItem("school_academic_grades_dynamic");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback
      }
    }
    return INITIAL_MAP;
  });

  // Keep track of active phase & grade
  const [activePhase, setActivePhase] = useState<string>("elementary");
  const [selectedGradeId, setSelectedGradeId] = useState<string>("e1");

  // Tabs for the interactive Selected Grade Dashboard
  const [dashboardTab, setDashboardTab] = useState<"curriculum" | "homework" | "schedule">("curriculum");

  // Admin Authentication state & forms
  const [adminPassword, setAdminPassword] = useState<string>("");
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [adminAuthError, setAdminAuthError] = useState<string>("");
  const [adminForgotMessage, setAdminForgotMessage] = useState<string>("");

  // Teacher Authentication state & forms
  const [teacherPassword, setTeacherPassword] = useState<string>("");
  const [isTeacherAuthenticated, setIsTeacherAuthenticated] = useState<boolean>(false);
  const [teacherAuthError, setTeacherAuthError] = useState<string>("");
  
  // Custom controls error/success stats
  const [adminStatus, setAdminStatus] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [teacherStatus, setTeacherStatus] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Form states for Admin Upload File Uploader
  const [adminSelectedPhase, setAdminSelectedPhase] = useState<string>("elementary");
  const [adminSelectedGradeId, setAdminSelectedGradeId] = useState<string>("e1");
  const [uploadedBase64, setUploadedBase64] = useState<string>("");
  const [uploadedFileName, setUploadedFileName] = useState<string>("");
  const [uploadedFileType, setUploadedFileType] = useState<"image" | "pdf">("image");

  // Form states for Teacher Edit Form
  const [teacherSelectedPhase, setTeacherSelectedPhase] = useState<string>("elementary");
  const [teacherSelectedGradeId, setTeacherSelectedGradeId] = useState<string>("e1");
  
  // Teacher inputs to add items
  const [newCurriculumItem, setNewCurriculumItem] = useState<string>("");
  const [newHomeworkSubject, setNewHomeworkSubject] = useState<string>("");
  const [newHomeworkTask, setNewHomeworkTask] = useState<string>("");
  const [newHomeworkDate, setNewHomeworkDate] = useState<string>("2026-05-21");

  // Excel and Paste Results states
  const [pasteTargetGrade, setPasteTargetGrade] = useState<string>("الصف الأول الأساسي");
  const [excelPasteText, setExcelPasteText] = useState<string>("");
  const [pastedHeaders, setPastedHeaders] = useState<string[]>([]);
  const [pastedRows, setPastedRows] = useState<Record<string, string | number>[]>([]);
  const [excelImportStatus, setExcelImportStatus] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Persist status updates to local storage
  const saveToStorage = (updatedMap: Record<string, GradeData[]>) => {
    setGradesData(updatedMap);
    localStorage.setItem("school_academic_grades_dynamic", JSON.stringify(updatedMap));
  };

  // Switch phase changes & automatically reset selected grade to corresponding first option
  const handlePhaseChange = (phaseId: string) => {
    setActivePhase(phaseId);
    const list = gradesData[phaseId] || [];
    if (list.length > 0) {
      setSelectedGradeId(list[0].id);
    }
  };

  // Dropdown phase quick sync
  useEffect(() => {
    // Ensure accurate selectedGradeId matches activePhase
    const list = gradesData[activePhase] || [];
    const found = list.find(g => g.id === selectedGradeId);
    if (!found && list.length > 0) {
      setSelectedGradeId(list[0].id);
    }
  }, [activePhase]);

  // Find active grade object
  const activeGrade: GradeData = React.useMemo(() => {
    const list = gradesData[activePhase] || [];
    return list.find(g => g.id === selectedGradeId) || list[0] || INITIAL_MAP.elementary[0];
  }, [gradesData, activePhase, selectedGradeId]);

  // Interactive checkbox toggler for student homework check lists
  const toggleHomeworkStatus = (itemId: string) => {
    const updated = { ...gradesData };
    for (const p in updated) {
      updated[p] = updated[p].map(g => {
        if (g.id === activeGrade.id) {
          return {
            ...g,
            homework: g.homework.map(h => {
              if (h.id === itemId) {
                return { ...h, status: h.status === "pending" ? "done" : "pending" as "pending" | "done" };
              }
              return h;
            })
          };
        }
        return g;
      });
    }
    saveToStorage(updated);
  };

  // Reset all local storage data back to school defaults
  const handleResetToDefaults = () => {
    if (window.confirm("هل أنت متأكد من رغبتك في إعادة تعيين كافة الجداول، المقررات، والواجبات المدرسية إلى القوائم الافتراضية الرسمية؟")) {
      localStorage.removeItem("school_academic_grades_dynamic");
      setGradesData(INITIAL_MAP);
      setAdminStatus({ type: "success", text: "تمت إعادة تعيين كافة البيانات والمناهج والجداول الافتراضية للجميع بنجاح! 🔄" });
      setTimeout(() => setAdminStatus(null), 5000);
    }
  };

  // Administrative schedule publisher uploader
  const handleAdminScheduleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fName = file.name;
    const isPdf = file.type === "application/pdf" || fName.toLowerCase().endsWith(".pdf");
    const reader = new FileReader();

    reader.onload = (event) => {
      const base64Str = event.target?.result as string;
      if (base64Str) {
        setUploadedBase64(base64Str);
        setUploadedFileName(fName);
        setUploadedFileType(isPdf ? "pdf" : "image");
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePublishSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadedBase64) {
      setAdminStatus({ type: "error", text: "يرجى أولاً رفع ملف الجدول (صورة أو ملف PDF) ليتم نشره" });
      return;
    }

    const updated = { ...gradesData };
    const list = updated[adminSelectedPhase] || [];
    const targetIdx = list.findIndex(g => g.id === adminSelectedGradeId);

    if (targetIdx !== -1) {
      list[targetIdx] = {
        ...list[targetIdx],
        customSchedule: uploadedBase64,
        customScheduleName: uploadedFileName,
        customScheduleType: uploadedFileType
      };
      
      updated[adminSelectedPhase] = list;
      saveToStorage(updated);
      setAdminStatus({ 
        type: "success", 
        text: `برافو! تم بنجاح نشر الجدول الدراسي والملف الجديد للصف (${list[targetIdx].name}) وسيتم عرضه فورياً للطلاب والمدرسين!` 
      });
      // Reset publisher state
      setUploadedBase64("");
      setUploadedFileName("");
      
      // Auto toggle view to the published grade so they immediately verify
      setActivePhase(adminSelectedPhase);
      setSelectedGradeId(adminSelectedGradeId);
      setDashboardTab("schedule");

      setTimeout(() => setAdminStatus(null), 6000);
    }
  };

  // Remove administrative custom uploaded schedule and revert to default lesson timetable
  const handleClearCustomSchedule = (phase: string, gradeId: string) => {
    const updated = { ...gradesData };
    const list = updated[phase] || [];
    const targetIdx = list.findIndex(g => g.id === gradeId);

    if (targetIdx !== -1) {
      list[targetIdx] = {
        ...list[targetIdx],
        customSchedule: undefined,
        customScheduleName: undefined,
        customScheduleType: undefined
      };
      updated[phase] = list;
      saveToStorage(updated);
      setAdminStatus({ type: "success", text: "تم بنجاح حذف وإلغاء الجدول الدراسي المخصص والرجوع للجدول المنهجي الافتراضي." });
      setTimeout(() => setAdminStatus(null), 4000);
    }
  };

  // Admin portal login logic with password check
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const SECRET_KEY = "D@r573$E";
    if (adminPassword === SECRET_KEY) {
      setIsAdminAuthenticated(true);
      setAdminAuthError("");
      setAdminStatus({ type: "success", text: "تم تسجيل دخول إدارة المدرسة بنجاح! يمكنك الآن رفع ونشر الجداول." });
      setTimeout(() => setAdminStatus(null), 4000);
    } else {
      setIsAdminAuthenticated(false);
      setAdminAuthError("رمز مرور الإدارة غير صحيح. يرجى إعادة المحاولة.");
    }
  };

  // Admin forgot password logic: trigger email containing the password to amlf.yen@gmail.com
  const handleAdminForgot = (e: React.MouseEvent) => {
    e.preventDefault();
    const SECRET_KEY = "D@r573$E";
    const email = "amlf.yen@gmail.com";
    const subject = encodeURIComponent("استعادة كلمة المرور للوحة الإدارة - مدرسة خطواتنا الذكية");
    const body = encodeURIComponent(`مرحباً بكم،\n\nلقد تلقينا طلباً لاستعادة كلمة المرور الخاصة بلوحة الإدارة لنشر الجداول الرسمية.\n\nكلمة المرور الرسمية هي:\n${SECRET_KEY}\n\nيرجى استخدامها لتسجيل الدخول بأمان وعدم مشاركتها مع أي شخص غير مخول.`);
    
    // Set feedback message
    setAdminForgotMessage("تم تجهيز رسالة بكلمة المرور إلى amlf.yen@gmail.com بنجاح! جاري فتح تطبيق البريد الخاص بك لإرساله...");
    
    // Open standard mailto to physically send the email
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
    
    // Clear message after 8 seconds
    setTimeout(() => {
      setAdminForgotMessage("");
    }, 8000);
  };

  // Teacher portal login logic with exclusive password check
  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const SECRET_KEY = "D@r573$E";
    
    if (teacherPassword === SECRET_KEY) {
      setIsTeacherAuthenticated(true);
      setTeacherAuthError("");
      setTeacherStatus({ type: "success", text: "مرحباً بكم يا معلم المستقبل الأكاديمي الموقر! تم تسجيل الدخول بنجاح." });
      setTimeout(() => setTeacherStatus(null), 4000);
    } else {
      setIsTeacherAuthenticated(false);
      setTeacherAuthError("عذراً، الرمز السري الذي أدخلته غير مطابق مسبقاً للهيئة التدريسية المعتمدة.");
    }
  };

  // Excel workbook multi-sheet ingestion supporting 12 worksheets
  const handleImportExcelResults = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const savedRaw = localStorage.getItem("school_results_by_grade");
        let resultsSheets: Record<string, any[]> = {};
        if (savedRaw) {
          try {
            resultsSheets = JSON.parse(savedRaw);
          } catch (err) {}
        }

        let sheetsProcessed = 0;
        let rowsCount = 0;

        workbook.SheetNames.forEach((sheetName) => {
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json<any>(worksheet);

          let matchedGradeName = EXCEL_GRADE_NAMES.find(g => g.includes(sheetName) || sheetName.includes(g));
          if (!matchedGradeName) {
            const index = workbook.SheetNames.indexOf(sheetName);
            if (index >= 0 && index < EXCEL_GRADE_NAMES.length) {
              matchedGradeName = EXCEL_GRADE_NAMES[index];
            }
          }

          if (matchedGradeName && json.length > 0) {
            resultsSheets[matchedGradeName] = json;
            sheetsProcessed++;
            rowsCount += json.length;
          }
        });

        localStorage.setItem("school_results_by_grade", JSON.stringify(resultsSheets));
        setExcelImportStatus({
          type: "success",
          text: `تم استيراد صفحات شيت الإكسل بنجاح! تم رصد وتحديث (${sheetsProcessed}) ورقة عمل دراسية بإجمالي (${rowsCount}) طالباً وطالبة وسفرها لقاعدة الكنترول 📈`
        });
        setTimeout(() => setExcelImportStatus(null), 8000);
      } catch (err) {
        setExcelImportStatus({
          type: "error",
          text: "فشل استيراد شيت الإكسل. يرجى التأكد من أن الملف بصيغة .xlsx صحيحة ويحتوي على أوراق العمل المطلوبة."
        });
        setTimeout(() => setExcelImportStatus(null), 8000);
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = ""; // Reset
  };

  // Generate and download sample Excel workbook with 12 spreadsheets
  const handleDownloadSampleExcel = () => {
    try {
      const workbook = XLSX.utils.book_new();
      EXCEL_GRADE_NAMES.forEach((gradeName) => {
        const sampleRows = [
          { 
            "رقم الطالب": "101", 
            "اسم الطالب": "أحمد محمد العولقي", 
            "اللغة العربية": 98, 
            "الرياضيات": 95, 
            "العلوم": 92, 
            "التربية الإسلامية": 100,
            "المجموع": 385, 
            "التقدير العام": "ممتاز" 
          },
          { 
            "رقم الطالب": "102", 
            "اسم الطالب": "سارة صقر القاسمي", 
            "اللغة العربية": 88, 
            "الرياضيات": 79, 
            "العلوم": 85, 
            "التربية الإسلامية": 95,
            "المجموع": 347, 
            "التقدير العام": "جيد جداً" 
          }
        ];
        const worksheet = XLSX.utils.json_to_sheet(sampleRows);
        XLSX.utils.book_append_sheet(workbook, worksheet, gradeName.substring(0, 31));
      });
      XLSX.writeFile(workbook, "نموذج_كنترول_مدرسة_أمل_المستقبل_12_صف.xlsx");
      setExcelImportStatus({
        type: "success",
        text: "تم إنشاء وتحميل نموذج شيت الإكسل الاسترشادي ذو الـ 12 ورقة عمل المطلوبة للكنترول الموحد بنجاح! 📂"
      });
      setTimeout(() => setExcelImportStatus(null), 6000);
    } catch (e) {
      setExcelImportStatus({
        type: "error",
        text: "حدث خطأ غير متوقع أثناء تحضير شيت الإكسل الاسترشادي."
      });
    }
  };

  // Paste text parser supporting tab-separated cell pasting directly from Excel
  const handleParsePastedText = (text: string) => {
    setExcelPasteText(text);
    if (!text.trim()) {
      setPastedHeaders([]);
      setPastedRows([]);
      return;
    }

    try {
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      if (lines.length === 0) {
        setPastedHeaders([]);
        setPastedRows([]);
        return;
      }

      // First line are columns/headers
      const headers = lines[0].split('\t').map(h => h.trim()).filter(Boolean);
      if (headers.length === 0) {
        setPastedHeaders([]);
        setPastedRows([]);
        return;
      }

      const rowsData: Record<string, string | number>[] = [];
      for (let i = 1; i < lines.length; i++) {
        const cells = lines[i].split('\t');
        const rowObj: Record<string, string | number> = {};
        headers.forEach((h, hIdx) => {
          let val = cells[hIdx] ? cells[hIdx].trim() : "";
          if (val !== "" && !isNaN(Number(val))) {
            rowObj[h] = Number(val);
          } else {
            rowObj[h] = val;
          }
        });
        rowsData.push(rowObj);
      }

      setPastedHeaders(headers);
      setPastedRows(rowsData);
    } catch (e) {
      console.error("Paste parsing error", e);
    }
  };

  // Confirm and save pasted cells
  const handleConfirmPastedResults = () => {
    if (pastedRows.length === 0) {
      setExcelImportStatus({
        type: "error",
        text: "يرجى أولاً لصق خلايا صالحة من ملف إكسل في الحقل المخصص للتحقق من البيانات."
      });
      return;
    }

    try {
      const savedRaw = localStorage.getItem("school_results_by_grade");
      let resultsSheets: Record<string, any[]> = {};
      if (savedRaw) {
        try {
          resultsSheets = JSON.parse(savedRaw);
        } catch (e) {}
      }

      resultsSheets[pasteTargetGrade] = pastedRows;

      localStorage.setItem("school_results_by_grade", JSON.stringify(resultsSheets));
      
      setExcelImportStatus({
        type: "success",
        text: `تم حفظ وإدراج بيانات النتائج الملصقة بنجاح لـ (${pasteTargetGrade})! تم تحديث سجلات لعدد (${pastedRows.length}) طالباً بنجاح 📋✨`
      });
      setExcelPasteText("");
      setPastedHeaders([]);
      setPastedRows([]);
      setTimeout(() => setExcelImportStatus(null), 8000);
    } catch (err) {
      setExcelImportStatus({
        type: "error",
        text: "فشل حفظ النتائج الملصقة. يرجى مراجعة تناسق البيانات."
      });
    }
  };

  // Teacher actions: addNewCurriculumItem
  const handleAddCurriculumItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCurriculumItem.trim()) return;

    const updated = { ...gradesData };
    const list = updated[teacherSelectedPhase] || [];
    const targetIdx = list.findIndex(g => g.id === teacherSelectedGradeId);

    if (targetIdx !== -1) {
      const currentCurriculum = list[targetIdx].curriculum || [];
      list[targetIdx] = {
        ...list[targetIdx],
        curriculum: [...currentCurriculum, newCurriculumItem.trim()]
      };
      updated[teacherSelectedPhase] = list;
      saveToStorage(updated);
      setNewCurriculumItem("");
      setTeacherStatus({ type: "success", text: "تمت إضافة المادة الدراسية الجديدة للمنهج بنجاح!" });
      setTimeout(() => setTeacherStatus(null), 4000);

      // Force view synchronization to curriculum tab for the edited class
      setActivePhase(teacherSelectedPhase);
      setSelectedGradeId(teacherSelectedGradeId);
      setDashboardTab("curriculum");
    }
  };

  // Teacher actions: deleteCurriculumItem
  const handleDeleteCurriculumItem = (phase: string, gradeId: string, itemIdx: number) => {
    const updated = { ...gradesData };
    const list = updated[phase] || [];
    const targetIdx = list.findIndex(g => g.id === gradeId);

    if (targetIdx !== -1) {
      const filtered = (list[targetIdx].curriculum || []).filter((_, idx) => idx !== itemIdx);
      list[targetIdx] = {
        ...list[targetIdx],
        curriculum: filtered
      };
      updated[phase] = list;
      saveToStorage(updated);
      setTeacherStatus({ type: "success", text: "تم حذف المقرر الدراسي بنجاح." });
      setTimeout(() => setTeacherStatus(null), 3000);

      // Sync views
      setActivePhase(phase);
      setSelectedGradeId(gradeId);
      setDashboardTab("curriculum");
    }
  };

  // Teacher actions: addNewHomeworkItem
  const handleAddHomeworkItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHomeworkSubject.trim() || !newHomeworkTask.trim()) {
      setTeacherStatus({ type: "error", text: "يرجى تعبئة اسم المادة ومحتوى التكليف المنزلي" });
      return;
    }

    const updated = { ...gradesData };
    const list = updated[teacherSelectedPhase] || [];
    const targetIdx = list.findIndex(g => g.id === teacherSelectedGradeId);

    if (targetIdx !== -1) {
      const currentHomework = list[targetIdx].homework || [];
      const newHW: HomeworkItem = {
        id: `hw-${Date.now()}`,
        subject: newHomeworkSubject.trim(),
        task: newHomeworkTask.trim(),
        status: "pending",
        date: newHomeworkDate
      };

      list[targetIdx] = {
        ...list[targetIdx],
        homework: [newHW, ...currentHomework]
      };
      updated[teacherSelectedPhase] = list;
      saveToStorage(updated);
      
      setNewHomeworkSubject("");
      setNewHomeworkTask("");
      setTeacherStatus({ type: "success", text: "تم نشر وتكليف الطلاب بالواجب اليومي الجديد بنجاح! 📝" });
      setTimeout(() => setTeacherStatus(null), 4000);

      // Force view synchronization to homework tab for the edited class
      setActivePhase(teacherSelectedPhase);
      setSelectedGradeId(teacherSelectedGradeId);
      setDashboardTab("homework");
    }
  };

  // Teacher actions: deleteHomeworkItem
  const handleDeleteHomeworkItem = (phase: string, gradeId: string, hwId: string) => {
    const updated = { ...gradesData };
    const list = updated[phase] || [];
    const targetIdx = list.findIndex(g => g.id === gradeId);

    if (targetIdx !== -1) {
      const filtered = (list[targetIdx].homework || []).filter(h => h.id !== hwId);
      list[targetIdx] = {
        ...list[targetIdx],
        homework: filtered
      };
      updated[phase] = list;
      saveToStorage(updated);
      setTeacherStatus({ type: "success", text: "تم سحب وحذف الواجب اليومي بنجاح." });
      setTimeout(() => setTeacherStatus(null), 3000);

      // Sync views
      setActivePhase(phase);
      setSelectedGradeId(gradeId);
      setDashboardTab("homework");
    }
  };

  return (
    <div id="academic-phases-view" className="space-y-12 pb-12 text-right">
      
      {/* Dynamic Intro Header */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <span className="bg-primary/10 text-primary text-xs font-bold px-4 py-1.5 rounded-full select-none inline-flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          مقرراتنا وجداولنا بلمسة ذكية متطورة
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 font-display">
          الأقسام والمراحل التعليمية بمد خطتنا الذكية
        </h1>
        <p className="text-slate-500 text-sm leading-relaxed max-w-2xl mx-auto">
          تفاعل مع الأقسام الثلاثة واكتشف مناهج صفّك وواجباتك اليومية المعتمدة فوراً، مع لوحات تمكين وتوزيع إلكتروني خاصة للإدارة والمعلمين.
        </p>
      </div>

      {/* THREE PHASES BENTO GRID SECTION (Supports side-scrolling on small screens) */}
      <div className="space-y-2">
        <h3 className="font-extrabold text-slate-800 text-xs text-right pr-1 flex items-center gap-1">
          <span>🎯</span>
          <span>تصفح المراحل التعليمية الثلاث (انقر على المرحلة وحدد صفّك عبر المربع):</span>
        </h3>
        
        <div className="flex sm:grid sm:grid-cols-3 gap-6 overflow-x-auto snap-x snap-mandatory pb-4 py-1 px-1 scrollbar-thin scroll-smooth shrink-0">
          
          {/* Card 1: Elementary Phase */}
          <div 
            onClick={() => handlePhaseChange("elementary")}
            className={`min-w-[280px] sm:min-w-0 snap-center rounded-3xl p-6 border transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${
              activePhase === "elementary" 
                ? "bg-gradient-to-br from-blue-50/80 to-indigo-50/40 border-primary shadow-lg ring-2 ring-primary/20 scale-[1.01]" 
                : "bg-white hover:bg-slate-50/80 border-slate-200/80 hover:border-slate-350 shadow-sm"
            }`}
          >
            {/* Top info and icon */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-2xl transition duration-300 ${
                  activePhase === "elementary" ? "bg-primary text-white" : "bg-blue-50 text-blue-600"
                }`}>
                  <Book className="w-6 h-6 group-hover:rotate-6 transition-transform" />
                </div>
                <span className="text-[10px] bg-blue-100/70 text-blue-700 font-black px-2.5 py-1 rounded-lg">الصفوف 1 - 6</span>
              </div>
              <h3 className="font-black text-slate-900 text-md font-display mb-1.5">المرحلة الابتدائية</h3>
              <p className="text-[11px] text-slate-500 leading-normal pl-4 mb-4">تأسيس لغوي وعلمي متين وتطوير ذهني تفاعلي للناشئين والأطفال.</p>
            </div>
            
            {/* Embedded Class Selector Dropdown */}
            <div className="mt-4 pt-4 border-t border-slate-100" onClick={(e) => e.stopPropagation()}>
              <label className="block text-[10px] font-black text-slate-400 mb-2">اختر الصف الدراسي المخصص:</label>
              <select
                id="select-elementary"
                value={activePhase === "elementary" ? selectedGradeId : "placeholder"}
                onChange={(e) => {
                  setActivePhase("elementary");
                  setSelectedGradeId(e.target.value);
                }}
                className="w-full bg-white border border-slate-200 text-xs font-bold py-2.5 px-3 rounded-xl focus:border-primary focus:ring-1 focus:ring-primary/25 cursor-pointer text-slate-800"
              >
                <option value="placeholder" disabled hidden>-- اختر الصف --</option>
                {gradesData.elementary.map(grade => (
                  <option key={grade.id} value={grade.id}>{grade.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Card 2: Preparatory Phase */}
          <div 
            onClick={() => handlePhaseChange("prep")}
            className={`min-w-[280px] sm:min-w-0 snap-center rounded-3xl p-6 border transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${
              activePhase === "prep" 
                ? "bg-gradient-to-br from-amber-50/80 to-orange-50/40 border-accent shadow-lg ring-2 ring-accent/20 scale-[1.01]" 
                : "bg-white hover:bg-slate-50/80 border-slate-200/80 hover:border-slate-350 shadow-sm"
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-2xl transition duration-300 ${
                  activePhase === "prep" ? "bg-accent text-white" : "bg-amber-50 text-accent"
                }`}>
                  <Users className="w-6 h-6 group-hover:rotate-6 transition-transform" />
                </div>
                <span className="text-[10px] bg-amber-100/70 text-amber-700 font-black px-2.5 py-1 rounded-lg">الصفوف 7 - 9</span>
              </div>
              <h3 className="font-black text-slate-900 text-md font-display mb-1.5">المرحلة الإعدادية والأساسية</h3>
              <p className="text-[11px] text-slate-500 leading-normal pl-4 mb-4">خطى التفكير العلمي المعمّق والتحليل وبناء المفاهيم الميكانيكية الرائدة.</p>
            </div>
            
            <div className="mt-4 pt-4 border-t border-slate-100" onClick={(e) => e.stopPropagation()}>
              <label className="block text-[10px] font-black text-slate-400 mb-2">اختر الصف الدراسي المخصص:</label>
              <select
                id="select-prep"
                value={activePhase === "prep" ? selectedGradeId : "placeholder"}
                onChange={(e) => {
                  setActivePhase("prep");
                  setSelectedGradeId(e.target.value);
                }}
                className="w-full bg-white border border-slate-200 text-xs font-bold py-2.5 px-3 rounded-xl focus:border-accent focus:ring-1 focus:ring-accent/25 cursor-pointer text-slate-800"
              >
                <option value="placeholder" disabled hidden>-- اختر الصف --</option>
                {gradesData.prep.map(grade => (
                  <option key={grade.id} value={grade.id}>{grade.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Card 3: Secondary Phase */}
          <div 
            onClick={() => handlePhaseChange("secondary")}
            className={`min-w-[280px] sm:min-w-0 snap-center rounded-3xl p-6 border transition-all duration-300 relative overflow-hidden flex flex-col justify-between cursor-pointer group ${
              activePhase === "secondary" 
                ? "bg-gradient-to-br from-purple-50/80 to-fuchsia-50/40 border-indigo-600 shadow-lg ring-2 ring-indigo-600/20 scale-[1.01]" 
                : "bg-white hover:bg-slate-50/80 border-slate-200/80 hover:border-slate-350 shadow-sm"
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-2xl transition duration-300 ${
                  activePhase === "secondary" ? "bg-indigo-600 text-white" : "bg-purple-50 text-indigo-600"
                }`}>
                  <Award className="w-6 h-6 group-hover:rotate-6 transition-transform" />
                </div>
                <span className="text-[10px] bg-purple-100/70 text-purple-700 font-black px-2.5 py-1 rounded-lg">الصفوف 10 - 12</span>
              </div>
              <h3 className="font-black text-slate-900 text-md font-display mb-1.5">المرحلة الثانوية العامة</h3>
              <p className="text-[11px] text-slate-500 leading-normal pl-4 mb-4">مسارات أكاديمية وريادية متقدمة واثقة نحو القبول والجاهزية للجامعة.</p>
            </div>
            
            <div className="mt-4 pt-4 border-t border-slate-100" onClick={(e) => e.stopPropagation()}>
              <label className="block text-[10px] font-black text-slate-400 mb-2">اختر الصف الدراسي المخصص:</label>
              <select
                id="select-secondary"
                value={activePhase === "secondary" ? selectedGradeId : "placeholder"}
                onChange={(e) => {
                  setActivePhase("secondary");
                  setSelectedGradeId(e.target.value);
                }}
                className="w-full bg-white border border-slate-200 text-xs font-bold py-2.5 px-3 rounded-xl focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600/25 cursor-pointer text-slate-800"
              >
                <option value="placeholder" disabled hidden>-- اختر الصف --</option>
                {gradesData.secondary.map(grade => (
                  <option key={grade.id} value={grade.id}>{grade.name}</option>
                ))}
              </select>
            </div>
          </div>

        </div>
      </div>

      {/* DYNAMIC GRADE INFORMATION DASHBOARD */}
      <div className="bg-white border border-slate-200/65 rounded-3xl shadow-sm overflow-hidden animate-fade-in">
        
        {/* Dashboard Title Ribbon */}
        <div className="bg-slate-900 text-white px-6 sm:px-8 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h2 className="font-black font-display text-base">
              بوابة عرض تفاصيل: <span className="text-yellow-400 underline decoration-wavy underline-offset-4">{activeGrade?.name || "الصف المختار"}</span>
            </h2>
          </div>
          
          {/* Quick Sub-tab selector */}
          <div className="flex items-center bg-slate-800 p-1.5 rounded-xl border border-slate-700 gap-1 w-full sm:w-auto text-[11px] font-bold">
            <button
              onClick={() => setDashboardTab("curriculum")}
              className={`flex-1 px-4 py-1.5 rounded-lg transition ${
                dashboardTab === "curriculum" ? "bg-primary text-white" : "text-slate-300 hover:text-white"
              }`}
            >
              المنهج الدراسي 📚
            </button>
            <button
              onClick={() => setDashboardTab("homework")}
              className={`flex-1 px-4 py-1.5 rounded-lg transition relative ${
                dashboardTab === "homework" ? "bg-primary text-white" : "text-slate-300 hover:text-white"
              }`}
            >
              الواجبات اليومية 📝
              {activeGrade?.homework?.filter(h => h.status === "pending").length > 0 && (
                <span className="absolute -top-1 -left-1 bg-red-500 text-[8px] font-sans px-1.5 py-0.5 rounded-full text-white animate-bounce">
                  {activeGrade.homework.filter(h => h.status === "pending").length}
                </span>
              )}
            </button>
            <button
              onClick={() => setDashboardTab("schedule")}
              className={`flex-1 px-4 py-1.5 rounded-lg transition ${
                dashboardTab === "schedule" ? "bg-primary text-white" : "text-slate-300 hover:text-white"
              }`}
            >
              الحصص والجدول 📅
            </button>
          </div>
        </div>

        {/* Dynamic Inner Node */}
        <div className="p-6 sm:p-8">
          
          {/* TAB 1: CURRICULUM */}
          {dashboardTab === "curriculum" && (
            <div className="space-y-6">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3 justify-start">
                <Book className="w-5 h-5 text-blue-600" />
                <h4 className="font-black text-slate-950 text-sm font-display">مجموعة الكتب والمكتسبات التعليمية لصفّك</h4>
              </div>

              {activeGrade?.curriculum?.length === 0 ? (
                <p className="text-slate-400 italic text-xs text-center py-8">لا يوجد مقررات مدونة حالياً لهذا الصف. يرجى مراجعة المعلم لإضافتها.</p>
              ) : (
                <ul className="grid md:grid-cols-2 gap-4">
                  {activeGrade?.curriculum?.map((item, idx) => (
                    <li 
                      key={idx} 
                      className="p-4 bg-slate-50/80 hover:bg-slate-50 border border-slate-100/75 rounded-2xl flex items-start gap-3 transition"
                    >
                      <span className="w-6 h-6 rounded-lg bg-blue-100 text-blue-700 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-slate-700 text-xs font-semibold leading-relaxed">{item}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {/* TAB 2: INTERACTIVE HOMEWORK */}
          {dashboardTab === "homework" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
                <div className="flex items-center gap-2 justify-start">
                  <Activity className="w-5 h-5 text-amber-600" />
                  <h4 className="font-black text-slate-950 text-sm font-display">الأجندة والواجبات المنزلية المقررة اليوم</h4>
                </div>
                <span className="text-[10px] bg-slate-100 text-slate-500 font-extrabold px-3 py-1 rounded-full">
                  💡 تلميح: انقر على المربع لوضع علامة (مكتمل) لترتيب إنجازك!
                </span>
              </div>

              {activeGrade?.homework?.length === 0 ? (
                <div className="text-center py-12 space-y-3 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                  <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto" />
                  <p className="font-extrabold text-slate-800 text-xs">رائع ومثالي! الطلاب معفون من أي واجبات مضافة لهذا اليوم.</p>
                  <p className="text-[10.5px] text-slate-400">تابع مع كشك الإدارة للمستجدات دائماً.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {activeGrade?.homework?.map((hw) => (
                    <div 
                      key={hw.id}
                      onClick={() => toggleHomeworkStatus(hw.id)}
                      className={`p-4 border rounded-2xl flex items-center justify-between gap-4 transition duration-200 cursor-pointer select-none ${
                        hw.status === "done"
                          ? "bg-slate-50/85 border-slate-100 text-slate-400 line-through"
                          : "bg-white border-amber-100 hover:bg-amber-50/20 text-slate-800"
                      }`}
                    >
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        {/* Checkbox state */}
                        <div className={`w-5.5 h-5.5 rounded-lg border mt-0.5 shrink-0 flex items-center justify-center transition-all ${
                          hw.status === "done"
                            ? "bg-emerald-600 border-emerald-600 text-white"
                            : "bg-white border-slate-300 group-hover:border-slate-450"
                        }`}>
                          {hw.status === "done" && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <span className={`inline-block text-[10px] font-extrabold px-2.5 py-0.5 rounded-md mb-1.5 ${
                            hw.status === "done" 
                              ? "bg-slate-200 text-slate-500" 
                              : "bg-amber-100 text-amber-800"
                          }`}>
                            {hw.subject}
                          </span>
                          <p className={`text-xs font-bold leading-normal truncate ${hw.status === "done" ? "text-slate-400" : "text-slate-850"}`}>{hw.task}</p>
                        </div>
                      </div>

                      <div className="shrink-0 flex items-center gap-2 text-[10px] font-bold text-slate-400">
                        <Clock className="w-3.5 h-3.5 text-slate-350" />
                        <span>الاستحقاق: {hw.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SCHEDULES & TIMETABLES */}
          {dashboardTab === "schedule" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 flex-wrap gap-2">
                <div className="flex items-center gap-2 justify-start">
                  <Calendar className="w-5 h-5 text-indigo-600" />
                  <h4 className="font-black text-slate-950 text-sm font-display">تفاصيل جدول الحصص والخطط الزمنية</h4>
                </div>
                {activeGrade?.customSchedule && (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-extrabold px-3 py-1 rounded-full animate-pulse">
                    ✓ يعرض الآن الجدول الجديد المنشور من الإدارة
                  </span>
                )}
              </div>

              {/* ADMIN PUBLISHED CUSTOM SCHEDULE PREVIEW (IF AVAILABLE) */}
              {activeGrade?.customSchedule ? (
                <div className="space-y-4">
                  
                  {activeGrade.customScheduleType === "pdf" ? (
                    /* PDF Simulated Mockup view with beautiful action bar */
                    <div className="border border-rose-100 rounded-3xl overflow-hidden bg-rose-50/10">
                      <div className="bg-rose-600 text-white px-6 py-4 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <FileText className="w-5 h-5 text-white" />
                          <div className="text-right">
                            <p className="font-extrabold text-xs">{activeGrade.customScheduleName || "جدول دراسي معتمد.pdf"}</p>
                            <p className="text-[9px] text-rose-100 font-bold">ملف ثيقة إلكترونية (PDF) مخصص ومعبّأ للصف</p>
                          </div>
                        </div>
                        <a 
                          href={activeGrade.customSchedule}
                          download={activeGrade.customScheduleName || `جدول_${activeGrade.name}.pdf`}
                          className="bg-white text-rose-700 hover:bg-rose-50 font-bold text-[10px] px-4 py-2 rounded-xl transition shadow-sm select-none"
                        >
                          تحميل وتنزيل المستند 📥
                        </a>
                      </div>
                      
                      {/* Reader view simulation */}
                      <div className="p-8 text-center space-y-4 border-t border-rose-50 flex flex-col items-center">
                        <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center text-rose-700 mb-2">
                          <FileText className="w-8 h-8" />
                        </div>
                        <p className="font-black text-slate-800 text-xs">تم إرفاق مستند PDF صالح ومعتمد للهواتف والنسخ الورقية</p>
                        <p className="text-[11px] text-slate-500 max-w-md">يرجى النقر على زر التحميل المباشر بالأعلى لعرض التخصيص الكامل للجدول بمعدل الدقة الأقصى أو طباعته فورياً.</p>
                      </div>
                    </div>
                  ) : (
                    /* Image rendering */
                    <div className="border border-slate-200 rounded-3xl overflow-hidden bg-slate-50 max-w-2xl mx-auto">
                      <div className="bg-slate-100 px-4 py-3 flex items-center justify-between text-right border-b border-slate-200">
                        <span className="font-extrabold text-[10.5px] text-slate-600 truncate max-w-[240px]">{activeGrade.customScheduleName || "جدول الصف المعتمد"}</span>
                        <a 
                          href={activeGrade.customSchedule} 
                          download={activeGrade.customScheduleName || "الجدول.png"}
                          className="text-primary font-bold text-[10px]"
                        >
                          حفظ وحفظ الصورة التوضيحية 💾
                        </a>
                      </div>
                      <img 
                        src={activeGrade.customSchedule} 
                        alt="جدول الحصص المخصص"
                        referrerPolicy="no-referrer"
                        className="w-full h-auto object-contain max-h-[500px]"
                      />
                    </div>
                  )}

                  {/* Fallback to original layout reference if desired */}
                  <details className="text-right bg-slate-50 p-4 rounded-2xl border cursor-pointer">
                    <summary className="text-xs font-black text-slate-600 outline-none select-none">انقر هنا لعرض التوزع والجدول المنهجي الأساسي كمرجع إضافي 🗓️</summary>
                    <div className="pt-4">{renderDefaultScheduleTable(activeGrade)}</div>
                  </details>

                </div>
              ) : (
                /* Original Standard Schedule table configuration */
                renderDefaultScheduleTable(activeGrade)
              )}

            </div>
          )}

        </div>
      </div>

      {/* ADMIN & TEACHER PANELS (ACCORDIONS) */}
      <section className="bg-slate-100 rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div className="text-right">
            <h3 className="font-black text-slate-900 text-md font-display flex items-center gap-1.5 justify-start">
              <span>🛠️</span>
              <span>لوحة تحكم وتوجيه الصفوف والواجبات الكبرى</span>
            </h3>
            <p className="text-[11.5px] text-slate-500">حصر تعديلات الإدارة لرفع الجداول المكتملة وتكليفات الهيئة التدريسية بكلمة السر الموحدة.</p>
          </div>
          <button
            onClick={handleResetToDefaults}
            className="self-start text-[10.5px] bg-slate-200 hover:bg-slate-300 transition px-3 py-2 rounded-xl text-slate-700 font-extrabold flex items-center gap-1 cursor-pointer select-none"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>إعادة التعيين التلقائي للبيانات الافتراضية 🔄</span>
          </button>
        </div>

        {/* Dynamic Inner Columns */}
        <div className="grid lg:grid-cols-2 gap-8">
          
          {/* COLUMN A: ADMIN PUBLISHING CODES */}
          <div className="bg-white border border-slate-200/60 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2 border-b border-indigo-50 pb-3">
              <span className="w-2 h-5 bg-indigo-600 rounded-full" />
              <h4 className="font-extrabold text-slate-950 text-xs font-display">1. لوحة دخول الإدارة لنشر الجداول الرسمية (صورة / PDF)</h4>
            </div>

            {adminStatus && (
              <div className={`p-3.5 rounded-xl text-[11px] font-bold ${
                adminStatus.type === "success" ? "bg-emerald-50 text-emerald-800 border border-emerald-100" : "bg-rose-50 text-rose-800 border border-rose-100"
              }`}>
                {adminStatus.text}
              </div>
            )}

            {!isAdminAuthenticated ? (
              <form onSubmit={handleAdminLogin} className="space-y-4 text-right">
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  هذا القسم مخصص ومحمي لإدارة المدرسة لنشر الجداول والخطط الرسمية (صورة / PDF). يرجى إدخال كلمة مرور الإدارة للمتابعة:
                </p>
                
                <div className="space-y-1.5">
                  <label className="block text-[10.5px] font-bold text-slate-600">رمز مرور الإدارة:</label>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="أدخل كلمة مرور الإدارة هنا..."
                    className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/20 text-xs py-3 px-3.5 rounded-xl font-bold"
                  />
                  {adminAuthError && (
                    <p className="text-[10px] text-rose-650 font-bold flex items-center gap-1 pl-1">
                      <ShieldAlert className="w-3 h-3 text-rose-600 shrink-0" />
                      <span>{adminAuthError}</span>
                    </p>
                  )}
                  {adminForgotMessage && (
                    <div className="p-2.5 rounded-lg bg-indigo-50 border border-indigo-100/70 text-[10px] text-indigo-900 font-bold leading-relaxed mt-1">
                      {adminForgotMessage}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={handleAdminForgot}
                    className="text-[10.5px] text-primary/95 hover:text-primary font-bold transition hover:underline"
                  >
                    نسيت كلمة المرور؟ 🔑
                  </button>
                  
                  <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-750 text-white font-extrabold px-5 py-2.5 rounded-xl text-xs transition flex items-center gap-1.5 shadow-sm cursor-pointer select-none"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>تحقق ودخول الإدارة 🔐</span>
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handlePublishSchedule} className="space-y-4 text-right">
                
                <div className="p-3 bg-slate-50 rounded-xl space-y-2 mb-1">
                  <div className="flex items-center justify-between text-right">
                    <span className="text-[10.5px] font-extrabold text-indigo-800 flex items-center gap-1">
                      <Unlock className="w-3 h-3" />
                      <span>تسجيل دخول الإدارة مفعّل بنجاح</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAdminAuthenticated(false);
                        setAdminPassword("");
                      }}
                      className="text-[10px] text-slate-400 hover:text-slate-600 font-bold hover:underline"
                    >
                      تسجيل خروج 🔒
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  
                  {/* Select Phase */}
                  <div>
                    <label className="block text-[10.5px] font-bold text-slate-700 mb-1.5">المرحلة التعليمية:</label>
                    <select
                      value={adminSelectedPhase}
                      onChange={(e) => {
                        setAdminSelectedPhase(e.target.value);
                        // Auto select first grade of new phase
                        const firstG = INITIAL_MAP[e.target.value]?.[0]?.id || "e1";
                        setAdminSelectedGradeId(firstG);
                      }}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold p-2.5 text-slate-800"
                    >
                      <option value="elementary">الابتدائية (1 - 6)</option>
                      <option value="prep">الإعدادية وبنود الأساسي (7 - 9)</option>
                      <option value="secondary">الثانوية العامة (10 - 12)</option>
                    </select>
                  </div>

                  {/* Select Grade */}
                  <div>
                    <label className="block text-[10.5px] font-bold text-slate-700 mb-1.5">الصف المستهدف للتعيين:</label>
                    <select
                      value={adminSelectedGradeId}
                      onChange={(e) => setAdminSelectedGradeId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold p-2.5 text-slate-800"
                    >
                      {gradesData[adminSelectedPhase]?.map(grade => (
                        <option key={grade.id} value={grade.id}>{grade.name}</option>
                      ))}
                    </select>
                  </div>

                </div>

                {/* Upload Input */}
                <div className="space-y-2">
                  <label className="block text-[10.5px] font-bold text-slate-700">اختر ملف الجدول (سواء صورة PNG/JPG أو مستند وثائق PDF):</label>
                  
                  <div className="border-2 border-dashed border-slate-200 hover:border-indigo-400 transition-colors rounded-2xl p-5 text-center cursor-pointer relative bg-slate-50/50">
                    <input
                      type="file"
                      accept="image/*, application/pdf"
                      onChange={handleAdminScheduleUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <div className="space-y-2 flex flex-col items-center">
                      <FileUp className="w-8 h-8 text-indigo-500" />
                      <p className="font-extrabold text-[11px] text-slate-700">انقر هنا لتحديد ملف الجدول أو إفلاته</p>
                      <p className="text-[10px] text-slate-400">يدعم تنسيقات الصور والمستندات بحد أقصى مسموح للتحميل مبدئياً</p>
                    </div>
                  </div>

                  {uploadedFileName && (
                    <div className="bg-emerald-50/50 p-3 rounded-xl border border-emerald-100 text-right flex items-center justify-between gap-1.5">
                      <div className="text-right">
                        <p className="font-black text-[10.5px] text-emerald-800 truncate max-w-[200px]">{uploadedFileName}</p>
                        <p className="text-[9.5px] text-emerald-600">جاهز للنشر الإلكتروني والحفظ المباشر</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setUploadedBase64("");
                          setUploadedFileName("");
                        }}
                        className="text-[10px] text-red-650 hover:underline font-bold"
                      >
                        إلغاء 🗑️
                      </button>
                    </div>
                  )}
                </div>

                {/* Publish Action buttons */}
                <div className="flex gap-2.5">
                  <button
                    type="submit"
                    className="flex-1 bg-indigo-650 hover:bg-indigo-750 text-white font-extrabold px-4 py-3 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer select-none"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>تثبيت ونشر جدول الحصص الآن 🚀</span>
                  </button>
                  
                  {gradesData[adminSelectedPhase]?.find(g => g.id === adminSelectedGradeId)?.customSchedule && (
                    <button
                      type="button"
                      onClick={() => handleClearCustomSchedule(adminSelectedPhase, adminSelectedGradeId)}
                      className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold px-3 py-3 rounded-xl text-xs transition"
                    >
                      حذف المرفق
                    </button>
                  )}
                </div>

              </form>
            )}
          </div>

          {/* COLUMN B: TEACHER PORTAL */}
          <div className="bg-white border border-slate-200/60 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2 border-b border-amber-50 pb-3">
              <span className="w-2 h-5 bg-amber-500 rounded-full" />
              <h4 className="font-extrabold text-slate-950 text-xs font-display">2. لوحة دخول المعلمين لإضافة المقررات والواجبات اليومية</h4>
            </div>

            {teacherStatus && (
              <div className={`p-3.5 rounded-xl text-[11px] font-bold ${
                teacherStatus.type === "success" ? "bg-emerald-50 text-emerald-800 border border-emerald-100" : "bg-rose-50 text-rose-800 border border-rose-100"
              }`}>
                {teacherStatus.text}
              </div>
            )}

            {/* Teacher login gate if not authenticated */}
            {!isTeacherAuthenticated ? (
              <form onSubmit={handleTeacherLogin} className="space-y-4 text-right">
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  هذا القسم محمي بقفل تدريسي معتمد للتثبيت والتعديل. الرجاء إدخال كلمة السر الخاصة بالمعلم للمواصلة:
                </p>
                
                <div className="space-y-1.5">
                  <label className="block text-[10.5px] font-bold text-slate-600">الرمز السري للمعلمين المصرح لهم:</label>
                  <input
                    type="password"
                    value={teacherPassword}
                    onChange={(e) => setTeacherPassword(e.target.value)}
                    placeholder="أدخل كلمة مرور معلمي المراحل..."
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-450 focus:ring-1 focus:ring-amber-450/20 text-xs py-3 px-3.5 rounded-xl font-bold"
                  />
                  {teacherAuthError && (
                    <p className="text-[10px] text-rose-650 font-bold flex items-center gap-1 pl-1">
                      <ShieldAlert className="w-3 h-3 text-rose-600 shrink-0" />
                      <span>{teacherAuthError}</span>
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold px-4 py-3 rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer select-none"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>التحقق والدخول للمنصة التدريسية 🔐</span>
                </button>
              </form>
            ) : (
              /* If Authenticated: Teacher editor workspace is visible */
              <div className="space-y-6">
                
                {/* Switch editor targets */}
                <div className="p-3 bg-slate-50 rounded-xl space-y-3">
                  <div className="flex items-center justify-between text-right mb-1">
                    <span className="text-[10.5px] font-extrabold text-amber-800 flex items-center gap-1">
                      <Unlock className="w-3 h-3" />
                      <span>حالة الاتصال: معلم مصرح له</span>
                    </span>
                    <button
                      onClick={() => {
                        setIsTeacherAuthenticated(false);
                        setTeacherPassword("");
                      }}
                      className="text-[10px] text-slate-400 hover:text-slate-600 font-bold hover:underline"
                    >
                      تسجيل خروج 🔓
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[9px] font-bold text-slate-500">المرحلة الأكاديمية:</label>
                      <select
                        value={teacherSelectedPhase}
                        onChange={(e) => {
                          setTeacherSelectedPhase(e.target.value);
                          const firstG = INITIAL_MAP[e.target.value]?.[0]?.id || "e1";
                          setTeacherSelectedGradeId(firstG);
                        }}
                        className="w-full bg-white border border-slate-250 rounded-lg text-xs font-bold p-1.5"
                      >
                        <option value="elementary">الابتدائية (1-6)</option>
                        <option value="prep">الإعدادية الأساسي (7-9)</option>
                        <option value="secondary">الثانوية العامة (10-12)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[9px] font-bold text-slate-500">منهج الصف:</label>
                      <select
                        value={teacherSelectedGradeId}
                        onChange={(e) => setTeacherSelectedGradeId(e.target.value)}
                        className="w-full bg-white border border-slate-250 rounded-lg text-xs font-bold p-1.5"
                      >
                        {gradesData[teacherSelectedPhase]?.map(grade => (
                          <option key={grade.id} value={grade.id}>{grade.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Task Manager Row 1: Add Syllabus Curriculum item */}
                <div className="space-y-2 border-t border-slate-100 pt-4 text-right">
                  <h5 className="text-[11px] font-bold text-slate-800 flex items-center justify-start gap-1">
                    <span>📚</span>
                    <span>تعديل المقررات وإدخال بند كتاب معتمد:</span>
                  </h5>
                  
                  <form onSubmit={handleAddCurriculumItem} className="flex gap-2">
                    <input
                      type="text"
                      value={newCurriculumItem}
                      onChange={(e) => setNewCurriculumItem(e.target.value)}
                      placeholder="امثلة: القواعد النحوية لمستوى الصف، علم الوراثة..."
                      className="flex-1 bg-slate-50 border border-slate-200 p-2 text-xs rounded-xl"
                    />
                    <button
                      type="submit"
                      className="bg-amber-500 hover:bg-amber-600 text-white font-black text-xs px-3 rounded-xl transition duration-150 shrink-0"
                    >
                      إضافة ➕
                    </button>
                  </form>

                  {/* Curriculums current List as reference to delete immediately */}
                  <div className="max-h-24 overflow-y-auto bg-slate-50 border border-slate-100 rounded-xl p-2.5 text-[10px] space-y-1.5">
                    <p className="text-[9px] text-slate-400 font-medium">المقررات الحالية (انقر على السلة للحذف):</p>
                    {gradesData[teacherSelectedPhase]
                      ?.find(g => g.id === teacherSelectedGradeId)
                      ?.curriculum?.map((item, index) => (
                        <div key={index} className="flex items-center justify-between gap-1 border-b border-white-50 pb-1">
                          <span className="text-slate-700 truncate">{index + 1}. {item}</span>
                          <button
                            type="button"
                            onClick={() => handleDeleteCurriculumItem(teacherSelectedPhase, teacherSelectedGradeId, index)}
                            className="text-rose-600 hover:text-rose-800 p-0.5"
                            title="حذف هذا المقرر"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Task Manager Row 2: Posting New Homework assignment */}
                <div className="space-y-2 border-t border-slate-100 pt-4 text-right">
                  <h5 className="text-[11px] font-bold text-slate-800 flex items-center justify-start gap-1">
                    <span>📝</span>
                    <span>نشر تكليف منزلي جديد (واجب يومي):</span>
                  </h5>

                  <form onSubmit={handleAddHomeworkItem} className="space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={newHomeworkSubject}
                        onChange={(e) => setNewHomeworkSubject(e.target.value)}
                        placeholder="المادة الدراسية (لغتي، علوم)"
                        className="bg-slate-50 border border-slate-200 p-2 text-xs rounded-lg"
                      />
                      <input
                        type="date"
                        value={newHomeworkDate}
                        onChange={(e) => setNewHomeworkDate(e.target.value)}
                        className="bg-slate-50 border border-slate-200 p-2 text-xs rounded-lg font-mono text-center"
                      />
                    </div>
                    <textarea
                      value={newHomeworkTask}
                      onChange={(e) => setNewHomeworkTask(e.target.value)}
                      placeholder="اكتب التكليف أو أسئلة الصفحة المخصصة للاستحقاق اليومي..."
                      rows={2}
                      className="w-full bg-slate-50 border border-slate-200 p-2.5 text-xs rounded-lg"
                    />
                    <button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-2 rounded-xl text-xs flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>نشر التكليف والواجب اليومي للطلاب 📝</span>
                    </button>
                  </form>

                  {/* Homeworks current list in select grade to delete */}
                  <div className="max-h-24 overflow-y-auto bg-slate-50 border border-slate-100 rounded-xl p-2.5 text-[10px] space-y-1.5">
                    <p className="text-[9px] text-slate-400 font-medium">تكليفات الواجب المضافة حالياً:</p>
                    {gradesData[teacherSelectedPhase]
                      ?.find(g => g.id === teacherSelectedGradeId)
                      ?.homework?.map((hw) => (
                        <div key={hw.id} className="flex items-center justify-between gap-1.5 border-b border-white-50 pb-1">
                          <span className="text-slate-700 truncate w-3/4">[{hw.subject}] {hw.task}</span>
                          <button
                            type="button"
                            onClick={() => handleDeleteHomeworkItem(teacherSelectedPhase, teacherSelectedGradeId, hw.id)}
                            className="text-rose-600 hover:text-rose-800"
                            title="سحب الواجب"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                  </div>

                </div>

              </div>
            )}
          </div>

        </div>

      </section>

      {/* SECTION C: EXCEL IMPORT & DIRECT PASTE PORTAL */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-205/60 shadow-lg space-y-6 mt-8 text-right font-sans">
        <div className="border-b border-indigo-100 pb-4">
          <h3 className="font-black text-slate-900 text-md sm:text-lg font-display flex items-center gap-2 justify-start">
            <FileSpreadsheet className="w-5 h-5 text-indigo-600 animate-pulse" />
            <span>بوابة رصد نتائج الطلاب المוحدة للكنترول (استيراد إكسل ولصق خلايا) 📊</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
            الآن يمكنك وبكل سهولة رصد نقاط وعلامات الطلاب لـ 12 مرحلة دراسية كاملة دفعة واحدة. يدعم النظام الاستيراد عبر شيت إكسل شامل مقسم على 12 ورقة عمل منفصلة، أو نسخ وتلصيق خلايا الدرجات والنتائج من إكسل مباشرة إلى الحقل المخصص أدناه.
          </p>
        </div>

        {excelImportStatus && (
          <div className={`p-4 rounded-xl text-xs font-black border ${
            excelImportStatus.type === "success" 
              ? "bg-[#e6fff0] text-[#00a651] border-[#c2f0d5]" 
              : "bg-[#ffeaea] text-[#e53935] border-[#fbc4c4]"
          }`}>
            {excelImportStatus.text}
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-8">
          
          {/* Card 1: 12-Sheet Excel Ingestion */}
          <div className="bg-[#f8faff] border border-indigo-100 rounded-2xl p-6 space-y-5 text-right flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-indigo-100/60 pb-3">
                <span className="w-2.5 h-6 bg-indigo-650 rounded-full" />
                <h4 className="font-black text-[#0066cc] text-xs font-display">1. استيراد شيت إكسل الموحد لجميع الفصول (12 ورقة عمل)</h4>
              </div>

              <p className="text-[11px] text-slate-500 leading-relaxed">
                قم برفع كشف علامات مجمع يحتوي على 12 ورقة عمل منفصلة (Sheet مخصصة لكل صف من الأول الابتدائي وحتى الثالث الثانوي). سيتولى النظام مطابقة ورقات عمل الشيت تلقائياً وتحديث كشوفات نتائج الطلاب لتظهر فوراً في بوابة البحث.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleDownloadSampleExcel}
                  className="flex-1 bg-white hover:bg-slate-50 text-indigo-700 border border-indigo-200 font-extrabold px-4 py-3 rounded-xl text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-xs select-none"
                >
                  <Download className="w-4 h-4 text-indigo-650" />
                  <span>تحميل نموذج كشف الإكسل الاسترشادي 📥</span>
                </button>
              </div>

              <div className="border border-indigo-150/40 rounded-xl bg-white p-4">
                <label className="block text-[10.5px] font-black text-indigo-900 mb-2">قم بمسح أو رفع الشيت للتحديث المباشر:</label>
                <div className="border-2 border-dashed border-indigo-200 hover:border-indigo-500 transition-all rounded-xl p-6 text-center cursor-pointer bg-white relative">
                  <input
                    type="file"
                    accept=".xlsx, .xls"
                    onChange={handleImportExcelResults}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="space-y-2 flex flex-col items-center justify-center">
                    <FileSpreadsheet className="w-10 h-10 text-emerald-500" />
                    <p className="font-extrabold text-[11px] text-[#00a651]">اسحب شيت الإكسل المكتمل هنا أو انقر للتصفح</p>
                    <p className="text-[9.5px] text-slate-400">الصيغ المعتمدة: XLSX, XLS فقط من الكنترول الرئيسي</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-indigo-50/50 p-3 rounded-lg border border-indigo-100/50 text-[10px] text-indigo-900 leading-normal mt-4">
              ⚠️ <strong>توجيه إداري:</strong> يرجى الحفاظ على مسميات واجهات الكشوفات في الملف المطابق لتفادي التعذر، مثل: (الصف الأول الأساسي، الصف الثاني الأساسي ... إلخ).
            </div>
          </div>

          {/* Card 2: Directly Grid cell copy paste */}
          <div className="bg-[#fafbfb] border border-slate-205/60 rounded-2xl p-6 space-y-5 text-right flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
                <span className="w-2.5 h-6 bg-emerald-500 rounded-full" />
                <h4 className="font-black text-[#00a651] text-xs font-display">2. نسخ ولصق خلايا النتائج والدرجات مباشرة 📋</h4>
              </div>

              <div className="grid grid-cols-1 gap-2">
                <label className="block text-[10.5px] font-black text-slate-700">اختر الصف الدراسي المستهدف للصق ونقل الخلايا إليه:</label>
                <select
                  value={pasteTargetGrade}
                  onChange={(e) => setPasteTargetGrade(e.target.value)}
                  className="w-full bg-white border border-slate-250 rounded-xl text-xs font-black p-3 text-slate-800"
                >
                  {EXCEL_GRADE_NAMES.map(name => (
                    <option key={name} value={name}>{name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[10.5px] font-black text-slate-705">
                  قم بتحديد ونسخ خلايا الجدول من شيت الإكسل ثم الصقها بالداخل مباشرة:
                </label>
                <textarea
                  value={excelPasteText}
                  onChange={(e) => handleParsePastedText(e.target.value)}
                  placeholder="رقم الطالب	اسم الطالب	اللغة العربية	الرياضيات	العلوم	المجموع	التقدير العام&#10;101	أحمد يحيى العباسي	95	90	92	277	ممتاز&#10;102	فاطمة عمار صالح	98	96	97	291	ممتاز مرتفع"
                  rows={4}
                  dir="auto"
                  className="w-full bg-white border border-slate-200 text-xs p-3.5 rounded-xl font-mono text-right focus:ring-1 focus:ring-emerald-350 focus:border-emerald-450 focus:outline-none"
                />
              </div>

              {/* Live table preview of pasted rows */}
              {pastedRows.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-bold">معاينة حية للشبكة الناتجة قبل الرصد النهائي:</span>
                    <span className="inline-block bg-[#e6fff0] text-[#00a651] px-2.5 py-0.5 rounded-full text-[9px] font-black">
                       تم رصد {pastedRows.length} صف جاهز للاعتماد
                    </span>
                  </div>
                  
                  <div className="overflow-x-auto max-h-36 border border-slate-150 rounded-lg shadow-inner bg-white">
                    <table className="w-full text-center border-collapse text-[9.5px]">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-150 font-bold text-slate-600">
                          {pastedHeaders.map((head, hi) => (
                            <th key={hi} className="p-2 font-bold whitespace-nowrap">{head}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-[#0f172a]">
                        {pastedRows.slice(0, 5).map((row, ri) => (
                          <tr key={ri} className="hover:bg-slate-50/50">
                            {pastedHeaders.map((head, hi) => (
                              <td key={hi} className="p-2 max-w-[120px] truncate">{String(row[head] !== undefined ? row[head] : "-")}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {pastedRows.length > 5 && (
                      <p className="text-[8px] text-slate-400 text-center py-1 bg-slate-50/50 border-t border-slate-50 font-sans">
                        سيتم استيراد بقية الفوج المتكامل ({pastedRows.length - 5} صفوف أخرين) عند الاعتماد.
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleConfirmPastedResults}
              disabled={pastedRows.length === 0}
              className={`w-full font-black py-3.5 rounded-xl text-xs transition duration-150 flex items-center justify-center gap-1.5 shadow mt-4 ${
                pastedRows.length > 0 
                  ? "bg-[#00a651] hover:bg-[#008944] text-white cursor-pointer" 
                  : "bg-slate-200 text-slate-400 cursor-not-allowed"
              }`}
            >
              <Clipboard className="w-4 h-4" />
              <span>تأكيد وحفظ خلايا النتائج الملصقة فوراً للكنترول 📋✨</span>
            </button>
          </div>

        </div>
      </section>

    </div>
  );
}

// Separate helper utility to render default timetable lessons list
function renderDefaultScheduleTable(grade: GradeData) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-150">
      <table className="w-full text-right border-collapse text-xs">
        <thead>
          <tr className="bg-slate-50 text-slate-600 border-b border-slate-150 font-black">
            <th className="p-4 w-28 font-display">اليوم</th>
            <th className="p-4 font-display">الحصة الأولى (8:00 ص)</th>
            <th className="p-4 font-display">الحصة الثانية (8:45 ص)</th>
            <th className="p-4 font-display">الحصة الثالثة (9:30 ص)</th>
            <th className="p-4 font-display">الحصة الرابعة (10:30 ص)</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 text-slate-750">
          {grade?.schedule?.map((row, index) => (
            <tr key={index} className="hover:bg-slate-50/70 transition-colors">
              <td className="p-4 font-black bg-slate-50/50 text-primary w-28 select-none">{row.day}</td>
              {row.lessons.map((lesson, lIdx) => (
                <td key={lIdx} className="p-4">
                  <span className="inline-block px-3 py-1.5 rounded-lg bg-indigo-50/50 text-indigo-950 border border-indigo-100/50 font-bold text-[10.5px]">
                    {lesson}
                  </span>
                </td>
              ))}
              {/* Fallback space */}
              {Array.from({ length: Math.max(0, 4 - row.lessons.length) }).map((_, missingIdx) => (
                <td key={missingIdx} className="p-4 text-slate-350 italic text-[10px]">فسحة أو نشاط موجه</td>
              ))}
            </tr>
          ))}
          {(!grade || !grade.schedule || grade.schedule.length === 0) && (
            <tr>
              <td colSpan={5} className="p-8 text-center text-slate-400 italic">لا يوجد جدول حصص مدون حالياً كمرجع.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
