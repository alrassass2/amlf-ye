import React, { useState } from "react";
import { 
  BookOpen, 
  Award, 
  CheckCircle, 
  ArrowLeft, 
  Users, 
  Shield, 
  Compass, 
  ChevronRight, 
  PhoneCall, 
  GraduationCap,
  Terminal,
  DownloadCloud,
  UploadCloud,
  RefreshCw,
  Lock,
  Unlock,
  Check
} from "lucide-react";

interface HomeProps {
  onNavigate: (tab: string) => void;
  onExplorePhase: (phase: string) => void;
  isDevAuthenticated: boolean;
  setIsDevAuthenticated: (val: boolean) => void;
  handleDownloadFullBackup: () => void;
  handleUploadBackupFileAndSync: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handlePushAllDataToServerSync: () => Promise<boolean>;
}

export default function Home({ 
  onNavigate, 
  onExplorePhase,
  isDevAuthenticated,
  setIsDevAuthenticated,
  handleDownloadFullBackup,
  handleUploadBackupFileAndSync,
  handlePushAllDataToServerSync
}: HomeProps) {
  // Developer Section Inline States
  const [showLocalDevPanel, setShowLocalDevPanel] = useState<boolean>(false);
  const [devLocalPass, setDevLocalPass] = useState<string>(prev => prev || "");
  const [devLocalError, setDevLocalError] = useState<string>("");
  const [syncStatus, setSyncStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [syncMsg, setSyncMsg] = useState<string>("");

  const handleLocalDevLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (devLocalPass === "64a93s" || devLocalPass === "alrassass") {
      setIsDevAuthenticated(true);
      setDevLocalError("");
    } else {
      setDevLocalError("❌ كود فك التشفير الأمني غير صحيح.");
    }
  };

  const executeSync = async () => {
    setSyncStatus("loading");
    setSyncMsg("جاري مزامنة الملفات ورفع كشوف الهيكل البرمجي إلى الاستضافة المعتمدة...");
    const success = await handlePushAllDataToServerSync();
    if (success) {
      setSyncStatus("success");
      setSyncMsg("✓ تم الحفظ والمزامنة السحابية بنجاح! جاري تلقيم الاستضافة وإعادة تشغيل المنصة آلياً...");
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } else {
      setSyncStatus("error");
      setSyncMsg("❌ حدث خطأ أثناء الاتصال بالخادم، يرجى تكرار المحاولة.");
    }
  };

  return (
    <div id="home-view" className="space-y-16 pb-12">
      {/* Hero Banner Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary to-secondary text-white rounded-3xl py-16 px-8 md:px-16 shadow-xl">
        {/* Background Decorative patterns */}
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-accent opacity-10 rounded-full blur-2xl"></div>
        <div className="absolute -bottom-16 -left-16 w-80 h-80 bg-blue-400 opacity-15 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 grid md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-7 space-y-6 text-right">
            <span className="inline-block bg-white/25 text-white font-black px-6 py-2.5 rounded-full text-sm md:text-base border border-white/40 shadow-sm animate-pulse">
              أهلاً بكم في صرح المستقبل والتميز
            </span>
            <h1 className="text-3xl md:text-4xl font-extrabold leading-tight text-white drop-shadow-sm font-display">
              مدرسة أمل المستقبل الأهلية
            </h1>
            <p className="text-blue-100 text-lg md:text-xl font-bold leading-relaxed">
              مرحباً بكم في مدرسة أمل المستقبل الأهلية: تعليم متميز لبناء جيل واعد
            </p>
            
            {/* Quick Actions Panel */}
            <div className="flex flex-wrap gap-4 pt-4 justify-start">
              <button
                id="btn-hero-register"
                onClick={() => onNavigate("register")}
                className="bg-accent hover:bg-amber-600 text-neutral-900 font-bold px-8 py-3.5 rounded-xl transition duration-300 shadow-lg hover:shadow-accent/20 flex items-center gap-2 text-sm"
              >
                <span>التسجيل الإلكتروني المباشر</span>
                <GraduationCap className="w-5 h-5" />
              </button>
              <button
                id="btn-hero-portal"
                onClick={() => onNavigate("student-portal")}
                className="bg-white/10 hover:bg-white/20 text-white border border-white/20 font-semibold px-6 py-3.5 rounded-xl transition duration-300 flex items-center gap-2 text-sm"
              >
                <span>المنصة التعليمية للطلاب</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          <div className="md:col-span-5 flex justify-center relative">
            <div className="relative w-56 h-56 md:w-72 md:h-72 rounded-2xl overflow-hidden shadow-2xl border-4 border-white/10 bg-white">
              <img 
                src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEidrH6MnHQpTLlBdsspA0VEsh4wPZc7IlAPm7jkZuC6vQMhxd-bUKRby2yYZ_4uUZHhBQl7p2AXOUjUIhOz6QAk5bO0s11f_rsaXczAxby9W027qC6nb1lHuad9eaMElqS9MEGTyrhJv7iPhAZdCs3TToymc3ngpXkboWhqJ2TxG4Is-vKPk9ZV6YzepA/s320/3.png"
                alt="Amal Al Mustaqbal Official School Banner" 
                className="w-full h-full object-contain p-4 bg-white"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-sky-600/90 via-[#0284c7]/30 to-transparent flex items-end p-4 select-none">
                <div className="text-right w-full">
                  <p className="text-[10px] text-amber-300 font-bold block mb-0.5">الشعار الرسمي المعتمد</p>
                  <p className="font-extrabold text-white text-xs leading-tight drop-shadow-md">مدرسة أمل المستقبل الأهلية</p>
                </div>
              </div>
            </div>
            {/* Decorative Gold Badge */}
            <div className="absolute -bottom-4 -right-4 bg-yellow-500 text-slate-900 font-bold p-4 rounded-xl shadow-lg flex items-center gap-2 animate-bounce">
              <span className="text-2xl">🥇</span>
              <div className="text-right leading-none">
                <p className="text-[10px] uppercase font-bold text-slate-800">حائزة على</p>
                <p className="text-xs font-black">درع مدرسة العام</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Discreet Developer Panel Section */}
      <div className="bg-slate-100 border border-slate-200 rounded-3xl p-5 text-right space-y-4 shadow-sm" dir="rtl">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-slate-900 text-amber-400 rounded-xl">
              <Terminal className="w-5 h-5" />
            </div>
            <div className="text-right">
              <h4 className="font-extrabold text-slate-900 text-sm">لوحة تحكم كبار المطورين والمزامنة السحابية 💻</h4>
              <p className="text-[10px] text-slate-500">خاص بمهام المطور ومزامن التغييرات سحابياً للاستضافة الرسمية</p>
            </div>
          </div>
          <button
            onClick={() => setShowLocalDevPanel(!showLocalDevPanel)}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[11px] font-black transition flex items-center gap-2 cursor-pointer"
          >
            <span>{showLocalDevPanel ? "إخفاء اللوحة ✕" : "إظهار لوحة المطور ⚙️"}</span>
          </button>
        </div>

        {showLocalDevPanel && (
          <div className="border-t border-slate-200 pt-5 mt-4 space-y-4 transition-all duration-300">
            {!isDevAuthenticated ? (
              <form onSubmit={handleLocalDevLogin} className="max-w-md mx-auto space-y-3 bg-white p-5 rounded-2xl border border-slate-150 shadow-sm text-center">
                <span className="text-[10px] bg-amber-100 text-amber-800 px-3 py-1 rounded-full font-bold">بوابة أمنية مشفرة 🔒</span>
                <p className="text-[11px] font-bold text-slate-600 mt-2">يرجى كتابة رمز التحقق المالي والفني للمطور (64a93s):</p>
                
                <input
                  type="password"
                  required
                  value={devLocalPass}
                  onChange={(e) => setDevLocalPass(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs font-mono tracking-widest focus:outline-none focus:border-slate-400"
                  placeholder="••••••••"
                />
                
                {devLocalError && (
                  <p className="text-[10px] text-rose-600 font-bold bg-rose-50 p-2 rounded-lg">{devLocalError}</p>
                )}

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-black py-2.5 rounded-xl text-xs transition shadow-sm cursor-pointer"
                >
                  تأكيد الاتصال الآمن للمطور 🛡️
                </button>
              </form>
            ) : (
              <div className="grid md:grid-cols-3 gap-5">
                
                {/* 1. Export Master Database button */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3 shadow-sm flex flex-col justify-between text-right">
                  <div className="space-y-1">
                    <div className="text-emerald-600 font-black text-xs flex items-center gap-1.5 justify-start">
                      <DownloadCloud className="w-5 h-5" />
                      <span>تصدير ملفات المنصة بالكامل</span>
                    </div>
                    <p className="text-[10.5px] text-slate-500 leading-relaxed">توليد وحزم ملف Backup بروتوكولي بصيغة JSON يجمع الشيتات والسجلات بالكامل داخل ملف مضغوط (.ZIP).</p>
                  </div>
                  <button
                    onClick={handleDownloadFullBackup}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black py-2.5 rounded-xl transition shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>تحميل ملف مشروع مضغوط بالكامل (.ZIP) 📥</span>
                  </button>
                </div>

                {/* 2. Upload / Sync local file to Host */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3 shadow-sm flex flex-col justify-between text-right">
                  <div className="space-y-1">
                    <div className="text-indigo-600 font-black text-xs flex items-center gap-1.5 justify-start">
                      <UploadCloud className="w-5 h-5" />
                      <span>رفع واستيراد السجلات سحابياً</span>
                    </div>
                    <p className="text-[10.5px] text-slate-500 leading-relaxed">تلقيم وتغذية قاعدة بيانات المنصة من ملف خارجي ومزامنتها لحظياً بالاستضافة.</p>
                  </div>
                  
                  <label className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black py-2.5 rounded-xl transition shadow-sm flex items-center justify-center gap-2 cursor-pointer text-center">
                    <span>رفع وتغذية ملف البيانات 🔄</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleUploadBackupFileAndSync}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* 3. Global Cloud Host Sync Tool which triggers saveDataWithServerSync and refreshes the display */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3 shadow-sm flex flex-col justify-between text-right border-amber-500/20 shadow-amber-500-[2px]">
                  <div className="space-y-1">
                    <div className="text-amber-500 font-black text-xs flex items-center gap-1.5 justify-start">
                      <RefreshCw className={`w-5 h-5 ${syncStatus === 'loading' ? 'animate-spin' : ''}`} />
                      <span>المزامنة الكاملة بالاستضافة الخارجية</span>
                    </div>
                    <p className="text-[10.5px] text-slate-500 leading-relaxed">مزامنة التعديلات سحابياً وتوجيه مخدم الملفات لتحديث الشاشة فورياً بالجانبين.</p>
                  </div>
                  <button
                    onClick={executeSync}
                    disabled={syncStatus === "loading"}
                    className="w-full bg-amber-500 hover:bg-amber-600 disabled:bg-slate-300 text-slate-950 text-xs font-black py-2.5 rounded-xl transition shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>{syncStatus === "loading" ? "جاري الاتصال السحابي..." : "تحديث ومزامنة المنصة بالاستضافة ⚡"}</span>
                  </button>
                </div>

                {/* Status Indicator */}
                {syncMsg && (
                  <div className={`col-span-1 md:col-span-3 p-3.5 rounded-xl text-[11px] text-center font-bold border ${
                    syncStatus === "success" ? "bg-emerald-50 border-emerald-200 text-emerald-800" :
                    syncStatus === "error" ? "bg-rose-50 border-rose-200 text-rose-800" :
                    "bg-blue-50 border-blue-100 text-blue-800 animate-pulse"
                  }`}>
                    {syncMsg}
                  </div>
                )}
                
                {/* Logout Option */}
                <div className="col-span-1 md:col-span-3 text-left">
                  <button
                    onClick={() => setIsDevAuthenticated(false)}
                    className="text-[10px] text-rose-600 hover:underline font-bold"
                  >
                    🔒 إغلاق وتأمين لوحة التطوير
                  </button>
                </div>

              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Stats Summary & Fast Links */}
      <section className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: BookOpen, title: "المنصة الذكية", desc: "دروس تفاعلية وصالة واجبات رقمية متطورة", actionLabel: "دخول منصة الطالب", tab: "student-portal", color: "blue" },
          { icon: Award, title: "نظام النتائج", desc: "بوابة استخراج معتمدة وطباعة كشوف درجات تفصيلية", actionLabel: "بوابة نتائج الطلاب", tab: "results", color: "amber" },
          { icon: Users, title: "بوابة أولياء الأمور", desc: "متابعة الحضور والغياب ودفع الأقساط بشكل فوري", actionLabel: "منصة ولي الأمر", tab: "parent-portal", color: "indigo" },
          { icon: Shield, title: "التسجيل الرقمي", desc: "قدم طلب الالتحاق المدرسي وارفِق المستندات في دقائق", actionLabel: "شاشات التسجيل الإلكتروني", tab: "register", color: "emerald" }
        ].map((item, index) => (
          <div key={index} className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between h-full group text-right">
            <div className="space-y-4">
              <div className={`p-3 rounded-xl w-fit ${
                item.color === "blue" ? "bg-blue-50 text-blue-600" :
                item.color === "amber" ? "bg-amber-50 text-amber-600" :
                item.color === "indigo" ? "bg-indigo-50 text-indigo-600" :
                "bg-emerald-50 text-emerald-600"
              }`}>
                <item.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-800 font-display">{item.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
            </div>
            
            <button
              onClick={() => onNavigate(item.tab)}
              className="mt-6 text-primary group-hover:text-accent font-semibold text-xs flex items-center gap-1 transition-colors justify-start"
            >
              <span>{item.actionLabel}</span>
              <ChevronRight className="w-4 h-4 rotate-180" />
            </button>
          </div>
        ))}
      </section>

      {/* Campaign Admission and Discounts Banner (Direct Flyer Details) */}
      <section className="bg-slate-950 text-white rounded-3xl p-8 md:p-12 shadow-xl relative overflow-hidden border-2 border-amber-500/20">
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-br from-amber-500/10 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-gradient-to-tr from-teal-500/10 to-transparent rounded-full blur-3xl"></div>

        <div className="relative z-10 space-y-10 text-right">
          {/* Campaign Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/10 pb-6">
            <div className="space-y-2">
              <span className="bg-amber-500 text-slate-950 text-xs font-black px-4 py-1 rounded-full uppercase tracking-wider inline-block">
                حملة القبول والتسجيل للعام الدراسي الجديد
              </span>
              <h2 className="text-2xl md:text-3xl font-black font-display text-white">
                مدرسة أمل المستقبل الأهلية: مصنع النجاح والتميز 🎉
              </h2>
              <p className="text-slate-400 text-xs md:text-sm">
                نعلن بكل فخر واعتزاز عن فتح باب التسجيل الإلكتروني للعام الدراسي الجديد بكافة المراحل التعليمية
              </p>
            </div>
            <div className="bg-red-500/90 text-white font-bold text-xs px-5 py-3 rounded-2xl animate-pulse inline-flex items-center gap-2 border border-red-400 border-dashed justify-center">
              <span>⚠️</span>
              <span>المقاعد محدودة جداً! بادر بالتسجيل الآن</span>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-start">
            {/* Discounts Block */}
            <div className="lg:col-span-12 xl:col-span-7 space-y-6">
              <div className="bg-white/5 border border-white/10 p-6 rounded-2xl space-y-4">
                <h3 className="text-md font-bold text-amber-400 font-display flex items-center gap-2 justify-start border-b border-white/5 pb-2">
                  <span>🎁</span>
                  <span>عرض التسجيل المحدود والخصومات الاستثنائية للعام الجديد</span>
                </h3>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2 text-right">
                    <p className="text-sm font-bold text-emerald-400">🆓 الأخ الخامس مجاناً بالكامل!</p>
                    <p className="text-xs text-slate-350 leading-relaxed">
                      يعفى الأخ الخامس المسجل بالمدرسة من الرسوم الدراسية بالكامل دعماً ومشاركة لأهالينا الكرام بمدينة باجل.
                    </p>
                  </div>

                  <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2 text-right">
                    <p className="text-sm font-bold text-amber-300">📉 خصم 30% للأخ الثالث</p>
                    <p className="text-xs text-slate-350 leading-relaxed">
                      خصم فوري مباشر بنسبة 30% من الرسوم الدراسية المترتبة للأخ الثالث المسجل بالصرح الدراسي.
                    </p>
                  </div>

                  <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2 text-right">
                    <p className="text-sm font-bold text-blue-300">🎓 مقاعد مجانية لأوائل المدارس الحكومية</p>
                    <p className="text-xs text-slate-350 leading-relaxed">
                      مقاعد مجانية للطلاب الأوائل المتخرجين من المدارس الحكومية تقديراً لجدهم واجتهادهم المتميز.
                    </p>
                  </div>

                  <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2 text-right">
                    <p className="text-sm font-bold text-purple-300">🏢 خصم 40% لأوائل المدارس الخاصة</p>
                    <p className="text-xs text-slate-350 leading-relaxed">
                      حافز دراسي استثنائي بخصم 40% من الرسوم المدرسية لأوائل الطلاب المتقدمين من المدارس الخاصة بباجل.
                    </p>
                  </div>
                </div>
              </div>

              {/* Campus physical Advantages */}
              <div className="bg-white/5 border border-white/10 p-6 rounded-2xl space-y-4">
                <h3 className="text-md font-bold text-emerald-400 font-display flex items-center gap-2 justify-start border-b border-white/5 pb-2">
                  <span>✨</span>
                  <span>مميزات ومرافق مدرسة أمل المستقبل النموذجية</span>
                </h3>

                <div className="grid md:grid-cols-2 gap-4 text-xs">
                  <div className="flex gap-3 items-start justify-start p-2 hover:bg-white/5 rounded-lg transition duration-150 text-right">
                    <span className="text-emerald-400 text-lg">⚽</span>
                    <div>
                      <p className="font-bold text-white">ملاعب رياضية ومساحات خضراء</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">مساحات ترفيهية خضراء واسعة وملاعب آمنة لممارسة الرياضة والأنشطة البدنية والصحية بمدينة باجل.</p>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start justify-start p-2 hover:bg-white/5 rounded-lg transition duration-150 text-right">
                    <span className="text-emerald-400 text-lg">📚</span>
                    <div>
                      <p className="font-bold text-white">مكتبة مدرسية محفزة وآمنة</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">تضم رصيداً معرفياً منوعاً وقراءات علمية وأدبية وثقافية محببة لنمو فكر الطالب المتكامل.</p>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start justify-start p-2 hover:bg-white/5 rounded-lg transition duration-150 text-right">
                    <span className="text-emerald-400 text-lg">🔬</span>
                    <div>
                      <p className="font-bold text-white">مختبرات علمية متطورة</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">معامل تفاعلية متكاملة لإجراء التجارب العلمية للفيزياء، الكيمياء والأحياء بأمان مطلق.</p>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start justify-start p-2 hover:bg-white/5 rounded-lg transition duration-150 text-right">
                    <span className="text-emerald-400 text-lg">🖥️</span>
                    <div>
                      <p className="font-bold text-white">قاعات دراسية مجهزة بأحدث الوسائل</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">فصول ذكية مزودة بشاشات تفاعلية، تكييف مريح ومقاعد دراسية تناسب مقاييس الجسد الصحية والحديثة.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Why Choose Us Column */}
            <div className="lg:col-span-12 xl:col-span-5 bg-white/5 border border-white/10 p-6 rounded-2xl space-y-6 text-right">
              <h3 className="text-md font-bold text-amber-400 font-display flex items-center gap-2 justify-start border-b border-white/5 pb-2">
                <span>🤔</span>
                <span>لماذا تختار مدرستنا لمستقبل أبنائك؟</span>
              </h3>

              <div className="space-y-4">
                {[
                  { title: "تعليم حديث ومتطور بأحدث الوسائل", desc: "نتبنى منهجية تعليمية ذكية تدمج التطور العلمي بالقيم الأصيلة والمثابرة المعرفية والعملية.", icon: "💻" },
                  { title: "بيئة تعليمية آمنة ومحفزة للطلاب", desc: "نوظف المراقبة التربوية والاهتمام النفسي لضمان بيئة مدرسية خالية من المشاحنات ومحفزة للشغف العلمي والجسدي.", icon: "🛡️" },
                  { title: "كادر تعليمي مؤهل ومتخصص وذو خبرة", desc: "خيرة المربين والأساتذة المتخصصين ذوي الخبرة الطويلة في توصيل الأفكار وتبسيط المواد وتأهيل المتفوقين بباجل.", icon: "🧑‍🏫" },
                  { title: "أنشطة طلابية، رياضية وشاملة", desc: "نؤمن ببناء الجسد والعقل والروح؛ برامج لا صفية، دوري رياضي معشب وحفلات تخريج متميزة وسنوية.", icon: "🏆" }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-3 items-start justify-start p-3 bg-slate-900/40 rounded-xl border border-white/5 hover:border-amber-500/30 transition duration-150 text-right">
                    <span className="text-xl pt-0.5 shrink-0">{item.icon}</span>
                    <div className="space-y-0.5">
                      <p className="font-bold text-xs text-amber-350">{item.title}</p>
                      <p className="text-[10px] text-slate-400 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Official Flyer Section */}
      <section className="bg-gradient-to-br from-indigo-50/50 via-white to-blue-50/50 rounded-3xl border border-slate-100 p-8 shadow-sm text-center space-y-8">
        <div className="max-w-2xl mx-auto space-y-3">
          <span className="bg-emerald-50 text-emerald-850 text-xs font-extrabold px-4 py-1.5 rounded-full border border-emerald-100 uppercase inline-block">
            🗺️ البروشور والدليل البصري المعتمد
          </span>
          <h2 className="text-2xl md:text-3xl font-black font-display text-slate-900 leading-tight">
            دليل التسجيل والقبول - مدرسة أمل المستقبل الأهلية
          </h2>
          <p className="text-slate-500 text-xs md:text-sm">
            نستعرض معكم البوستر والبروشور الإعلاني الرسمي للتعريف بالمدرسة والبرامج والمزايا تحت شعار «العلم نور» لبناء جيل مستقبل متميز.
          </p>
        </div>

        <div className="relative max-w-xl mx-auto rounded-2xl overflow-hidden shadow-xl border-4 border-white bg-slate-50 group transition duration-300 hover:shadow-2xl">
          <img 
            src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgrPNPvHpdX_t8b1SS2neMikLSUnjEiCWAEJ3yAsv-lUDtDHz0Vo1dMR5Astd-uNidoxQEUlbuZkgdkzPyZd8-MIhYizI14tC4d4qNMIkZQD3SbjxrjlsML3y32WK4uosvnOGMABZISo1W02snm001AGgr2FFn61DJ7iHHyc6b_d87O7Ng22j6bBnMB3A/s320/%D9%88%D8%A7%D8%AC%D9%87%D9%87.png"
            alt="بروشور كرت التسجيل والقبول مدرسة أمل المستقبل"
            className="w-full h-auto object-contain mx-auto max-h-[520px] rounded-xl transition duration-300 group-hover:scale-[1.01]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute bottom-3 right-3 bg-slate-900/80 hover:bg-slate-900 text-white font-bold text-[10.5px] py-1.5 px-3 rounded-xl backdrop-blur-sm select-none transition">
            شعار وحملة مدرسة أمل المستقبل الأهلية
          </div>
        </div>
      </section>

      {/* Mission & Vision Bento */}
      <section className="bg-white rounded-3xl border border-slate-100 p-8 md:p-12 shadow-sm">
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
          <span className="text-primary font-bold text-sm tracking-widest uppercase">رؤيتنا ورسالتنا</span>
          <h2 className="text-3xl font-bold font-display text-slate-900">الريادة في البناء والأمل في العطاء</h2>
          <div className="h-1.5 w-24 bg-accent mx-auto rounded-full"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 space-y-4 text-right">
            <div className="w-12 h-12 bg-primary/10 text-primary rounded-xl flex items-center justify-center">
              <Compass className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 font-display">رؤيتنا الأكاديمية</h3>
            <p className="text-slate-600 leading-relaxed text-sm transition-all">
              نسعى لأن نكون النموذج الرائد والأكثر تميزاً في قطاع التعليم الأهلي والخاص، من خلال تنشئة أجيال شغوفة بالبحث والابتكار، متسلحة بالقيم المبادئ، ومواكبة للمتغيرات العلمية والحضارية العصرية لبناء غدٍ أفضل.
            </p>
          </div>

          <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 space-y-4 text-right">
            <div className="w-12 h-12 bg-accent/10 text-accent rounded-xl flex items-center justify-center">
              <CheckCircle className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 font-display">رسالتنا التربوية</h3>
            <p className="text-slate-600 leading-relaxed text-sm">
              توفير بيئة تربوية ملهمة وآمنة وصديقة للتعلم الذاتي التفاعلي بالاعتماد على مناهج متميزة وكوادر تعليمية مؤهلة تأهيلاً شاملاً وتفعيل المشاركة المجتمعية الحقيقية مع أولياء الأمور لتنمية شخصية الطالب فكرياً وجسدياً ورواداً.
            </p>
          </div>
        </div>
      </section>

      {/* Educational Phases Nav Grid */}
      <section className="space-y-8">
        <div className="text-center space-y-3">
          <h2 className="text-2xl md:text-3xl font-bold font-display text-slate-900">المراحل التعليمية بالمدرسة</h2>
          <p className="text-slate-500 max-w-lg mx-auto text-sm">مستويات وبرامج مخصصة مبنية على أسس أكاديمية عالمية لتلبية احتياجات نمو طفلك</p>
        </div>

        <div className="grid sm:grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { tag: "elementary", name: "المرحلة الابتدائية", desc: "تأسيس شامل ومكثف للمواد الرياضية واللغات والعلوم وصقل المهارات السلوكية الراسخة.", age: "6 - 11 سنة", color: "from-blue-500 to-indigo-400" },
            { tag: "prep", name: "المرحلة الإعدادية", desc: "بناء التفكير النقدي، تعزيز المسائل التحليلية وتنمية المشاريع العلمية الابتكارية لطلابنا.", age: "12 - 14 سنة", color: "from-amber-500 to-orange-400" },
            { tag: "secondary", name: "المرحلة الثانوية", desc: "تأهيل شامل وفردي لاختبارات القبول والجامعات وبناء مجسمات البرمجة والقيادة.", age: "15 - 17 سنة", color: "from-teal-500 to-emerald-400" }
          ].map((phase, idx) => (
            <div key={idx} className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between text-right">
              <div className={`h-3 bg-gradient-to-r ${phase.color}`}></div>
              <div className="p-6 space-y-4">
                <span className="text-xs bg-slate-100 text-slate-600 font-medium px-2.5 py-1 rounded-md">{phase.age}</span>
                <h3 className="text-lg font-bold text-slate-800 font-display pt-1">{phase.name}</h3>
                <p className="text-slate-500 text-xs lines-clamp-3 leading-relaxed">{phase.desc}</p>
              </div>
              <div className="px-6 pb-6 pt-2">
                <button
                  onClick={() => onExplorePhase(phase.tag)}
                  className="w-full bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold py-2 rounded-xl transition duration-200 text-xs border border-slate-100 flex items-center justify-center gap-1"
                >
                  <span>استكشف المنهج والجداول</span>
                  <ChevronRight className="w-3.5 h-3.5 rotate-180" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="bg-slate-900 text-white rounded-3xl p-8 md:p-12 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-1/4 w-80 h-80 bg-primary opacity-20 rounded-full blur-3xl"></div>
        <div className="relative z-10 grid md:grid-cols-2 gap-12 items-center text-right">
          <div className="space-y-6">
            <span className="text-accent font-bold text-sm tracking-wider">لماذا أمل المستقبل؟</span>
            <h2 className="text-3xl font-bold font-display text-white">مميزات تحفز الشغف الأكاديمي الحقيقي</h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              تلتزم مدرستنا بتقديم أعلى معايير الجودة الأكاديمية، حيث نوفر ميزات فريدة تجعلنا الخيار الأمثل للمستقبل الأكاديمي والمهني لأبنائكم وبناتكم.
            </p>
            
            <ul className="space-y-4 text-sm">
              {[
                "اعتمادات تعليمية مرخصة ومناهج وطنية ودولية متكاملة.",
                "مختبرات تكنولوجية مجهزة ببرمجيات ذكاء اصطناعي وأدوات روبوتية.",
                "نظام تواصل مباشر فوري على مدار الساعة لأولياء الأمور والإدارة.",
                "مساحات للمواهب الرياضية، وحفلات تكريم وإنجازات موثقة دائمًا."
              ].map((feat, index) => (
                <li key={index} className="flex items-start gap-2 justify-start">
                  <span className="text-accent text-lg pt-0.5">✔</span>
                  <span className="text-slate-200">{feat}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            {[
              { num: "98%", label: "معدل الرضا الأكاديمي" },
              { num: "+1200", label: "خريج وخريجة متفوقين" },
              { num: "100%", label: "تفاعلية المنصة الإلكترونية" },
              { num: "+60", label: "معلم ومعلمة من ذوي الخبرة" }
            ].map((stat, i) => (
              <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl text-center space-y-2">
                <p className="text-3xl font-black text-accent">{stat.num}</p>
                <p className="text-xs text-slate-300">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick CTA banner */}
      <section className="bg-gradient-to-r from-teal-50 to-blue-50 rounded-3xl p-8 md:p-12 border border-blue-100 flex flex-col md:flex-row items-center justify-between text-right gap-6">
        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-slate-900 font-display">هل لديكم أي استفسار مالي أو إداري؟</h3>
          <p className="text-slate-600 text-sm">فريق الدعم الفني والإداري جاهز لخدمتكم وحجز موعد استشارة بمقر المدرسة دائمًا.</p>
        </div>
        <div className="flex gap-4">
          <button
            onClick={() => onNavigate("contact")}
            className="bg-primary hover:bg-blue-800 text-white font-bold px-6 py-3 rounded-xl transition duration-200 text-sm flex items-center gap-2 shadow-md shadow-blue-800/10"
          >
            <PhoneCall className="w-4 h-4" />
            <span>تواصل وموقع المدرسة</span>
          </button>
        </div>
      </section>
    </div>
  );
}
