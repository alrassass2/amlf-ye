import React, { useState, useEffect } from "react";
import { saveDataWithServerSync } from "../data";
import { 
  CreditCard, 
  Bus, 
  BookOpen, 
  Search, 
  Plus, 
  Trash2, 
  RefreshCw, 
  CheckCircle, 
  AlertTriangle, 
  DollarSign, 
  HelpCircle, 
  MapPin, 
  Users, 
  ChevronDown,
  ChevronUp,
  Download,
  Info,
  Lock,
  Unlock,
  Printer,
  FileText,
  Key,
  Mail,
  LogOut,
  Sliders,
  Sparkles,
  Edit3,
  Trash
} from "lucide-react";

// Types matching the required fields
export interface StudentFeeRecord {
  id: string; // ID
  name: string; // Student Name
  grade: string; // Grade
  tuitionFee: number; // رسوم تعليم
  busFee: number; // رسوم نقل وباصات
  uniformFee: number; // رسوم زي مدرسي
  booksFee: number; // رسوم منهج
  amountPaid: number; // كم دفع الطالب رسوم
  busRoute: string; // خط الباص
  seatNumber: string; // رقم المقعد
}

// Active school bus route type definition
export interface BusRouteItem {
  id: string;
  name: string;      // e.g. "خط الحافلة A (ذهبي)"
  route: string;     // e.g. "باكن، الميناء، حي الشعب"
  driver: string;    // e.g. "الكابتن عادل المشجر"
  phone: string;     // e.g. "773195229"
  capacity: number;
  supervisor: string;// e.g. "أ. رائدة محمد"
  status: "active" | "suspended";
}

// Fixed fee schedule by grade level
export const GRADE_FEES_TEMPLATES: Record<string, {
  tuition: number;
  bus: number;
  uniform: number;
  books: number;
}> = {
  "الصف الأول الابتدائي": { tuition: 6000, bus: 2000, uniform: 1500, books: 1500 },
  "الصف الثاني الابتدائي": { tuition: 6000, bus: 2000, uniform: 1500, books: 1500 },
  "الصف الثالث الابتدائي": { tuition: 6500, bus: 2000, uniform: 1500, books: 1500 },
  "الصف الرابع الابتدائي": { tuition: 6500, bus: 2000, uniform: 1500, books: 1550 },
  "الصف الخامس الابتدائي": { tuition: 7000, bus: 2500, uniform: 1500, books: 1600 },
  "الصف السادس الابتدائي": { tuition: 7000, bus: 2500, uniform: 1500, books: 1600 },
  "الصف الأول الإعدادي": { tuition: 8500, bus: 2800, uniform: 1800, books: 1700 },
  "الصف الثاني الإعدادي": { tuition: 8500, bus: 2800, uniform: 1800, books: 1700 },
  "الصف الثالث الإعدادي": { tuition: 9000, bus: 3000, uniform: 1800, books: 1800 },
  "الصف الأول الثانوي": { tuition: 10000, bus: 3500, uniform: 2000, books: 2000 },
  "الصف الثاني الثانوي": { tuition: 11000, bus: 3500, uniform: 2000, books: 2205 },
  "الصف الثالث الثانوي": { tuition: 12000, bus: 4000, uniform: 2200, books: 2500 }
};

export default function FeesDashboard() {
  const [selectedGrade, setSelectedGrade] = useState<string>("الصف السادس الابتدائي");
  const [students, setStudents] = useState<StudentFeeRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>("all"); // 'all', 'paid', 'unpaid'
  
  // Custom Fee Templates State
  const [feesTemplates, setFeesTemplates] = useState<Record<string, {
    tuition: number;
    bus: number;
    uniform: number;
    books: number;
  }>>(() => {
    const saved = localStorage.getItem("school_grade_fees_templates_v2");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return GRADE_FEES_TEMPLATES;
  });

  const saveFeesTemplates = (newTemplates: Record<string, {
    tuition: number;
    bus: number;
    uniform: number;
    books: number;
  }>) => {
    setFeesTemplates(newTemplates);
    localStorage.setItem("school_grade_fees_templates_v2", JSON.stringify(newTemplates));
    saveDataWithServerSync("school_grade_fees_templates_v2", newTemplates);
  };

  // State-driven Bus Routes with supervisors and drivers
  const [busRoutes, setBusRoutes] = useState<BusRouteItem[]>(() => {
    const saved = localStorage.getItem("school_bus_routes_v2");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: "bus-a",
        name: "خط الحافلة A (ذهبي)",
        route: "باجل، الميناء، حي الشعب والأطراف المجاورة",
        driver: "الكابتن عادل المشجر",
        phone: "773195229",
        capacity: 25,
        supervisor: "أ. سلوى أحمد",
        status: "active"
      },
      {
        id: "bus-b",
        name: "خط الحافلة B (فضي)",
        route: "شارع المطار، الحي الغربي والمخطط القديم",
        driver: "الكابتن طارق الهادي",
        phone: "711823901",
        capacity: 25,
        supervisor: "أ. خديجة عمر",
        status: "active"
      },
      {
        id: "bus-c",
        name: "خط الحافلة C (احتياطي)",
        route: "المخطط الدائري، ومجمع الإدارة الأهلية الجديد",
        driver: "الكابتن صبري حزام",
        phone: "739501533",
        capacity: 20,
        supervisor: "أ. ماجد عثمان",
        status: "suspended"
      }
    ];
  });

  const saveBusRoutes = (newRoutes: BusRouteItem[]) => {
    setBusRoutes(newRoutes);
    localStorage.setItem("school_bus_routes_v2", JSON.stringify(newRoutes));
    saveDataWithServerSync("school_bus_routes_v2", newRoutes);
  };

  // Modal control states for modifications
  const [isEditingFeesModalOpen, setIsEditingFeesModalOpen] = useState<boolean>(false);
  const [editTuitionFee, setEditTuitionFee] = useState<number>(0);
  const [editBusFee, setEditBusFee] = useState<number>(0);
  const [editUniformFee, setEditUniformFee] = useState<number>(0);
  const [editBooksFee, setEditBooksFee] = useState<number>(0);

  // Bus Routes admin modal state
  const [isBusModalOpen, setIsBusModalOpen] = useState<boolean>(false);
  const [editingBusRoute, setEditingBusRoute] = useState<BusRouteItem | null>(null);
  const [busRouteFormName, setBusRouteFormName] = useState<string>("");
  const [busRouteFormRoute, setBusRouteFormRoute] = useState<string>("");
  const [busRouteFormDriver, setBusRouteFormDriver] = useState<string>("");
  const [busRouteFormPhone, setBusRouteFormPhone] = useState<string>("");
  const [busRouteFormSupervisor, setBusRouteFormSupervisor] = useState<string>("");
  const [busRouteFormCapacity, setBusRouteFormCapacity] = useState<number>(25);
  const [busRouteFormStatus, setBusRouteFormStatus] = useState<"active" | "suspended">("active");

  // Effect to keep edit states synchronous with active grade selection
  useEffect(() => {
    if (feesTemplates[selectedGrade]) {
      setEditTuitionFee(feesTemplates[selectedGrade].tuition);
      setEditBusFee(feesTemplates[selectedGrade].bus);
      setEditUniformFee(feesTemplates[selectedGrade].uniform);
      setEditBooksFee(feesTemplates[selectedGrade].books);
    }
  }, [selectedGrade, feesTemplates, isEditingFeesModalOpen]);

  // --- Administration Authorization & Verification States ---
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem("fees_admin_authorized") === "true";
  });
  const [showAdminLoginPanel, setShowAdminLoginPanel] = useState<boolean>(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState<string>("");
  const [adminLoginError, setAdminLoginError] = useState<string>("");

  // Forgot Password Loop
  const [showForgotBox, setShowForgotBox] = useState<boolean>(false);
  const [forgotEmailInput, setForgotEmailInput] = useState<string>("");
  const [forgotError, setForgotError] = useState<string>("");
  const [forgotSuccess, setForgotSuccess] = useState<string>("");

  // Student Inquiry Mode Lookups
  const [studentInquiryId, setStudentInquiryId] = useState<string>("");
  const [inquiredStudent, setInquiredStudent] = useState<StudentFeeRecord | null>(null);
  const [inquiryError, setInquiryError] = useState<string>("");

  // Targeted printing state (Single Student receipt)
  const [selectedReceiptStudent, setSelectedReceiptStudent] = useState<StudentFeeRecord | null>(null);

  // New Student Modal Form States
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newId, setNewId] = useState<string>("");
  const [newName, setNewName] = useState<string>("");
  const [newGrade, setNewGrade] = useState<string>("الصف السادس الابتدائي");
  const [newBusOption, setNewBusOption] = useState<string>("yes"); // "yes" or "no"
  const [newBusRoute, setNewBusRoute] = useState<string>("خط الحافلة A - الميناء والشعب");
  const [customPaidAmount, setCustomPaidAmount] = useState<string>("0");
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [successMsg, setSuccessMsg] = useState<string>("");

  // Default initial students to bind
  const defaultFeeStudents: StudentFeeRecord[] = [
    {
      id: "101",
      name: "عمر أحمد اليوسف",
      grade: "الصف السادس الابتدائي",
      tuitionFee: 7000,
      busFee: 2500,
      uniformFee: 1500,
      booksFee: 1600,
      amountPaid: 8000,
      busRoute: "خط الحافلة A - الميناء والشعب",
      seatNumber: "12"
    },
    {
      id: "102",
      name: "سارة محمد الكردي",
      grade: "الصف الثالث الإعدادي",
      tuitionFee: 9000,
      busFee: 3000,
      uniformFee: 1800,
      booksFee: 1800,
      amountPaid: 10000,
      busRoute: "خط الحافلة B - شارع المطار والغربي",
      seatNumber: "05"
    },
    {
      id: "103",
      name: "يوسف محمد الكردي",
      grade: "الصف الأول الابتدائي",
      tuitionFee: 6000,
      busFee: 2000,
      uniformFee: 1500,
      booksFee: 1500,
      amountPaid: 5000,
      busRoute: "خط الحافلة B - شارع المطار والغربي",
      seatNumber: "06"
    },
    {
      id: "104",
      name: "رائد سامر العلي",
      grade: "الصف الأول الإعدادي",
      tuitionFee: 8500,
      busFee: 0,
      uniformFee: 1800,
      booksFee: 1700,
      amountPaid: 12000,
      busRoute: "بدون نقل - نقل خاص",
      seatNumber: "لا يوجد"
    },
    {
      id: "105",
      name: "هبة مصطفى زقوت",
      grade: "الصف الأول الابتدائي",
      tuitionFee: 6000,
      busFee: 2000,
      uniformFee: 1500,
      booksFee: 1500,
      amountPaid: 11000,
      busRoute: "خط الحافلة A - الميناء والشعب",
      seatNumber: "18"
    }
  ];

  // Load from localStorage or set defaults
  useEffect(() => {
    const saved = localStorage.getItem("school_student_fees");
    if (saved) {
      try {
        setStudents(JSON.parse(saved));
      } catch (e) {
        setStudents(defaultFeeStudents);
      }
    } else {
      setStudents(defaultFeeStudents);
      localStorage.setItem("school_student_fees", JSON.stringify(defaultFeeStudents));
    }
  }, []);

  const saveToStorage = (updatedList: StudentFeeRecord[]) => {
    setStudents(updatedList);
    localStorage.setItem("school_student_fees", JSON.stringify(updatedList));

    // Also update current inquiries in real-time
    if (inquiredStudent) {
      const refreshed = updatedList.find(s => s.id === inquiredStudent.id);
      if (refreshed) {
        setInquiredStudent(refreshed);
      }
    }
  };

  // Get active fees template for the dropdown selected grade
  const currentTemplate = feesTemplates[selectedGrade] || { tuition: 0, bus: 0, uniform: 0, books: 0 };
  const templateTotal = currentTemplate.tuition + currentTemplate.bus + currentTemplate.uniform + currentTemplate.books;

  // Segmented calculations
  const monthlyCost = Math.round(templateTotal / 10);
  const quarterlyCost = Math.round(templateTotal / 3);
  const endYearCost = Math.round(currentTemplate.tuition + currentTemplate.books);

  // Admin login handling
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminLoginError("");
    if (adminPasswordInput === "D@r573$E") {
      setIsAdminLoggedIn(true);
      localStorage.setItem("fees_admin_authorized", "true");
      setShowAdminLoginPanel(false);
      setAdminPasswordInput("");
    } else {
      setAdminLoginError("كلمة المرور غير صحيحة ماليًا! يرجى إعادة المحاولة بدقة.");
    }
  };

  // Admin logout
  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    localStorage.removeItem("fees_admin_authorized");
  };

  const handleSaveFeesTemplateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = {
      ...feesTemplates,
      [selectedGrade]: {
        tuition: Number(editTuitionFee),
        bus: Number(editBusFee),
        uniform: Number(editUniformFee),
        books: Number(editBooksFee)
      }
    };
    saveFeesTemplates(updated);
    setIsEditingFeesModalOpen(false);
  };

  const handleBusRouteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBusRoute) {
      // Edit mode
      const updated = busRoutes.map(b => b.id === editingBusRoute.id ? {
        ...b,
        name: busRouteFormName,
        route: busRouteFormRoute,
        driver: busRouteFormDriver,
        phone: busRouteFormPhone,
        supervisor: busRouteFormSupervisor,
        capacity: Number(busRouteFormCapacity),
        status: busRouteFormStatus
      } : b);
      saveBusRoutes(updated);
    } else {
      // Add mode
      const newRoute: BusRouteItem = {
        id: `bus-${Date.now()}`,
        name: busRouteFormName,
        route: busRouteFormRoute,
        driver: busRouteFormDriver,
        phone: busRouteFormPhone,
        supervisor: busRouteFormSupervisor,
        capacity: Number(busRouteFormCapacity),
        status: busRouteFormStatus
      };
      saveBusRoutes([...busRoutes, newRoute]);
    }
    setIsBusModalOpen(false);
  };

  // Forgot password flow
  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError("");
    setForgotSuccess("");

    if (forgotEmailInput.trim() !== "amlf.yen@gmail.com") {
      setForgotError("البريد الإلكتروني المدخل ليس البريد الرسمي لإدارة المدرسة المستهدفة!");
      return;
    }

    setForgotSuccess("✓ تم فحص البريد الرسمي وتأكيد الهوية للإدارة بنجاح! كلمة المرور المعينة للبوابة هي: D@r573$E");
    
    // Trigger localized email composer draft for administration security
    try {
      window.location.href = `mailto:amlf.yen@gmail.com?subject=طلب استعادة كلمة مرور الرسوم وحجوزات الباص&body=مرحباً، نظام مدرسة أمل ذكي المالي. أرسل هذا البروتوكول لتأكيد هوية الإشراف المالي واستعادة كلمة المرور لـ amlf.yen@gmail.com. كلمة المرور هي: D@r573$E`;
    } catch (err) {
      console.log("Mailto redirect blocked by browser but message is shown.");
    }
  };

  // Student personalized inquiry action (using Academic ID)
  const handleStudentInquirySearch = (e: React.FormEvent) => {
    e.preventDefault();
    setInquiryError("");
    setInquiredStudent(null);

    const queryId = studentInquiryId.trim();
    if (!queryId) {
      setInquiryError("يرجى كتابة رقم الطالب للاستعلام.");
      return;
    }

    const found = students.find(st => st.id === queryId);
    if (found) {
      setInquiredStudent(found);
    } else {
      setInquiryError("🚨 عذرًا، رقم الطالب هذا غير مسجل بالمنظومة أو لم يتم إدراجه مسبقاً بقاعدة الكنترول المالي.");
    }
  };

  // Helper payment deposits
  const handleRecordPayment = (id: string, payAmount: number) => {
    const updated = students.map(st => {
      if (st.id === id) {
        const totalExpected = st.tuitionFee + st.busFee + st.uniformFee + st.booksFee;
        const newPaid = Math.min(st.amountPaid + payAmount, totalExpected);
        return { ...st, amountPaid: newPaid };
      }
      return st;
    });
    saveToStorage(updated);
  };

  // Delete Student
  const handleDeleteStudent = (id: string) => {
    if (confirm("هل أنت متأكد من حذف كشف الطالب المالي بالكامل من النظام المالي والمحافظة؟")) {
      const filtered = students.filter(st => st.id !== id);
      saveToStorage(filtered);
    }
  };

  // Add Student Handler
  const handleAddStudentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!newId.trim() || !newName.trim()) {
      setErrorMsg("يرجى تعبئة كافة الحقول الأساسية المطلوبة.");
      return;
    }

    if (students.some(st => st.id === newId.trim())) {
      setErrorMsg("رقم الطالب أو الكود هذا مستخدم بالفعل لطالب آخر.");
      return;
    }

    const template = feesTemplates[newGrade] || { tuition: 0, bus: 0, uniform: 0, books: 0 };
    const busCost = newBusOption === "yes" ? template.bus : 0;
    const paidVal = parseFloat(customPaidAmount) || 0;
    
    const newRecord: StudentFeeRecord = {
      id: newId.trim(),
      name: newName.trim(),
      grade: newGrade,
      tuitionFee: template.tuition,
      busFee: busCost,
      uniformFee: template.uniform,
      booksFee: template.books,
      amountPaid: paidVal,
      busRoute: newBusOption === "yes" ? newBusRoute : "بدون نقل - نقل خاص",
      seatNumber: newBusOption === "yes" ? `${Math.floor(Math.random() * 25) + 1}` : "لا يوجد"
    };

    const updated = [...students, newRecord];
    saveToStorage(updated);

    // Reset fields
    setNewId("");
    setNewName("");
    setCustomPaidAmount("0");
    setSuccessMsg("تم إضافة الطالب في سجل الرسوم وحجز الباص بنجاح ✓");
    setTimeout(() => {
      setShowAddModal(false);
      setSuccessMsg("");
    }, 1500);
  };

  // Export ledger to standard browser-downloadable UTF-8 CSV
  const handleDownloadCSV = () => {
    try {
      const headers = [
        "كود الطالب", 
        "الاسم الكامل", 
        "الصف الدراسي", 
        "رسوم التعليم (ريال)", 
        "رسوم الباص (ريال)", 
        "الزي والمناهج (ريال)", 
        "إجمالي المطلوب (ريال)", 
        "المبلغ المسدد (ريال)", 
        "المتبقي (ريال)", 
        "خط التوصيل", 
        "رقم مقعد الحافلة"
      ];

      const csvRows = students.map(st => {
        const total = st.tuitionFee + st.busFee + st.uniformFee + st.booksFee;
        const remaining = total - st.amountPaid;
        return [
          st.id,
          st.name,
          st.grade,
          st.tuitionFee,
          st.busFee,
          st.uniformFee + st.booksFee,
          total,
          st.amountPaid,
          remaining,
          st.busRoute,
          st.seatNumber
        ];
      });

      // Construct with UTF-8 BOM so MS Excel reads Arabic letters correctly
      const csvStr = "\uFEFF" + [headers.join(","), ...csvRows.map(row => row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))].join("\n");
      const blob = new Blob([csvStr], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `كشف_الحساب_المالي_مدرسة_أمل_المستقبل_${new Date().toISOString().split("T")[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Csv generation error:", err);
      alert("تعذر تصدير الملف حالياً.");
    }
  };

  // Trigger generalized browser printer dialog
  const handlePrintFullTable = () => {
    window.print();
  };

  // Filter & Search Logic (for Admin view)
  const filteredStudents = students.filter(st => {
    const totalCost = st.tuitionFee + st.busFee + st.uniformFee + st.booksFee;
    const isOver = st.amountPaid >= totalCost;
    
    if (selectedStatusFilter === "paid" && !isOver) return false;
    if (selectedStatusFilter === "unpaid" && isOver) return false;

    const query = searchQuery.toLowerCase();
    return (
      st.id.includes(query) ||
      st.name.toLowerCase().includes(query) ||
      st.grade.toLowerCase().includes(query)
    );
  });

  return (
    <div className="space-y-8 text-right font-sans leading-relaxed animate-fade-in text-slate-900 pb-12 relative">
      
      {/* Injecting CSS specifically for clean print support (RTL Invoice layouts) */}
      <style>{`
        @media print {
          /* Hide anything except the printable card when printing student receipt */
          body * {
            visibility: hidden !important;
          }
          #print-invoice-root, #print-invoice-root * {
            visibility: visible !important;
          }
          #print-invoice-root {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            right: 0 !important;
            width: 100% !important;
            background: white !important;
            color: black !important;
            font-size: 13px !important;
            padding: 30px !important;
            margin: 0 !important;
            direction: rtl !important;
          }
        }
      `}</style>

      {/* ADMIN STATUS INDICATOR BAR */}
      <div className="bg-slate-50 border-y border-slate-205 py-3 px-5 sm:px-8 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full ${isAdminLoggedIn ? "bg-emerald-500 animate-pulse" : "bg-amber-400"}`}></span>
          <p className="text-xs font-bold text-slate-650">
            {isAdminLoggedIn ? (
              <span className="text-emerald-800 flex items-center gap-1">
                <span>مرحباً الإدارة المعتمدة بمدرسة أمل المستقبل (تمت المصادقة المالية للجلسة 🔓)</span>
              </span>
            ) : (
              <span>وضع الطالب وأولياء الأمور المالي (لصلاحية الإشراف والتعديل المالي يرجى تسجيل الدخول)</span>
            )}
          </p>
        </div>

        <div>
          {isAdminLoggedIn ? (
            <button
              onClick={handleAdminLogout}
              className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-extrabold text-[11px] px-3.5 py-1.5 rounded-xl transition duration-150 flex items-center gap-1 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>خروج من وضع الإشراف 🔒</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setShowAdminLoginPanel(true);
                setShowForgotBox(false);
                setAdminLoginError("");
                setAdminPasswordInput("");
              }}
              className="bg-primary hover:bg-[#1e293b] text-white font-black text-[11px] px-3.5 py-1.5 rounded-xl shadow-xs transition duration-150 flex items-center gap-1 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>تسجيل دخول المسؤولين 🔓</span>
            </button>
          )}
        </div>
      </div>

      {/* SECTION 1: Welcome Header */}
      <div className="bg-gradient-to-l from-[#0ea5e9] to-[#0284c7] text-white p-6 sm:p-8 rounded-3xl relative overflow-hidden shadow-xl select-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.15),transparent)] pointer-events-none"></div>
        <div className="relative flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="bg-white/10 text-white text-[10px] font-black px-3 py-1.5 rounded-full select-none tracking-wide">
              بوابة الرصيد المالي وإشراف حافلات الكنترول 🚌💸
            </span>
            <h1 className="text-xl sm:text-2xl md:text-3xl font-black font-display tracking-tight">
              {isAdminLoggedIn ? "لوحة الإدارة والتحكم المالي المباشر" : "بوابة الاستعلام الذكي عن الرسوم وحجوزات الباص"}
            </h1>
            <p className="text-xs text-blue-105 leading-relaxed max-w-2xl font-medium opacity-95">
              {isAdminLoggedIn 
                ? "صلاحيات وحقيبة الإدارة للضوابط وتنزيل كشوف الطلاب وتعديل وخصم وإضافة القيود للطلاب المسجلين بساحة النقل والتعليم لعام 2026." 
                : "تمنح الطلاب إمكانية مراجعة تفاصيل كشف الروم المدرسية وقسط الحافلة المستحق والمسدد بالإضافة إلى موقع مقعد السفر الدراسي في أي وقت."}
            </p>
          </div>

          {isAdminLoggedIn && (
            <div className="flex gap-2.5 shrink-0 w-full md:w-auto">
              <button 
                onClick={() => setShowAddModal(true)}
                className="w-full md:w-auto bg-white hover:bg-slate-50 text-sky-850 font-black px-4.5 py-3 rounded-2xl text-xs transition-all flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4 text-sky-605" />
                <span>إدراج طالب مالي جديد 📂</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ADMIN IS NOT LOGGED IN: STUDENT QUICK INQUIRY ENTRANCE VIEW */}
      {!isAdminLoggedIn ? (
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Right Side lookup (8 cols) */}
          <div className="lg:col-span-8 bg-white p-6 sm:p-8 rounded-3xl border border-slate-150/80 shadow-md space-y-6">
            <div className="space-y-2 border-b pb-4">
              <h3 className="text-base font-black text-slate-800 flex items-center gap-1.5">
                <span className="p-1 px-1.5 bg-sky-50 text-sky-600 rounded-lg">🔍</span>
                <span>الاستعلام السريع برقم الطالب الخاص بك</span>
              </h3>
              <p className="text-xs text-slate-500 font-bold leading-relaxed">
                لكي تطلع على الرسوم الدراسية وحالة خدمة حافلات الباص ومبلغ المستحقات والخصومات الخاصة بك، يرجى كتابة الرمز الرقمي للطالب في النظام هنا (مثال: <span className="text-primary font-mono tracking-wider font-extrabold underline">101</span> أو <span className="text-primary font-mono tracking-wider font-extrabold underline">102</span> أو <span className="text-primary font-mono tracking-wider font-extrabold underline">103</span>):
              </p>
            </div>

            <form onSubmit={handleStudentInquirySearch} className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  placeholder="أدخل كود الطالب المكون من أرقام فقط (مثال: 101)..."
                  value={studentInquiryId}
                  onChange={(e) => setStudentInquiryId(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-3 pr-4 pl-10 rounded-2xl font-extrabold text-center text-slate-800 tracking-wider outline-none"
                />
              </div>
              <button
                type="submit"
                className="bg-sky-600 hover:bg-sky-700 text-white font-black px-6 py-3 rounded-2xl text-xs transition duration-150 shadow-md cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>بحث واستعلام 🔍</span>
              </button>
            </form>

            {inquiryError && (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 font-black text-xs leading-relaxed">
                ⚠️ {inquiryError}
              </div>
            )}

            {/* INQUIRY STUDENT RESULTS CARD */}
            {inquiredStudent ? (
              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-6 animate-slide-down">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <span className="text-[10px] bg-sky-100 text-sky-800 font-black px-2 py-1 rounded-md">طالب معتمد ✓</span>
                    <h4 className="text-base font-black text-slate-900 mt-1">{inquiredStudent.name}</h4>
                    <p className="text-[11px] text-slate-400 font-bold">الرقم الأكاديمي: <span className="font-mono text-slate-650 font-black">{inquiredStudent.id}</span> | {inquiredStudent.grade}</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedReceiptStudent(inquiredStudent)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 transition cursor-pointer select-none"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>طباعة تفصيل الرسوم المدرسية 🖨️</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  
                  {/* Tuition */}
                  <div className="p-3.5 bg-white border border-slate-200 rounded-xl">
                    <p className="text-[10px] text-slate-400 font-black">أقساط ورسوم التعليم</p>
                    <p className="text-sm font-mono font-black text-slate-800 pt-1">{inquiredStudent.tuitionFee.toLocaleString()} ريال</p>
                    <span className="text-[9px] text-slate-400 font-medium">سداد الفصل الدراسي المعتمد</span>
                  </div>

                  {/* Bus */}
                  <div className="p-3.5 bg-white border border-slate-200 rounded-xl">
                    <p className="text-[10px] text-slate-400 font-black">خدمة النقل والباص</p>
                    <p className="text-sm font-mono font-black text-sky-700 pt-1">
                      {inquiredStudent.busFee > 0 ? `${inquiredStudent.busFee.toLocaleString()} ريال` : "غير مشترك"}
                    </p>
                    <span className="text-[9px] text-slate-400 font-medium">الاشتراك السنوي لساحة النقل</span>
                  </div>

                  {/* Uniform & Books */}
                  <div className="p-3.5 bg-white border border-slate-200 rounded-xl col-span-2 md:col-span-1">
                    <p className="text-[10px] text-slate-400 font-black">الزي والمناهج المعتمدة</p>
                    <p className="text-sm font-mono font-black text-slate-800 pt-1">{(inquiredStudent.uniformFee + inquiredStudent.booksFee).toLocaleString()} ريال</p>
                    <span className="text-[9px] text-slate-400 font-medium font-sans">ثمن الكراسات والزي الرسمي</span>
                  </div>

                </div>

                {/* Total Invoice Details */}
                {(() => {
                  const expectedTotal = inquiredStudent.tuitionFee + inquiredStudent.busFee + inquiredStudent.uniformFee + inquiredStudent.booksFee;
                  const remaining = expectedTotal - inquiredStudent.amountPaid;
                  const isSafePaid = remaining <= 0;

                  return (
                    <div className="space-y-4">
                      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div className="space-y-1">
                          <p className="text-xs font-black text-slate-700">السيولة الإجمالية والذمة المالية للحساب:</p>
                          <div className="flex flex-wrap items-center gap-3 text-[11px] font-bold text-slate-450">
                            <p>المطلوب كليا: <span className="font-mono text-slate-800 font-black">{expectedTotal.toLocaleString()} ريال</span></p>
                            <p className="text-slate-300">|</p>
                            <p>كم سددت: <span className="font-mono text-emerald-700 font-black">{inquiredStudent.amountPaid.toLocaleString()} ريال</span></p>
                          </div>
                        </div>

                        <div className="text-center sm:text-left">
                          <span className="text-[10px] text-slate-400 font-bold block pb-1">المتبقي المطلوب سداده:</span>
                          {isSafePaid ? (
                            <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 font-black px-3.5 py-1.5 rounded-xl text-xs block">
                              تم تصفية وبراءة الذمة المالية ✓
                            </span>
                          ) : (
                            <span className="bg-rose-50 text-rose-700 border border-rose-100 font-mono font-black px-4 py-1.5 rounded-xl text-sm block">
                              {remaining.toLocaleString()} ريال يمني
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Bus route and seating details */}
                      {inquiredStudent.busFee > 0 ? (
                        <div className="bg-sky-50/50 border border-sky-100 rounded-xl p-4 flex items-start gap-3 text-xs text-sky-900">
                          <span className="p-1 px-1.5 bg-white text-sky-600 rounded-lg shrink-0 mt-0.5 shadow-3xs">🚌</span>
                          <div className="space-y-1">
                            <p className="font-extrabold">تفاصيل مسارك ومقعد حافلتك المدرسية:</p>
                            <p className="text-slate-450 font-bold">الحافلة المحددة: <span className="text-sky-800">{inquiredStudent.busRoute}</span></p>
                            <p className="text-slate-450 font-bold">رقم مقعدك الدراسي المحجوز: <span className="text-sky-850 font-mono text-xs font-black bg-white rounded border border-sky-100/50 px-1.5 py-0.2">{inquiredStudent.seatNumber}</span></p>
                            <p className="text-[10px] text-sky-600 font-bold leading-relaxed pt-1">
                              * يرجى التواجد في المنطقة السكنية المحددة في تمام الساعة 7:10 صباحاً لضمان عدم تأخر الحافلة المدرسية.
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-slate-100 border border-slate-200 rounded-xl p-4 flex items-start gap-2 text-[11px] text-slate-500">
                          <span className="shrink-0">📍</span>
                          <p className="font-medium leading-relaxed">
                            <strong>تفاصيل النقل:</strong> لا توجد حجوزات حافلة مسجلة لهذا الطالب بساحة النقل المدرسية. نمط النقل المعين هو نقل خاص / مستقل من جهة ذويكم.
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })()}

              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 font-bold border-2 border-dashed border-slate-200 rounded-2xl">
                <p className="text-xs">لم يتم اختيار أو استفسار أي كود طالب حتى الآن.</p>
                <p className="text-[10px] text-slate-400 font-medium pt-1">اكتب الكود الخاص بك بالجدول الأعلى وانقر استعلام لمعرفة التفاصيل.</p>
              </div>
            )}

          </div>

          {/* Left Side: School administration login form (4 cols) */}
          <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-slate-150/80 shadow-md space-y-4">
            
            <div className="flex items-center gap-2 border-b pb-3 text-slate-800">
              <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
                <Lock className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-black">لوحة التحكم وخزينة الإشراف (الموظفين)</h3>
            </div>

            <p className="text-[11px] text-slate-400 font-bold leading-relaxed">
              إذا كنت محاسباً أو رئيساً لقسم شؤون الطلاب، تفضل بتسجيل الدخول لتعديل الكشوفات، وتصدير البيانات، وإضافة خصومات للطلاب:
            </p>

            {/* LOGIN INPUT BOX */}
            <form onSubmit={handleAdminLogin} className="space-y-3 pt-2">
              {adminLoginError && (
                <div className="p-2.5 bg-rose-50 border border-rose-100 text-rose-750 font-black rounded-lg text-[10px] leading-relaxed">
                  ⚠️ {adminLoginError}
                </div>
              )}

              <div className="space-y-1">
                <label className="block text-[10px] font-black text-slate-550">توقيع كلمة المرور المعتمدة للتحكم:</label>
                <input
                  type="password"
                  placeholder="أدخل كلمة المرور..."
                  value={adminPasswordInput}
                  onChange={(e) => setAdminPasswordInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2 px-3 rounded-xl font-mono text-center tracking-widest text-slate-850"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#1e293b] hover:bg-slate-900 text-white font-black py-2 rounded-xl text-xs transition duration-150 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>دخول للوحة التحكم المباشر 🔓</span>
              </button>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotBox(true);
                    setForgotSuccess("");
                    setForgotError("");
                    setForgotEmailInput("");
                  }}
                  className="text-[10px] text-sky-600 hover:text-sky-700 font-extrabold hover:underline transition cursor-pointer"
                >
                  نسيت كلمة المرور؟ 🔑
                </button>
              </div>
            </form>

            {/* FORGOT PASSWORD MODAL COMPONENT */}
            {showForgotBox && (
              <div className="p-4 bg-sky-50 border border-sky-100 rounded-2xl text-right text-xs space-y-3 animate-slide-down">
                <p className="font-extrabold text-sky-850 flex items-center gap-1">
                  <span>🔑 بروتوكول استرداد كلمة المرور</span>
                </p>
                <p className="text-[10px] text-slate-600 leading-relaxed font-bold">
                  يجب إدخال البريد الإلكتروني المحمي الرسمي المعتمد لإدارة المدرسة وهو: <span className="font-mono text-primary font-black block select-all bg-white p-1 rounded border border-sky-100 mt-1">amlf.yen@gmail.com</span>
                </p>

                <form onSubmit={handleForgotSubmit} className="space-y-2.5">
                  <div className="space-y-1">
                    <label className="block text-[9.5px] font-bold text-slate-500">البريد الإلكتروني الرسمي للإدارة:</label>
                    <input
                      type="email"
                      required
                      placeholder="اكتب amlf.yen@gmail.com لتأكيد الهوية..."
                      value={forgotEmailInput}
                      onChange={(e) => setForgotEmailInput(e.target.value)}
                      className="w-full bg-white border border-slate-205 focus:border-sky-400 text-xs py-1.5 px-2.5 rounded-lg pr-2 text-slate-700"
                    />
                  </div>

                  {forgotError && (
                    <p className="text-[10px] text-rose-600 font-black">⚠️ {forgotError}</p>
                  )}

                  {forgotSuccess && (
                    <div className="p-2.5 bg-emerald-100/60 border border-emerald-200 text-emerald-800 font-black text-[10px] rounded-lg leading-relaxed select-all">
                      {forgotSuccess}
                    </div>
                  )}

                  <div className="flex items-center gap-2 justify-end pt-1">
                    <button
                      type="button"
                      onClick={() => setShowForgotBox(false)}
                      className="bg-slate-200 hover:bg-slate-300 text-slate-605 font-bold px-2.5 py-1.5 rounded-lg text-[10px]"
                    >
                      إلغاء
                    </button>
                    <button
                      type="submit"
                      className="bg-sky-600 hover:bg-sky-700 text-white font-black px-3.5 py-1.5 rounded-lg text-[10px]"
                    >
                      تحقق واسترداد ✉️
                    </button>
                  </div>
                </form>
              </div>
            )}

          </div>

          {/* Developer Rights & Contact Button for Student View */}
          <div className="lg:col-span-12 bg-white p-4 rounded-2xl border border-slate-150 flex flex-col sm:flex-row items-center justify-between gap-3 text-right">
            <span className="text-[10px] text-slate-500 font-bold">
              جميع الحقوق محفوظة ومحمية © مدرسة أمل المستقبل الأهلية | نظام الكنترول والرسوم 2026-2027
            </span>
            
            <a
              href="https://wa.me/967774632249"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white text-slate-800 hover:bg-slate-50 hover:border-slate-350 font-black text-xs rounded-xl border border-slate-200 transition-all duration-200 cursor-pointer shadow-3xs select-none"
              title="تواصل مع مصمم ومطور النظام عبر واتساب"
            >
              <img
                src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgRo4g4_W6PymhtlOvN5CxBqz6yChzUFfKcwx8ahexjk7Kyo6_1FZ3yKilegJEPLEmZO788AGdgcKCrQ5AkLbvMIRP72TT6BLMpjx731qmJAvEqPitsmRJdd1pmcFOkPLucbK6oO_vpKCXaHcb7pLh3l7zDeNh4MrnkvSDxofb5Rz5lT2E6Q42pFfHBtg/s320/1746267577250.jpg"
                alt="ALRASSASS Logo"
                className="w-5 h-5 rounded-full object-cover border border-slate-100"
                referrerPolicy="no-referrer"
              />
              <span>تصميم ALRASSASS</span>
            </a>
          </div>

        </div>
      ) : (
        /* ADMIN IS LOGGED IN: DISPLAY ALL COMPREHENSIVE TOOLS AND DATA LISTINGS */
        <div className="space-y-8">
          
          {/* SECTION 2: General Settings and Grade fees structure (Admin views) */}
          <div className="grid lg:grid-cols-12 gap-6 items-start">
            
            {/* RIGHT SIDE (8 Cols): Grade selection tariffs */}
            <div className="lg:col-span-8 bg-white p-6 sm:p-8 rounded-3xl border border-slate-150/85 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-sky-50 text-sky-700 rounded-xl">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-sm font-black text-slate-800">تفاصيل هيكل الرسوم المقررة (التعرفة العامة):</h2>
                    <p className="text-[10px] text-slate-400 font-bold">تحديد بنود سداد المرحلة المحددة لغرسها في معايير وتحديثات الطلاب:</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isAdminLoggedIn && (
                    <button
                      onClick={() => {
                        const current = feesTemplates[selectedGrade];
                        if (current) {
                          setEditTuitionFee(current.tuition);
                          setEditBusFee(current.bus);
                          setEditUniformFee(current.uniform);
                          setEditBooksFee(current.books);
                        }
                        setIsEditingFeesModalOpen(true);
                      }}
                      className="bg-sky-600 hover:bg-sky-700 text-white font-extrabold px-3 py-2.5 rounded-xl text-[11px] flex items-center gap-1 transition-all duration-150 shadow-sm"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>تعديل الرسوم المقررة ⚡</span>
                    </button>
                  )}
                  <div className="relative">
                    <select
                      value={selectedGrade}
                      onChange={(e) => setSelectedGrade(e.target.value)}
                      className="bg-slate-55 border border-slate-205 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2.5 pl-8 pr-4 rounded-xl font-bold text-slate-720 cursor-pointer outline-none min-w-[200px]"
                    >
                      {Object.keys(GRADE_FEES_TEMPLATES).map((gr) => (
                        <option key={gr} value={gr}>{gr}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Grid block display */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-blue-50/50 border border-blue-100 rounded-2xl hover:scale-102 transition duration-200">
                  <span className="text-[11px] font-bold text-blue-700 block border-b pb-1">رسوم التعليم</span>
                  <p className="text-[17px] font-mono font-black text-slate-800 pt-2">{currentTemplate.tuition.toLocaleString()} <span className="text-[10px] font-sans font-extrabold text-[#94a3b8]">ريال</span></p>
                  <p className="text-[9px] text-[#94a3b8] font-medium mt-0.5">القسط الأكاديمي السنوي</p>
                </div>

                <div className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-2xl hover:scale-102 transition duration-200">
                  <span className="text-[11px] font-bold text-emerald-800 block border-b pb-1">حافلات ونقل</span>
                  <p className="text-[17px] font-mono font-black text-slate-800 pt-2">{currentTemplate.bus.toLocaleString()} <span className="text-[10px] font-sans font-extrabold text-[#94a3b8]">ريال</span></p>
                  <p className="text-[9px] text-[#94a3b8] font-medium mt-0.5">رسوم الباص السكنية</p>
                </div>

                <div className="p-4 bg-amber-50/50 border border-amber-100 rounded-2xl hover:scale-102 transition duration-200">
                  <span className="text-[11px] font-bold text-amber-700 block border-b pb-1">الزي المدرسي</span>
                  <p className="text-[17px] font-mono font-black text-slate-800 pt-2">{currentTemplate.uniform.toLocaleString()} <span className="text-[10px] font-sans font-extrabold text-[#94a3b8]">ريال</span></p>
                  <p className="text-[9px] text-[#94a3b8] font-medium mt-0.5">الزي الرسمي والملحقات</p>
                </div>

                <div className="p-4 bg-purple-50/50 border border-purple-100 rounded-2xl hover:scale-102 transition duration-200">
                  <span className="text-[11px] font-bold text-purple-700 block border-b pb-1">المنهج والكتب</span>
                  <p className="text-[17px] font-mono font-black text-slate-800 pt-2">{currentTemplate.books.toLocaleString()} <span className="text-[10px] font-sans font-extrabold text-[#94a3b8]">ريال</span></p>
                  <p className="text-[9px] text-[#94a3b8] font-medium mt-0.5">حقيبة الكتب الكرتونية</p>
                </div>
              </div>

              {/* Total Summary */}
              <div className="bg-slate-50 border border-slate-100 p-4.5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-xs font-black text-slate-800">إجمالي الرسوم الافتراضية المحددة للصف الحالي:</p>
                  <p className="text-[9.5px] text-slate-400 font-bold mt-0.5">يتم تطبيق هذه القواعد آلياً عند تسجيل الطلاب الجدد بنظام الكنترول المعتمد.</p>
                </div>
                <div>
                  <span className="bg-sky-600 font-mono font-black text-sm text-white py-2 px-5 rounded-xl block shadow-sm border border-sky-600">
                    {templateTotal.toLocaleString()} ريال يمني
                  </span>
                </div>
              </div>

            </div>

            {/* LEFT SIDE (4 Cols): payment cycles statistics */}
            <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-slate-150/80 shadow-xs space-y-4">
              <div className="flex items-center gap-2 border-b pb-3">
                <div className="p-1.5 bg-amber-50 text-amber-650 rounded-lg">
                  <Sliders className="w-4 h-4" />
                </div>
                <h3 className="text-xs font-black text-slate-800">الضوابط وأقسام سداد الحسابات:</h3>
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-100 flex items-center gap-3">
                  <div className="w-2.5 h-11 bg-pink-500 rounded-full" />
                  <div className="flex-1 min-w-0">
                    <p className="font-extrabold text-slate-900 text-xs">قسط السداد الشهري</p>
                    <p className="text-[10px] text-slate-400">مقسم على 10 دفعات دورية</p>
                  </div>
                  <span className="text-xs font-black text-pink-700 font-mono shrink-0">{monthlyCost.toLocaleString()} ريال</span>
                </div>

                <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-100 flex items-center gap-3">
                  <div className="w-2.5 h-11 bg-indigo-500 rounded-full" />
                  <div className="flex-1 min-w-0">
                    <p className="font-extrabold text-slate-900 text-xs">القسط الربع سنوي</p>
                    <p className="text-[10px] text-slate-400">تقسيم مالي على 3 مراحل</p>
                  </div>
                  <span className="text-xs font-black text-indigo-700 font-mono shrink-0">{quarterlyCost.toLocaleString()} ريال</span>
                </div>

                <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-100 flex items-center gap-3">
                  <div className="w-2.5 h-11 bg-teal-500 rounded-full" />
                  <div className="flex-1 min-w-0">
                    <p className="font-extrabold text-slate-900 text-xs">تسوية قيد كشف النتائج</p>
                    <p className="text-[10px] text-slate-400">الحد الأدنى لتسليم الشهادة</p>
                  </div>
                  <span className="text-xs font-black text-teal-700 font-mono shrink-0">{endYearCost.toLocaleString()} ريال</span>
                </div>
              </div>
            </div>

          </div>

          {/* SECTION 3: Main dynamic interactive table with inline controls */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-150/85 shadow-md space-y-6">
            
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b pb-5">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="p-1 px-1.5 bg-emerald-105 text-emerald-802 rounded-md font-bold text-xs">إشراف</span>
                  <h3 className="text-sm font-black text-slate-800">بيانات كشف الحساب المالي للطلاب المسجلين</h3>
                </div>
                <p className="text-[10px] text-slate-400 font-bold">يمكنك إضافة أو خصم أو تعديل الحساب بمجرد النقر وتغيير القيم في الصناديق مباشرة! يتم الحفظ والاحتساب تلقائياً.</p>
              </div>

              {/* ACTION BUTTONS FOR ADMIN: PRINT AND EXPORT */}
              <div className="flex flex-wrap items-center gap-2.5 text-right">
                
                {/* Download CSV */}
                <button
                  onClick={handleDownloadCSV}
                  className="bg-sky-50 hover:bg-sky-100 text-sky-700 font-extrabold text-[11px] px-3 py-2 rounded-xl border border-sky-100 transition duration-150 flex items-center gap-1 cursor-pointer select-none"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تنزيل الكشف الكامل (CSV) 📥</span>
                </button>

                {/* Print whole table */}
                <button
                  onClick={handlePrintFullTable}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-[11px] px-3 py-2 rounded-xl border border-slate-200 transition duration-150 flex items-center gap-1 cursor-pointer select-none"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>طباعة الكشوفات المالية 🖨️</span>
                </button>

                {/* Reset defaults */}
                <button
                  onClick={() => {
                    if (confirm("هل أنت متأكد من رغبتك في إعادة تعيين كشوف الطلاب المالية للحالة التجريبية الأولية؟ (سيؤدي ذلك لمسح التعديلات الجارية)")) {
                      saveToStorage(defaultFeeStudents);
                    }
                  }}
                  className="p-2 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-400 border border-slate-200 transition rounded-xl cursor-pointer"
                  title="إعادة ضبط وتصفير الكشف المالي"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* FILTERS TOOLBAR */}
            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-150 space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
                {/* Filter tabs */}
                <div className="flex items-center bg-white p-1 rounded-xl border border-slate-200 w-full sm:w-auto">
                  <button
                    onClick={() => setSelectedStatusFilter("all")}
                    className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-[10.5px] font-extrabold transition cursor-pointer ${
                      selectedStatusFilter === "all" ? "bg-slate-900 text-white shadow-xs" : "text-slate-550 hover:text-slate-850"
                    }`}
                  >
                    الكل ({students.length})
                  </button>
                  <button
                    onClick={() => setSelectedStatusFilter("paid")}
                    className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-[10.5px] font-extrabold transition cursor-pointer ${
                      selectedStatusFilter === "paid" ? "bg-emerald-600 text-white" : "text-slate-550 hover:text-slate-850"
                    }`}
                  >
                    مسدد بالكامل ({students.filter(s => s.amountPaid >= (s.tuitionFee + s.busFee + s.uniformFee + s.booksFee)).length})
                  </button>
                  <button
                    onClick={() => setSelectedStatusFilter("unpaid")}
                    className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-[10.5px] font-extrabold transition cursor-pointer ${
                      selectedStatusFilter === "unpaid" ? "bg-rose-600 text-white" : "text-slate-550 hover:text-slate-850"
                    }`}
                  >
                    متبقي ذمم ({students.filter(s => s.amountPaid < (s.tuitionFee + s.busFee + s.uniformFee + s.booksFee)).length})
                  </button>
                </div>

                {/* Live search input */}
                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="ابحث برقم الطالب، الاسم الكامل، أو الصف..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-white border border-slate-205 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2 pr-4 pl-9 rounded-xl font-bold text-slate-720 outline-none"
                  />
                </div>
              </div>

              {/* Developer Rights & Contact Button */}
              <div className="pt-3 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-right">
                <span className="text-[10px] text-slate-500 font-bold">
                  جميع الحقوق محفوظة ومضمونة ماليًا © مدرسة أمل المستقبل الأهلية
                </span>
                
                <a
                  href="https://wa.me/967774632249"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white text-slate-800 hover:bg-slate-50 hover:border-slate-350 font-black text-xs rounded-xl border border-slate-200 transition-all duration-200 cursor-pointer shadow-3xs select-none"
                  title="تواصل مع مصمم ومطور النظام عبر واتساب"
                >
                  <img
                    src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgRo4g4_W6PymhtlOvN5CxBqz6yChzUFfKcwx8ahexjk7Kyo6_1FZ3yKilegJEPLEmZO788AGdgcKCrQ5AkLbvMIRP72TT6BLMpjx731qmJAvEqPitsmRJdd1pmcFOkPLucbK6oO_vpKCXaHcb7pLh3l7zDeNh4MrnkvSDxofb5Rz5lT2E6Q42pFfHBtg/s320/1746267577250.jpg"
                    alt="ALRASSASS Logo"
                    className="w-5 h-5 rounded-full object-cover border border-slate-100"
                    referrerPolicy="no-referrer"
                  />
                  <span>تصميم ALRASSASS</span>
                </a>
              </div>
            </div>

            {/* MAIN DATA LEDGER EXCEL-LIKE SPREADSHEET TABLE COMPONENT */}
            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full text-right text-xs table-auto border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-black border-b border-slate-200 select-none">
                    <th className="p-3 pr-4">كود الطالب</th>
                    <th className="p-3">اسم الطالب الكامل</th>
                    <th className="p-3">الصف والمرحلة</th>
                    <th className="p-3 text-center min-w-[100px]">رسوم تعليم 💰</th>
                    <th className="p-3 text-center min-w-[90px]">رسوم باص 🚌</th>
                    <th className="p-3 text-center min-w-[90px]">زي ومناهج 🏷️</th>
                    <th className="p-3 text-center font-bold text-slate-800">إجمالي مطلوب</th>
                    <th className="p-3 text-center min-w-[110px] bg-emerald-50/20 text-emerald-800">مسدد الطالب 💸</th>
                    <th className="p-3 text-center font-black">المتبقي المطلوب</th>
                    <th className="p-3 text-center">تفاصيل المقعد والخط</th>
                    <th className="p-3 text-center">الإجراءات والخصم</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredStudents.length > 0 ? (
                    filteredStudents.map((st) => {
                      const expectedTotal = st.tuitionFee + st.busFee + st.uniformFee + st.booksFee;
                      const remaining = expectedTotal - st.amountPaid;
                      const isFullyPaid = remaining <= 0;

                      return (
                        <tr key={st.id} className="border-b border-slate-100 hover:bg-slate-50/70 transition-colors">
                          
                          {/* Student Academic ID */}
                          <td className="p-3 pr-4 font-mono font-black text-slate-900">{st.id}</td>

                          {/* Full Name */}
                          <td className="p-3 font-extrabold text-[#111827]">
                            <p>{st.name}</p>
                            <p className="text-[9.5px] text-slate-400 font-bold">{st.grade}</p>
                          </td>

                          {/* Class */}
                          <td className="p-3 text-slate-500 font-extrabold">{st.grade}</td>

                          {/* INLINE EDITABLE: TUITION FEE */}
                          <td className="p-1.5 text-center">
                            <input
                              type="number"
                              min="0"
                              value={st.tuitionFee}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value) || 0;
                                const updated = students.map(s => s.id === st.id ? { ...s, tuitionFee: val } : s);
                                saveToStorage(updated);
                              }}
                              className="w-20 font-mono font-black text-xs text-center border border-slate-200 rounded-lg py-1 bg-white hover:border-sky-400 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/10"
                            />
                          </td>

                          {/* INLINE EDITABLE: BUS FEE */}
                          <td className="p-1.5 text-center">
                            <input
                              type="number"
                              min="0"
                              value={st.busFee}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value) || 0;
                                const updated = students.map(s => s.id === st.id ? { ...s, busFee: val } : s);
                                saveToStorage(updated);
                              }}
                              className="w-18 font-mono font-black text-xs text-center border-sky-100/80 border text-sky-850 rounded-lg py-1 bg-white hover:border-sky-400 focus:border-sky-500 focus:ring-1"
                            />
                          </td>

                          {/* INLINE EDITABLE: UNIFORM + BOOKS (COMBINED OR EDITING UNIFORM AS MOCK SEPARATOR) */}
                          <td className="p-1.5 text-center">
                            <input
                              type="number"
                              min="0"
                              value={st.uniformFee}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value) || 0;
                                const updated = students.map(s => s.id === st.id ? { ...s, uniformFee: val } : s);
                                saveToStorage(updated);
                              }}
                              className="w-16 font-mono font-bold text-xs text-center border border-slate-200 rounded-lg py-1 bg-white hover:border-sky-400"
                              title="تعديل قيمة الزي والمطالبة فقط"
                            />
                          </td>

                          {/* expected total calculation automatically recalculated */}
                          <td className="p-3 text-center font-mono font-black text-slate-900">
                            {expectedTotal.toLocaleString()} ريال
                          </td>

                          {/* INLINE EDITABLE: AMOUNT PAID */}
                          <td className="p-1.5 text-center bg-emerald-50/10">
                            <div className="flex items-center justify-center gap-1">
                              <input
                                type="number"
                                min="0"
                                max={expectedTotal}
                                value={st.amountPaid}
                                onChange={(e) => {
                                  const val = parseFloat(e.target.value) || 0;
                                  const updated = students.map(s => s.id === st.id ? { ...s, amountPaid: val } : s);
                                  saveToStorage(updated);
                                }}
                                className="w-20 font-mono font-black text-xs text-center text-emerald-800 border-emerald-250 border bg-white rounded-lg py-1 hover:border-emerald-400 focus:ring-1 focus:ring-emerald-500"
                              />
                            </div>
                          </td>

                          {/* Live remaining balance */}
                          <td className="p-3 text-center">
                            {isFullyPaid ? (
                              <span className="bg-emerald-50 text-emerald-700 font-extrabold text-[10px] px-2 py-0.5 rounded border border-emerald-150">
                                ✓ مسدد بالكامل
                              </span>
                            ) : (
                              <span className="font-mono font-black text-rose-650 bg-rose-50/60 px-2 py-0.5 rounded">
                                {remaining.toLocaleString()} ريال
                              </span>
                            )}
                          </td>

                          {/* Seating and lines */}
                          <td className="p-3 text-[10px] text-slate-550 text-center">
                            {st.busFee > 0 ? (
                              <div className="space-y-0.2">
                                <p className="font-black text-sky-850">🚌 {st.busRoute}</p>
                                <p className="text-slate-400">مقعد: <span className="font-mono font-bold">{st.seatNumber}</span></p>
                              </div>
                            ) : (
                              <span className="text-slate-350 italic">خاص / لا يوجد نقل</span>
                            )}
                          </td>

                          {/* ACTIONS */}
                          <td className="p-1.5 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {/* Print Receipt Button */}
                              <button
                                onClick={() => setSelectedReceiptStudent(st)}
                                title="طباعة وإصدار إيصال الطالب الفردي"
                                className="p-1.5 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-lg border border-slate-200 transition cursor-pointer"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>

                              {/* Adjust / Discount Special Note */}
                              <button
                                onClick={() => {
                                  const discountAmount = prompt(`أدخل قيمة الخصم المالي المقترح تقديمه للطالب: ${st.name} (بالريال):`, "500");
                                  if (discountAmount !== null) {
                                    const discNum = parseFloat(discountAmount) || 0;
                                    if (discNum > 0) {
                                      // Grant discount by reducing tuition fee or offsetting
                                      const newTuition = Math.max(0, st.tuitionFee - discNum);
                                      const updated = students.map(s => s.id === st.id ? { ...s, tuitionFee: newTuition } : s);
                                      saveToStorage(updated);
                                      alert(`✓ تم تطبيق خصم بقيمة ${discNum.toLocaleString()} ريال على الرسوم التعليمية للطالب بنجاح!`);
                                    }
                                  }
                                }}
                                title="تقديم خصم وتعديل الحساب مالي كهدية أو تخفيض"
                                className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg border border-amber-200 transition cursor-pointer"
                              >
                                💸 <span className="text-[8px] font-black">خصم</span>
                              </button>

                              {/* Delete */}
                              <button
                                onClick={() => handleDeleteStudent(st.id)}
                                title="حذف بالكامل من المنظومة"
                                className="p-1.5 hover:bg-rose-50 text-rose-500 hover:text-rose-700 transition rounded-lg cursor-pointer border border-transparent hover:border-rose-100"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>

                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={11} className="p-8 text-center text-slate-400 font-bold bg-slate-50">
                        <AlertTriangle className="w-8 h-8 mx-auto text-amber-500 mb-2" />
                        <span>لا توجد سجلات مطابقة للبحث ماليًا! يمكنك الضغط على "إضافة جديد" لتكبير الكشف.</span>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Admin Live Cumulative Statistics widget */}
            <div className="bg-gradient-to-l from-slate-50 to-white border border-slate-150 p-6 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="text-right space-y-1">
                <h4 className="text-xs font-black text-slate-800">📊 إجمالي السيولة والمعطيات لحسابات مدرسة أمل (محدثة لحظياً):</h4>
                <p className="text-[10px] text-slate-400 font-bold">يتم تفعيل كافة العمليات وتأكيدها آلياً بكافة المنصات المدرسية.</p>
              </div>
              <div className="flex flex-wrap items-center gap-6">
                <div className="text-center sm:text-left min-w-[124px] p-3 bg-white border border-slate-100 rounded-xl">
                  <span className="text-[9.5px] text-slate-400 font-black block">المطلوب الكامل</span>
                  <span className="text-sm font-mono font-black text-slate-850">
                    {students.reduce((acc, st) => acc + (st.tuitionFee + st.busFee + st.uniformFee + st.booksFee), 0).toLocaleString()} ريال
                  </span>
                </div>
                <div className="text-center sm:text-left min-w-[124px] p-3 bg-emerald-50 border border-emerald-100 rounded-xl">
                  <span className="text-[9.5px] text-emerald-700 font-black block">المحصل فعلياً</span>
                  <span className="text-sm font-mono font-black text-emerald-800">
                    {students.reduce((acc, st) => acc + st.amountPaid, 0).toLocaleString()} ريال
                  </span>
                </div>
                <div className="text-center sm:text-left min-w-[124px] p-3 bg-rose-50 border border-rose-105 rounded-xl">
                  <span className="text-[9.5px] text-rose-705 font-black block">متبقي الحصيلة الدائنة</span>
                  <span className="text-sm font-mono font-black text-rose-700">
                    {students.reduce((acc, st) => acc + ((st.tuitionFee + st.busFee + st.uniformFee + st.booksFee) - st.amountPaid), 0).toLocaleString()} ريال
                  </span>
                </div>
              </div>
            </div>

          </div>

          {/* SECTION 4: Transportation Bus Schedule Information Grid */}
          <div className="bg-slate-900 text-white p-6 sm:p-8 rounded-3xl shadow-xl overflow-hidden relative select-none">
            <div className="absolute top-0 right-0 w-64 h-64 bg-slate-800 rounded-full mix-blend-multiply filter blur-2xl opacity-50 pointer-events-none" />
            <div className="relative space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-yellow-400 text-slate-900 rounded-xl">
                    <Bus className="w-5 h-5 shrink-0" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white py-0.5">حجوزات وتسيير الحافلات المدرسية النشطة</h3>
                    <p className="text-[10px] text-slate-300 font-bold">متابعة مسارات الحافلات وأرقام تواصل السائقين للمربعات السكنية المعتمدة لعام 2026 م</p>
                  </div>
                </div>

                {isAdminLoggedIn && (
                  <button
                    onClick={() => {
                      setEditingBusRoute(null);
                      setBusRouteFormName("");
                      setBusRouteFormRoute("");
                      setBusRouteFormDriver("");
                      setBusRouteFormPhone("");
                      setBusRouteFormSupervisor("");
                      setBusRouteFormCapacity(25);
                      setBusRouteFormStatus("active");
                      setIsBusModalOpen(true);
                    }}
                    className="bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-extrabold px-3.5 py-2 rounded-xl text-[11px] flex items-center gap-1.5 transition shadow"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة خط حافلة جديد +</span>
                  </button>
                )}
              </div>

              <div className="grid md:grid-cols-3 gap-5 text-slate-850">
                {busRoutes.map((bus) => {
                  const occupiedSeats = students.filter(s => 
                    s.busRoute && (
                      s.busRoute.includes(bus.name) || 
                      s.busRoute.includes(bus.route) ||
                      (bus.id === "bus-a" && s.busRoute.includes("الميناء")) ||
                      (bus.id === "bus-b" && s.busRoute.includes("المطار"))
                    )
                  ).length;

                  return (
                    <div key={bus.id} className="bg-white/95 p-4 rounded-2xl border border-white/10 space-y-3 shadow-md text-right text-xs relative flex flex-col justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between border-b pb-2">
                          <span className="font-extrabold text-[#0ea5e9] text-[12px] font-display">{bus.name}</span>
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${bus.status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>
                            {bus.status === "active" ? "✓ فاعلة" : "معلق مؤقتاً"}
                          </span>
                        </div>
                        <p className="text-slate-600 font-bold leading-relaxed"><strong>منطقة المسار الدراسي:</strong> {bus.route}</p>
                        <div className="space-y-1 text-[10px] text-slate-500 border-t pt-2 mt-2">
                          <p>👤 <strong>سائق الخط:</strong> {bus.driver}</p>
                          <p>👩‍✈️ <strong>مشرفة الحافلة:</strong> {bus.supervisor || "غير متوفر"}</p>
                          <p>📞 <strong>هاتف التواصل:</strong> {bus.phone}</p>
                          <p>📍 <strong>سعة المقاعد:</strong> {bus.capacity} مقعداً (شغل منها {occupiedSeats} طلاب)</p>
                        </div>
                      </div>

                      {isAdminLoggedIn && (
                        <div className="flex gap-1.5 justify-end pt-2 border-t mt-2 shrink-0">
                          <button
                            onClick={() => {
                              setEditingBusRoute(bus);
                              setBusRouteFormName(bus.name);
                              setBusRouteFormRoute(bus.route);
                              setBusRouteFormDriver(bus.driver);
                              setBusRouteFormPhone(bus.phone);
                              setBusRouteFormSupervisor(bus.supervisor || "");
                              setBusRouteFormCapacity(bus.capacity);
                              setBusRouteFormStatus(bus.status);
                              setIsBusModalOpen(true);
                            }}
                            className="bg-amber-50 text-amber-900 border border-amber-200 px-2.5 py-1 rounded-lg text-[9.5px] font-bold flex items-center gap-1 hover:bg-amber-100 transition"
                          >
                            تعديل الخط ⚙️
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`هل ترغب فعلاً بمسح وإلغاء حافلة ${bus.name} نهائياً؟`)) {
                                const updated = busRoutes.filter(b => b.id !== bus.id);
                                saveBusRoutes(updated);
                              }
                            }}
                            className="bg-rose-50 text-rose-700 border border-rose-100 px-2 py-1 rounded-lg text-[9.5px] font-bold flex items-center gap-1 hover:bg-rose-100 transition"
                          >
                            حذف ✖
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

        </div>
      )}


      {/* ADMIN LOGIN DIALOG POPUP MODAL */}
      {showAdminLoginPanel && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-slate-900 select-none animate-fade-in text-right">
          <div className="bg-white rounded-3xl w-full max-w-md border border-slate-150 overflow-hidden shadow-2xl animate-scale-up">
            
            <div className="bg-gradient-to-l from-slate-900 to-slate-800 text-white p-5 flex items-center justify-between">
              <h3 className="text-xs font-black flex items-center gap-1.5">
                <Lock className="w-4 h-4" />
                <span>تسجيل دخول لوحة الإشراف المالي للكنترول</span>
              </h3>
              <button 
                onClick={() => setShowAdminLoginPanel(false)} 
                className="text-white bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-lg text-xs font-bold transition duration-200 cursor-pointer"
              >
                ✖
              </button>
            </div>

            <form onSubmit={handleAdminLogin} className="p-6 space-y-4">
              <p className="text-xs text-slate-500 font-bold leading-relaxed">
                الرجاء تسجيل الدخول بكلمة مرور إدارة الموارد المالية والكنترول المدرسي للتمكن من تعديل الكشوفات، تنزيلها، وطباعتها:
              </p>

              {adminLoginError && (
                <div className="p-2.5 bg-rose-50 border border-rose-100 text-rose-700 font-black rounded-xl text-[10.5px] leading-relaxed">
                  ⚠️ {adminLoginError}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-[10px] font-black text-slate-600">كلمة مرور محاسبة الكنترول :</label>
                <input
                  type="password"
                  required
                  placeholder="أدخل كلمة مرور الإدارة..."
                  value={adminPasswordInput}
                  onChange={(e) => setAdminPasswordInput(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-slate-205 focus:border-sky-500 text-xs py-2.5 px-3 rounded-xl font-mono text-center tracking-widest text-slate-800 outline-none"
                />
              </div>

              <div className="pt-2 flex flex-col gap-2.5">
                <button
                  type="submit"
                  className="w-full bg-primary hover:bg-slate-900 text-white font-black py-2.5 rounded-xl text-xs transition duration-150"
                >
                  تأكيد الدخول المالي 🔓
                </button>
                
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotBox(true);
                    setForgotSuccess("");
                    setForgotError("");
                    setForgotEmailInput("");
                  }}
                  className="text-[10px] text-sky-600 hover:text-sky-700 font-extrabold text-center hover:underline cursor-pointer"
                >
                  نسيت كلمة المرور؟ 🔑
                </button>
              </div>

              {/* FORGOT PASSWORD SUB ROUTE */}
              {showForgotBox && (
                <div className="p-4 bg-sky-50/75 border border-sky-100 rounded-2xl text-xs space-y-3 animate-slide-down mt-3">
                  <p className="font-extrabold text-sky-850 flex items-center gap-1">
                    <span>🔑 بروتوكول استرداد كلمة المرور</span>
                  </p>
                  <p className="text-[10px] text-slate-600 leading-relaxed font-bold">
                    يجب إدخال البريد الإلكتروني المحمي الرسمي المعتمد لإدارة المدرسة وهو: <span className="font-mono text-primary font-black block select-all bg-white p-1 rounded border border-sky-100 mt-1">amlf.yen@gmail.com</span>
                  </p>

                  <div className="space-y-2.5">
                    <div className="space-y-1">
                      <label className="block text-[9.5px] font-bold text-slate-500">البريد الإلكتروني الرسمي للإدارة:</label>
                      <input
                        type="email"
                        required
                        placeholder="اكتب amlf.yen@gmail.com لتأكيد الهوية..."
                        value={forgotEmailInput}
                        onChange={(e) => setForgotEmailInput(e.target.value)}
                        className="w-full bg-white border border-slate-205 focus:border-sky-400 text-xs py-1.5 px-2.5 rounded-lg pr-2 text-slate-700"
                      />
                    </div>

                    {forgotError && (
                      <p className="text-[10px] text-rose-600 font-black">⚠️ {forgotError}</p>
                    )}

                    {forgotSuccess && (
                      <div className="p-2.5 bg-emerald-100/60 border border-emerald-200 text-emerald-850 font-black text-[10px] rounded-lg leading-relaxed select-all">
                        {forgotSuccess}
                      </div>
                    )}

                    <div className="flex items-center gap-2 justify-end pt-1">
                      <button
                        type="button"
                        onClick={() => setShowForgotBox(false)}
                        className="bg-slate-200 hover:bg-slate-300 text-slate-605 font-bold px-2.5 py-1 rounded-lg text-[10px]"
                      >
                        إلغاء المعاينة
                      </button>
                      <button
                        type="button"
                        onClick={handleForgotSubmit}
                        className="bg-sky-600 hover:bg-sky-700 text-white font-black px-3.5 py-1 rounded-lg text-[10px]"
                      >
                        تحقق وتأكيد ✉️
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-3 border-t text-center">
                <button
                  type="button"
                  onClick={() => setShowAdminLoginPanel(false)}
                  className="bg-slate-105 text-slate-500 hover:bg-slate-200 px-4 py-2 rounded-xl text-xs font-bold"
                >
                  إلغاء وإغلاق
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* 2. EDITING SCHOOL GENERAL FEES FORMATS MODAL (ADMIN ONLY) */}
      {isEditingFeesModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-slate-900 select-none animate-fade-in text-right">
          <div className="bg-white rounded-3xl w-full max-w-sm border border-slate-150 overflow-hidden shadow-2xl animate-scale-up">
            <div className="bg-gradient-to-l from-sky-900 to-slate-800 text-white p-5 flex items-center justify-between">
              <h3 className="text-xs font-black flex items-center gap-1.5">
                <Edit3 className="w-4 h-4 text-amber-400" />
                <span>تعديل تعرفة الرسوم المقررة لـ {selectedGrade}</span>
              </h3>
              <button 
                onClick={() => setIsEditingFeesModalOpen(false)} 
                className="text-white bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-lg text-xs font-bold transition duration-200 cursor-pointer"
              >
                ✖
              </button>
            </div>

            <form onSubmit={handleSaveFeesTemplateSubmit} className="p-6 space-y-4">
              <p className="text-[10.5px] text-slate-500 font-bold leading-relaxed">
                تعديل الرسوم الدراسية السنوية المقررة لهذا الصف. سيتم اعتماد القيم الجديدة فورًا لكافة عمليات تسجيل الطلاب وحساب الاستعلامات الجدد:
              </p>

              <div className="space-y-3 font-sans">
                <div className="space-y-1">
                  <label className="block text-[10px] font-extrabold text-slate-600">رسوم قسط التعليم والتدريس (ريال):</label>
                  <input
                    type="number"
                    required
                    value={editTuitionFee}
                    onChange={(e) => setEditTuitionFee(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl font-mono text-center outline-none font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-extrabold text-slate-600">رسوم حافلات النقل المدرسي المعتادة (ريال):</label>
                  <input
                    type="number"
                    required
                    value={editBusFee}
                    onChange={(e) => setEditBusFee(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl font-mono text-center outline-none font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-extrabold text-slate-600">رسوم الزي المدرسي الرسمي والملحقات (ريال):</label>
                  <input
                    type="number"
                    required
                    value={editUniformFee}
                    onChange={(e) => setEditUniformFee(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl font-mono text-center outline-none font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-extrabold text-slate-600">رسوم حقيبة الكتب والمنهج المعتمد (ريال):</label>
                  <input
                    type="number"
                    required
                    value={editBooksFee}
                    onChange={(e) => setEditBooksFee(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl font-mono text-center outline-none font-bold"
                  />
                </div>
              </div>

              <div className="border-t pt-4 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-sky-600 hover:bg-sky-700 text-white font-black py-2.5 rounded-xl text-xs transition duration-150"
                >
                  حفظ وتأكيد التعديلات 💾
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditingFeesModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-500 px-4 py-2 rounded-xl text-xs font-bold"
                >
                  إلغاء التعديل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. SCHOOL BUS ROUTE ADD/EDIT DIALOG POPUP MODAL (ADMIN ONLY) */}
      {isBusModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-slate-900 select-none animate-fade-in text-right">
          <div className="bg-white rounded-3xl w-full max-w-md border border-slate-150 overflow-hidden shadow-2xl animate-scale-up">
            <div className="bg-gradient-to-l from-slate-900 to-slate-800 text-white p-5 flex items-center justify-between">
              <h3 className="text-xs font-black flex items-center gap-1.5">
                <Bus className="w-4 h-4 text-yellow-400 animate-bounce" />
                <span>{editingBusRoute ? `تعديل تفاصيل مسار ${editingBusRoute.name}` : "إضافة خط حافلة مدرسية جديد"}</span>
              </h3>
              <button 
                onClick={() => setIsBusModalOpen(false)} 
                className="text-white bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-lg text-xs font-bold transition duration-200 cursor-pointer"
              >
                ✖
              </button>
            </div>

            <form onSubmit={handleBusRouteSubmit} className="p-6 space-y-4">
              <p className="text-[10.5px] text-slate-500 font-bold leading-relaxed">
                يرجى إدخال وتعديل كافة بيانات خط خطوط النقل وسعة حافلة الطلاب الحالية بدقة، بما في ذلك كتابة اسم المشرف أو المشرفة لتنسيق وتأمين رحلة الطلاب اليومية:
              </p>

              <div className="space-y-3 font-sans">
                <div className="space-y-1">
                  <label className="block text-[10px] font-extrabold text-slate-600">اسم وتسمية الخط (مقر الإطلاق):</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: خط الحافلة D (أحمر)"
                    value={busRouteFormName}
                    onChange={(e) => setBusRouteFormName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl outline-none font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-extrabold text-slate-600">المربعات السكنية ومناطق المرور للمسار:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: المجمع السكني، شارع الستين، الأطراف الشمالية"
                    value={busRouteFormRoute}
                    onChange={(e) => setBusRouteFormRoute(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-extrabold text-slate-600">سائق الحافلة (الكابتن):</label>
                    <input
                      type="text"
                      required
                      placeholder="الكابتن أحمد هلال"
                      value={busRouteFormDriver}
                      onChange={(e) => setBusRouteFormDriver(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl outline-none font-bold"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] font-extrabold text-slate-600">رقم الهاتف للتواصل السريع:</label>
                    <input
                      type="text"
                      required
                      placeholder="7xxxxxxxx"
                      value={busRouteFormPhone}
                      onChange={(e) => setBusRouteFormPhone(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl font-mono text-center outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-extrabold text-slate-600">اسم مشرف أو مشرفة الخط:</label>
                    <input
                      type="text"
                      placeholder="مثال: أ. رائدة أحمد"
                      value={busRouteFormSupervisor}
                      onChange={(e) => setBusRouteFormSupervisor(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] font-extrabold text-slate-600">سعة المقاعد الكلية لحافلة الطلاب:</label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={100}
                      value={busRouteFormCapacity}
                      onChange={(e) => setBusRouteFormCapacity(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl font-mono text-center outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-extrabold text-slate-600">حالة خط السير والجاهزية للحافلة:</label>
                  <select
                    value={busRouteFormStatus}
                    onChange={(e) => setBusRouteFormStatus(e.target.value as "active" | "suspended")}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 text-xs py-2 px-3 rounded-xl outline-none cursor-pointer font-bold text-slate-700"
                  >
                    <option value="active">جاهزة وفاعلة ✓</option>
                    <option value="suspended">معلقة مؤقتاً ⚠️</option>
                  </select>
                </div>
              </div>

              <div className="border-t pt-4 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-slate-900 hover:bg-slate-950 text-white font-black py-2.5 rounded-xl text-xs transition duration-150"
                >
                  {editingBusRoute ? "تطبيق تعديلات وبنود الخط 💾" : "حفظ وإدراج الخط بساحة النقل +"}
                </button>
                <button
                  type="button"
                  onClick={() => setIsBusModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-500 px-4 py-2 rounded-xl text-xs font-bold"
                >
                  إلغاء Line
                </button>
              </div>
            </form>
          </div>
        </div>
      )}


      {/* INDIVIDUAL PRINTABLE RECEIPT MODAL & RENDER BLOCK */}
      {selectedReceiptStudent && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-slate-900/95 overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-2xl border border-slate-150 overflow-hidden shadow-2xl text-right animate-scale-up">
            
            {/* Modal Actions Header */}
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between no-print">
              <h3 className="text-xs font-black flex items-center gap-1.5">
                <Printer className="w-4 h-4 text-emerald-400" />
                <span>معاينة الإيصال المالي الرسمي القابل للطباعة</span>
              </h3>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    // Trigger browser printing for ONLY this card using the printable style rule we loaded
                    window.print();
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1 shadow-sm cursor-pointer select-none"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>اطبع الإيصال الآن 🖨️</span>
                </button>

                <button
                  onClick={() => setSelectedReceiptStudent(null)}
                  className="bg-white/10 hover:bg-white/20 text-white font-black px-3 py-1.5 rounded-lg text-xs"
                >
                  إغلاق النافذة ✖
                </button>
              </div>
            </div>

            {/* PRINT RECT CONTAINER STARTS (Using id print-invoice-root for dynamic @media print targeting) */}
            <div id="print-invoice-root" className="p-8 space-y-6 bg-white font-sans text-slate-900 printable-receipt-card">
              
              {/* Receipt school header logo */}
              <div className="flex justify-between items-center border-b-2 border-slate-900 pb-5">
                <div className="text-right space-y-1">
                  <h2 className="text-lg font-black text-slate-950 font-display">مدرسة أمل المستقبل الأهلية النموذجية 🌸</h2>
                  <p className="text-[11px] text-slate-500 font-bold">بوابة الكنترول والشؤون المالية والمدرسية المعتمدة</p>
                  <p className="text-[10px] text-slate-405 font-bold">تاريخ إصدار السند المالي: {new Date().toLocaleDateString("ar-YE")} م</p>
                </div>
                
                <div className="text-left border-r-2 border-slate-300 pr-4 shrink-0">
                  <span className="font-mono text-xs font-black text-slate-400 block pb-1">سند استعلام مالي رقم</span>
                  <span className="font-mono font-black text-sm bg-slate-900 text-white px-3 py-1 rounded-md">
                    #AM-{selectedReceiptStudent.id}-{new Date().getFullYear()}
                  </span>
                </div>
              </div>

              {/* Title label */}
              <div className="text-center py-2 bg-slate-100 border border-slate-200 rounded-xl relative select-none">
                <h3 className="text-sm font-black text-slate-800 tracking-wider">كشف كينونة الذمة المالية والرسوم وإشراك ساحة الباص</h3>
              </div>

              {/* Student identification table info */}
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-50/50 p-3 rounded-lg border border-slate-100">
                  <p className="text-slate-400 font-bold">الاسم الرباعي للطالب:</p>
                  <p className="font-extrabold text-[#111827] pt-0.5 text-sm">{selectedReceiptStudent.name}</p>
                </div>
                <div className="bg-slate-50/50 p-3 rounded-lg border border-slate-100 text-left">
                  <p className="text-slate-400 font-bold text-right">:الكود الأكاديمي الرقمي</p>
                  <p className="font-mono font-black text-[#111827] pt-0.5 text-sm text-right">{selectedReceiptStudent.id}</p>
                </div>
                <div className="bg-slate-50/50 p-3 rounded-lg border border-slate-100 col-span-2">
                  <p className="text-slate-400 font-bold">المرحلة والصف المعتمد باللوحة:</p>
                  <p className="font-extrabold text-slate-900 pt-0.5">{selectedReceiptStudent.grade}</p>
                </div>
              </div>

              {/* Detailed billing ledger breakdown table */}
              <div className="overflow-hidden rounded-xl border border-slate-200">
                <table className="w-full text-right text-xs table-auto border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-black border-b border-slate-200">
                      <th className="p-3">بند الرسوم والمستحقات الدراسية</th>
                      <th className="p-3 text-center">القيمة المقررة لعام 2026 م</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Tuition row */}
                    <tr className="border-b border-slate-100">
                      <td className="p-3 font-bold text-slate-800">1. القسط السنوي للرسوم التعليمية المقررة</td>
                      <td className="p-3 text-center font-mono font-bold text-slate-700">
                        {selectedReceiptStudent.tuitionFee.toLocaleString()} ريال يمني
                      </td>
                    </tr>
                    {/* Transportation route */}
                    <tr className="border-b border-slate-100">
                      <td className="p-3 font-bold text-slate-800">
                        2. رسوم نقل الحافلة المدرسية والمسارات 🚌 
                        <p className="text-[10px] text-slate-400 mt-0.5">({selectedReceiptStudent.busRoute})</p>
                      </td>
                      <td className="p-3 text-center font-mono font-bold text-sky-850">
                        {selectedReceiptStudent.busFee > 0 ? `${selectedReceiptStudent.busFee.toLocaleString()} ريال يمني` : "0 ريال يمني (غير مشترك)"}
                      </td>
                    </tr>
                    {/* Uniform fee */}
                    <tr className="border-b border-slate-100">
                      <td className="p-3 font-bold text-slate-800">3. كلفة الزي المدرسي الرسمي الموعد</td>
                      <td className="p-3 text-center font-mono font-bold text-slate-700">
                        {selectedReceiptStudent.uniformFee.toLocaleString()} ريال يمني
                      </td>
                    </tr>
                    {/* Books fee */}
                    <tr className="border-b border-slate-100">
                      <td className="p-3 font-bold text-slate-800">4. كراسات الدراسة وحقيبة المناهج والكتب المقررة</td>
                      <td className="p-3 text-center font-mono font-bold text-slate-700">
                        {selectedReceiptStudent.booksFee.toLocaleString()} ريال يمني
                      </td>
                    </tr>
                    {/* Sub aggregates expected */}
                    {(() => {
                      const expectedTotal = selectedReceiptStudent.tuitionFee + selectedReceiptStudent.busFee + selectedReceiptStudent.uniformFee + selectedReceiptStudent.booksFee;
                      const remaining = expectedTotal - selectedReceiptStudent.amountPaid;

                      return (
                        <>
                          <tr className="bg-slate-50/80 font-black text-slate-900 border-t-2 border-slate-200">
                            <td className="p-3 pr-4">إجمالي المطالبات المالية المترتبة كليًا:</td>
                            <td className="p-3 text-center font-mono text-sm">{expectedTotal.toLocaleString()} ريال يمني</td>
                          </tr>
                          <tr className="bg-emerald-50/30 font-black text-emerald-800 border-t border-slate-100">
                            <td className="p-3 pr-4">المبلغ المسدد المحصل بخزينة المدرسة:</td>
                            <td className="p-3 text-center font-mono text-sm text-emerald-800">{selectedReceiptStudent.amountPaid.toLocaleString()} ريال يمني</td>
                          </tr>
                          <tr className={`font-black border-t-2 border-slate-400 ${remaining <= 0 ? "bg-emerald-100/60 text-emerald-900" : "bg-rose-50 text-rose-800"}`}>
                            <td className="p-3 pr-4">المتبقي المطلوب تصفيتة بالكنترول المالي:</td>
                            <td className="p-3 text-center font-mono text-base font-black">
                              {remaining <= 0 ? "0 ريال (مسدد بالكامل ✓)" : `${remaining.toLocaleString()} ريال يمني`}
                            </td>
                          </tr>
                        </>
                      );
                    })()}
                  </tbody>
                </table>
              </div>

              {/* Seating and Bus allocation certificate in receipt */}
              {selectedReceiptStudent.busFee > 0 && (
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-1 block">
                  <p className="text-xs font-black text-slate-800 flex items-center gap-1.5 leading-none">
                    <span>🚌 شهادة اعتماد وحجز مقعد حافلة النقل:</span>
                  </p>
                  <p className="text-[10px] text-slate-500 font-medium leading-relaxed mt-1">
                    نشهد بأن الطالب <span className="font-extrabold text-[#111827]">{selectedReceiptStudent.name}</span> لديه مقعد معتمد بالرقم <span className="font-mono text-emerald-800 font-black">{selectedReceiptStudent.seatNumber}</span> على متن حافلات المدرسة التوصيلية المخصصة في مسار <span className="font-extrabold text-[#111827]">{selectedReceiptStudent.busRoute}</span>.
                  </p>
                </div>
              )}

              {/* Legal verification signatures */}
              <div className="pt-8 grid grid-cols-2 gap-4 text-xs select-none">
                <div className="text-center space-y-4">
                  <p className="font-extrabold text-slate-405">توقيع محاسب الكنترول المرجعي والمالية:</p>
                  <div className="h-10 flex items-end justify-center">
                    <span className="font-mono text-slate-350 italic text-[11px]">(مدرسة أمل المستقبل النموذجية)</span>
                  </div>
                </div>
                <div className="text-center space-y-4 border-r pr-4">
                  <p className="font-extrabold text-slate-405">توقيع واعتماد مدير إدارة المدرسة:</p>
                  <div className="h-10 flex items-end justify-center">
                    <span className="text-[11px] text-slate-450 font-bold decoration-teal-600 underline">الأستاذ / رئيس الكنترول المالي</span>
                  </div>
                </div>
              </div>

              {/* Footer text */}
              <div className="pt-4 border-t border-dashed text-center text-[10px] text-slate-400 flex justify-between">
                <span>* يحتفظ بهذا السند المالي كوثيقة رسمية مراجعة براء الذمة *</span>
                <span>تكنولوجيا الكنترول الذكي لمدرسة أمل 🌸</span>
              </div>

            </div>
            {/* PRINT RECT CONTAINER ENDS */}

            {/* Modal Actions Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2.5 no-print">
              <button
                type="button"
                onClick={() => setSelectedReceiptStudent(null)}
                className="bg-slate-200 hover:bg-slate-300 text-slate-650 font-extrabold px-5 py-2 rounded-xl text-xs transition cursor-pointer"
              >
                إغلاق المعاينة والرجوع للكشف
              </button>
            </div>

          </div>
        </div>
      )}

      {/* NEW STUDENT MODAL WINDOW (ADMIN ONLY) */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-slate-900 select-none animate-fade-in text-right">
          <div className="bg-white rounded-3xl w-full max-w-lg border border-slate-150 overflow-hidden shadow-2xl animate-scale-up">
            
            <div className="bg-gradient-to-l from-sky-600 to-sky-700 text-white p-5 flex items-center justify-between">
              <h3 className="text-sm font-black flex items-center gap-1.5">
                <Plus className="w-4 h-4" />
                <span>تسجيل طالب مالي وإدراج في الحافلة الدراسية</span>
              </h3>
              <button 
                onClick={() => {
                  setShowAddModal(false);
                  setErrorMsg("");
                }} 
                className="text-white bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-lg text-xs font-bold transition duration-200"
              >
                ✖ إغلاق
              </button>
            </div>

            <form onSubmit={handleAddStudentSubmit} className="p-6 space-y-4">
              
              {/* Error messages */}
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-[10.5px] text-rose-650 font-black leading-relaxed">
                  ⚠️ {errorMsg}
                </div>
              )}

              {/* Success Messages */}
              {successMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-[10.5px] text-emerald-800 font-black leading-relaxed">
                  ✓ {successMsg}
                </div>
              )}

              {/* Student basic ID */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-600">رقم الطالب الأكاديمي الرقمي (الرمز التعريفي الفريد):</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: 106..."
                  value={newId}
                  onChange={(e) => setNewId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2.5 px-3 rounded-xl font-extrabold pr-2 text-slate-755 outline-none"
                />
              </div>

              {/* Full Student Name */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-600">الاسم الثلاثي أو الكامل للبحث السريع كشفاً:</label>
                <input
                  type="text"
                  required
                  placeholder="أدخل اسم الطالب رباعياً..."
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2.5 px-3 rounded-xl font-bold pr-2 text-slate-750 outline-none"
                />
              </div>

              {/* Grade structure selection */}
              <div className="grid grid-cols-2 gap-4">
                
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-600">الصف الدراسي المقيد له:</label>
                  <select
                    value={newGrade}
                    onChange={(e) => setNewGrade(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2.5 px-2 rounded-xl font-extrabold cursor-pointer text-slate-700 outline-none"
                  >
                    {Object.keys(GRADE_FEES_TEMPLATES).map(gr => (
                      <option key={gr} value={gr}>{gr}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-600">الاشتراك بنقل الحافلة المدرسية؟</label>
                  <select
                    value={newBusOption}
                    onChange={(e) => setNewBusOption(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2.5 px-2 rounded-xl font-extrabold cursor-pointer text-slate-705 outline-none"
                  >
                    <option value="yes">نعم، اشتراك فاعل ومعد ومقعد حافلة</option>
                    <option value="no">لا، نقل شخصي متاح مجاناً</option>
                  </select>
                </div>

              </div>

              {/* Seat & Route if transport active */}
              {newBusOption === "yes" && (
                <div className="space-y-1 animate-slide-down">
                  <label className="block text-[10px] font-bold text-slate-600">خط حافلة التموضع وحجوزات النقل المدرسية:</label>
                  <select
                    value={newBusRoute}
                    onChange={(e) => setNewBusRoute(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-202 text-xs py-2.5 px-2 rounded-xl font-bold cursor-pointer text-slate-700 outline-none"
                  >
                    <option value="خط الحافلة A - الميناء والشعب">خط الحافلة A - الميناء وعقبة الشعب الكابتن عادل</option>
                    <option value="خط الحافلة B - شارع المطار والغربي">خط الحافلة B - شارع المطار والغربي الكابتن طارق</option>
                  </select>
                </div>
              )}

              {/* Custom Initial Down payment */}
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-605">المبلغ المدفوع كقسط مقدم عند التسجيل (ريال تعريض):</label>
                <input
                  type="number"
                  placeholder="مثال: 2000..."
                  value={customPaidAmount}
                  onChange={(e) => setCustomPaidAmount(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-205 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/20 text-xs py-2.5 px-3 rounded-xl font-extrabold text-slate-755 outline-none"
                />
                <span className="text-[9px] text-slate-400 block pt-0.5">سيقوم الكنترول بحساب المتبقي وتعيين الحالة تلقائياً بعد الإرسال والمراجعة.</span>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="bg-slate-105 text-slate-505 hover:bg-slate-200 font-extrabold px-4 py-2.5 rounded-xl text-xs transition duration-150 cursor-pointer select-none"
                >
                  إلغاء الأمر
                </button>
                <button
                  type="submit"
                  className="bg-sky-600 hover:bg-sky-700 text-white font-black px-5 py-2.5 rounded-xl text-xs transition duration-150 shadow-md flex items-center gap-1.5 cursor-pointer select-none"
                >
                  <span>سجل واعتمد القيد ✓</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
