import React from "react";
import { BookOpen, Award, CheckCircle, ShieldCheck, Heart, User, Sparkles } from "lucide-react";

export default function About() {
  return (
    <div id="about-section" className="space-y-16 pb-12 text-right">
      {/* Intro Header */}
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <span className="bg-primary/15 text-primary text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wider">
          تعرف علينا عن قرب
        </span>
        <h1 className="text-3xl md:text-4xl font-extrabold text-slate-900 font-display">
          من نحن - مدرسة أمل المستقبل الأهلية
        </h1>
        <p className="text-slate-500 text-sm md:text-base leading-relaxed">
          تاريخ حافل بالعطاء الأكاديمي، وبيئة تربوية رائدة تأسست لبناء عقول واعدة وطموحة تقود مسيرة الأمل والتطوير.
        </p>
      </div>

      {/* Grid: School History & Vision */}
      <section className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold font-display text-slate-800">تاريخ مدرستنا العريق</h2>
            <div className="h-1 w-16 bg-accent rounded-full"></div>
          </div>
          <p className="text-slate-600 text-sm leading-relaxed">
            تأسست مدرسة <strong className="text-primary">أمل المستقبل الأهلية</strong> بهدف سد الفجوة بين التقنيات الحديثة والمناهج التعليمية المتوارثة. منذ البداية، حرصنا على توفير المعامل العلمية المتكاملة، وتوظيف كوادر حاصلة على أعلى الاعتمادات المهنية في الشرق الأوسط.
          </p>
          <p className="text-slate-600 text-sm leading-relaxed">
            استمرت مدرستنا في التوسع لتشمل كافة المراحل التعليمية من التمهيدي ورياض الأطفال حتى الحصول على الشهادة الثانوية العامة المعتمدة، مستندين في ذلك إلى شراكات فاعلة وتكنولوجيا الفصول الذكية المتطورة.
          </p>

          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center gap-3">
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">اعتماد مرخص</p>
                <p className="text-xs text-slate-400">كامل الترخيص التربوي</p>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center gap-3">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">تكنولوجيا رائدة</p>
                <p className="text-xs text-slate-400">فصول ومعامل ذكية</p>
              </div>
            </div>
          </div>
        </div>

        <div className="relative">
          <div className="w-full h-80 rounded-2xl overflow-hidden shadow-lg border border-slate-100">
            <img 
              src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=600" 
              alt="School Campus" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-6 -right-6 bg-primary text-white p-6 rounded-2xl shadow-xl flex items-center gap-3">
            <span className="text-4xl font-extrabold text-accent">10+</span>
            <div className="leading-tight text-xs">
              <p className="font-bold">سنوات من</p>
              <p className="text-blue-100">التميز التربوي المستمر</p>
            </div>
          </div>
        </div>
      </section>

      {/* Word from the Principal Section */}
      <section className="bg-white rounded-3xl border border-slate-100 p-8 md:p-12 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 left-0 w-32 h-32 bg-primary/5 rounded-full blur-xl"></div>
        <div className="grid md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-4 flex justify-center">
            <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-slate-100 shadow-md">
              <img 
                src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=300" 
                alt="المربي الفاضل د. عبد الرحمن بن فهد" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          <div className="md:col-span-8 space-y-4">
            <div className="text-right">
              <span className="bg-accent/15 text-accent text-xs font-bold px-3 py-1 rounded-full">كلمة القيادة المدرسية</span>
              <h3 className="text-2xl font-bold text-slate-800 font-display mt-2">رسالة المربي الفاضل مدير المدرسة</h3>
              <p className="text-xs text-slate-400">الأستاذ القدير عبده محمد الأهدل</p>
            </div>
            
            <p className="text-slate-600 text-sm leading-relaxed italic">
              &quot;أبنائي وبناتي الطلبة، السادة أولياء الأمور الأفاضل بمدينة باجل والحديدة، إن بناء عقل الطالب لا يتطلب تكرار العلوم فقط، بل يتطلب غرس نوازع الخير، وغرس الأخلاق والابتكار. في مدرسة أمل المستقبل الأهلية النموذجية، سخرنا كل الأساليب التكنولوجية والوسائل الحديثة لخدمة طفلكم وتنشئته التنشئة القويمة السليمة ليكون من صناع المستقبل المشرق.&quot;
            </p>
          </div>
        </div>
      </section>

      {/* Core Values Section */}
      <section className="space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold font-display text-slate-800">قيمنا الراسخة التي نوجه بها طلابنا</h2>
          <p className="text-slate-500 max-w-md mx-auto text-xs">نبني شخصية الطالب برباعية متكاملة لضمان التفوق الحقيقي في المجتمع</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: Award, title: "التميز الأكاديمي", bg: "bg-blue-50 text-blue-600", desc: "نحرص على بلوغ أعلى مستويات التعلم والتحصيل والنتائج." },
            { icon: ShieldCheck, title: "الأمان والالتزام", bg: "bg-emerald-50 text-emerald-600", desc: "بيئة خالية من المشاحنات ومراقبة إلكترونياً لسلامة الطالب." },
            { icon: Heart, title: "القيم التربوية الأخلاقية", bg: "bg-rose-50 text-rose-600", desc: "غرس التواضع، الكرم، المحبة والصددق تماشياً مع قيمنا الأصيلة." },
            { icon: User, title: "التمكين وتطوير القيادة", bg: "bg-amber-50 text-amber-600", desc: "صناعة القرار والتحدث بطلاقة وإعداد مشاريع شخصية متميزة." }
          ].map((item, idx) => (
            <div key={idx} className="bg-white border border-slate-50 rounded-2xl p-6 text-center space-y-4 hover:-translate-y-1 transition duration-300 shadow-sm hover:shadow-md">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mx-auto ${item.bg}`}>
                <item.icon className="w-6 h-6" />
              </div>
              <h3 className="text-md font-bold text-slate-800 font-display">{item.title}</h3>
              <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Accreditations Section */}
      <section className="bg-slate-50 border border-slate-100 rounded-3xl p-8 text-center space-y-6">
        <h3 className="text-lg font-bold text-slate-800 font-display">شركاء النجاح والاعتمادات التربوية الوطنية</h3>
        <p className="text-slate-500 text-xs max-w-lg mx-auto leading-relaxed">المدرسة مرخصة بالكامل ومعتمدة من وزارة التربية والتعليم وهيئة تقويم التعليم والتدريب، بالإضافة لشهادات الجودة التعليمية الإقليمية.</p>
        
        <div className="flex flex-wrap items-center justify-center gap-8 pt-4 grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition duration-300">
          {[
            { tag: "وزارة التعليم", label: "اعتماد وزارة التعليم" },
            { tag: "الجودة المدرسية", label: "شهادة ISO للجودة الأكاديمية" },
            { tag: "هيئة التقويم", label: "تقويم التعليم والتدريب المتميز" },
            { tag: "الاعتماد الدولي", label: "شريك كامبريدج لتقييم اللغة" }
          ].map((item, index) => (
            <div key={index} className="bg-white px-5 py-3 rounded-xl shadow-sm border border-slate-100 flex items-center gap-2">
              <span className="text-primary text-sm font-extrabold">🎖</span>
              <span className="text-xs font-bold text-slate-750">{item.label}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
