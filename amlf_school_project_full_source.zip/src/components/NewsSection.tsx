import React, { useState } from "react";
import { SchoolNews } from "../types";
import { initialNews, saveData, getSavedData } from "../data";
import { Calendar, Filter, Share2, Heart, Award, ArrowLeft, Trash2, Edit } from "lucide-react";

export default function NewsSection() {
  const [newsList, setNewsList] = useState<SchoolNews[]>(() => {
    return getSavedData<SchoolNews[]>("school_news", initialNews);
  });
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [activeArticle, setActiveArticle] = useState<SchoolNews | null>(null);

  // Likes counter simulation to make it feel real & stateful!
  const [likes, setLikes] = useState<Record<string, number>>({
    "news-1": 42,
    "news-2": 15,
    "news-3": 28,
    "news-4": 56
  });

  // Admin authentication
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    return localStorage.getItem("news_gallery_authenticated") === "true";
  });
  const [passwordInput, setPasswordInput] = useState<string>("");
  const [passwordError, setPasswordError] = useState<string>("");

  // Editor states
  const [editId, setEditId] = useState<string | null>(null);
  const [newsTitle, setNewsTitle] = useState<string>("");
  const [newsContent, setNewsContent] = useState<string>("");
  const [newsCategory, setNewsCategory] = useState<"أخبار" | "إعلان" | "إنجاز" | "رحلة">("أخبار");
  const [newsImage, setNewsImage] = useState<string>("");
  const [newsFormError, setNewsFormError] = useState<string>("");
  const [newsFormSuccess, setNewsFormSuccess] = useState<string>("");

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikes(prev => ({
      ...prev,
      [id]: (prev[id] || 0) + 1
    }));
  };

  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput.trim() === "64a93s") {
      setIsAdmin(true);
      localStorage.setItem("news_gallery_authenticated", "true");
      setPasswordError("");
      setPasswordInput("");
    } else {
      setPasswordError("كلمة المرور غير صحيحة، يرجى المحاولة مرة أخرى.");
    }
  };

  const handlePublishNews = (e: React.FormEvent) => {
    e.preventDefault();
    setNewsFormError("");
    setNewsFormSuccess("");

    if (!newsTitle.trim() || !newsContent.trim()) {
      setNewsFormError("يرجى ملء عنوان الخبر وتفاصيله بوضوح لمتابعة الإجراء.");
      return;
    }

    const fallbackImg = "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600";
    const finalImage = newsImage.trim() || fallbackImg;

    if (editId) {
      // Modify existing news item
      const updated = newsList.map(item => {
        if (item.id === editId) {
          return {
            ...item,
            title: newsTitle.trim(),
            content: newsContent.trim(),
            category: newsCategory,
            imageUrl: finalImage
          };
        }
        return item;
      });
      setNewsList(updated);
      saveData("school_news", updated);
      setNewsFormSuccess("تم تصحيح وتعديل الخبر وحفظه بنجاح!");
      setEditId(null);
    } else {
      // Add new news item
      const newItem: SchoolNews = {
        id: "news-" + Date.now(),
        title: newsTitle.trim(),
        content: newsContent.trim(),
        date: new Date().toISOString().split("T")[0],
        category: newsCategory,
        imageUrl: finalImage
      };
      const updated = [newItem, ...newsList];
      setNewsList(updated);
      saveData("school_news", updated);
      setNewsFormSuccess("تم نشر الخبر الجديد وإدراجه بنجاح لقائمة الأخبار!");
    }

    // Reset fields
    setNewsTitle("");
    setNewsContent("");
    setNewsImage("");
    setTimeout(() => {
      setNewsFormSuccess("");
    }, 4000);
  };

  const startEditNews = (item: SchoolNews, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAdmin) {
      alert("يرجى إلغاء قفل لوحة التحكم الإدارية لتمكين التصحيح والتعديل.");
      return;
    }
    setEditId(item.id);
    setNewsTitle(item.title);
    setNewsContent(item.content);
    setNewsCategory(item.category);
    setNewsImage(item.imageUrl);
    document.getElementById("admin-news-editor-form")?.scrollIntoView({ behavior: "smooth" });
  };

  const handleDeleteNews = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAdmin) {
      alert("يرجى إلغاء قفل لوحة التحكم الإدارية لاتمام عملية الحذف.");
      return;
    }
    if (window.confirm("هل بالتأكيد ترغب في حذف هذا الخبر نهائياً من أرشيف الأخبار المدرسية؟")) {
      const updated = newsList.filter(item => item.id !== id);
      setNewsList(updated);
      saveData("school_news", updated);
      if (activeArticle && activeArticle.id === id) {
        setActiveArticle(null);
      }
    }
  };

  const filteredNews = selectedCategory === "all"
    ? newsList
    : newsList.filter(item => item.category === selectedCategory);

  return (
    <div id="news-section-view" className="space-y-12 pb-12 text-right">
      
      {/* Article Detail Viewer */}
      {activeArticle && (
        <div id="full-article-overlay" className="bg-white border border-slate-100 rounded-3xl p-8 shadow-md space-y-6">
          <button 
            onClick={() => setActiveArticle(null)}
            className="flex items-center gap-2 text-primary hover:text-accent font-bold text-xs pb-2 border-b border-slate-100 w-full text-right transition-colors"
          >
            <ArrowLeft className="w-5 h-5 rotate-180" />
            <span>العودة إلى قائمة الأخبار والتعاميم المدرسية</span>
          </button>

          <img 
            src={activeArticle.imageUrl} 
            alt={activeArticle.title}
            className="w-full h-80 object-cover rounded-2xl shadow-sm border border-slate-100"
            referrerPolicy="no-referrer"
          />

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
            <span className="bg-primary/10 text-primary font-bold px-3 py-1 rounded-full">{activeArticle.category}</span>
            <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> {activeArticle.date}</span>
            <span className="text-rose-500 font-medium">❤️ {likes[activeArticle.id] || 0} تفاعلوا مع الخبر</span>
          </div>

          <h2 className="text-2xl font-bold font-display text-slate-950">{activeArticle.title}</h2>
          
          <p className="text-slate-600 leading-relaxed text-sm whitespace-pre-wrap">{activeArticle.content}</p>

          <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
            <button 
              onClick={(e) => handleLike(activeArticle.id, e)}
              className="bg-rose-50 text-rose-600 hover:bg-rose-100 px-6 py-2.5 rounded-xl font-bold text-xs transition duration-200 flex items-center gap-2"
            >
              <span>تسجيل إعجاب وتأييد للطلاب</span>
              <span>❤️</span>
            </button>
            <p className="text-slate-400 text-xs text-left">مدرستنا - مدرسة أمل المستقبل الأهلية © 2026</p>
          </div>
        </div>
      )}

      {!activeArticle && (
        <>
          {/* Intro Header */}
          <div className="text-center space-y-4 max-w-2xl mx-auto">
            <span className="bg-accent/20 text-accent text-xs font-bold px-4 py-1.5 rounded-full border border-accent/20">
              مدونة الأخبار والفعاليات
            </span>
            <h1 className="text-3xl font-extrabold text-slate-900 font-display">
              أخبار وفعاليات مدرسة أمل المستقبل الأهلية
            </h1>
            <p className="text-slate-500 text-sm">
              تابعوا باستمرار الفعاليات الحية والمكرمين، وتفاصيل الأنشطة الميدانية والقرارات المدرسية الهامة لأولياء الأمور أولاً بأول.
            </p>
          </div>

          {/* Categorical Filtering Bar */}
          <div className="flex flex-wrap items-center gap-3 justify-center border-b border-slate-100 pb-6">
            <Filter className="w-4 h-4 text-slate-400 ml-1" />
            {[
              { id: "all", label: "كافة الأخبار" },
              { id: "أخبار", label: "أخبار المدرسة العامة" },
              { id: "إعلان", label: "إعلانات وتعاميم الإدارة" },
              { id: "إنجاز", label: "تكريم المتفوقين والإنجازات" },
              { id: "رحلة", label: "رحلات ميدانية وعملية" }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition duration-200 font-display ${
                  selectedCategory === cat.id
                    ? "bg-primary text-white shadow-md"
                    : "bg-white text-slate-600 border border-slate-100 hover:bg-slate-50"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Two-Column Responsive Split Layout */}
          <div className="grid lg:grid-cols-12 gap-8 items-start">
            
            {/* Right: News Cards (8 columns) */}
            <div className="lg:col-span-8 space-y-6">
              {filteredNews.length === 0 ? (
                <div className="text-center py-12 bg-white border border-dashed rounded-3xl">
                  <p className="text-3xl">📅</p>
                  <p className="text-sm font-bold text-slate-500 mt-2">لا توجد أخبار منشورة حالياً في هذا التبويب!</p>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-6">
                  {filteredNews.map((item) => (
                    <div 
                      key={item.id}
                      id={`news-card-${item.id}`}
                      onClick={() => setActiveArticle(item)}
                      className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between group cursor-pointer relative"
                    >
                      <div className="relative h-48 overflow-hidden">
                        <img 
                          src={item.imageUrl} 
                          alt={item.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-4 right-4">
                          <span className="bg-slate-900/85 text-white font-bold px-3 py-1 rounded-md text-[10px] tracking-wide backdrop-blur-sm border border-white/10">
                            {item.category}
                          </span>
                        </div>

                        {/* Edit and Delete Icons overlay */}
                        {isAdmin && (
                          <div className="absolute top-4 left-4 flex items-center gap-1.5 z-20">
                            <button
                              type="button"
                              onClick={(e) => startEditNews(item, e)}
                              title="تعديل وتصحيح تفاصيل الخبر"
                              className="p-1.5 bg-slate-900/85 hover:bg-amber-600 border border-white/10 text-white rounded-lg shadow-md transition duration-150 transform hover:scale-105 cursor-pointer z-30"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => handleDeleteNews(item.id, e)}
                              title="حذف هذا الخبر نهائياً"
                              className="p-1.5 bg-rose-600 hover:bg-rose-705 border border-white/10 text-white rounded-lg shadow-md transition duration-150 transform hover:scale-105 cursor-pointer z-30"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="p-6 space-y-4 flex-grow flex flex-col justify-between">
                        <div className="space-y-2">
                          <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                            <Calendar className="w-3.5 h-3.5" /> {item.date}
                          </span>
                          <h3 className="font-bold text-sm text-slate-800 font-display group-hover:text-primary transition duration-150 line-clamp-2">
                            {item.title}
                          </h3>
                          <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed">
                            {item.content}
                          </p>
                        </div>

                        <div className="pt-4 border-t border-slate-50 flex items-center justify-between text-xs font-semibold">
                          <button 
                            onClick={(e) => handleLike(item.id, e)}
                            className="text-slate-450 hover:text-rose-500 transition duration-150 flex items-center gap-1 p-1 hover:bg-slate-50 rounded-lg"
                          >
                            <span>❤️ {likes[item.id] || 0}</span>
                            <span className="text-[10px] text-slate-400">إعجاب</span>
                          </button>
                          
                          <span className="text-primary group-hover:text-accent font-bold flex items-center gap-1 transition-colors">
                            <span>عرض التفاصيل</span>
                            <span className="text-xs rotate-180">📊</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Left: Administrative Control Sidebar Panel (4 columns) */}
            <div className="lg:col-span-4">
              <div id="admin-news-editor-form" className="bg-gradient-to-br from-slate-50 via-white to-indigo-50/10 border-2 border-slate-150 rounded-3xl p-6 shadow-sm space-y-5">
                <div className="border-b border-indigo-100 pb-3 text-right">
                  <h3 className="font-extrabold text-slate-900 font-display text-base flex items-center gap-2 justify-start">
                    <span className="text-lg">⚙️</span>
                    <span>لوحة إدارة الأخبار المدرسية</span>
                  </h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">صلاحية النشر، الحذف، وتصحيح الأخطاء الإملائية والبيانات</p>
                </div>

                {!isAdmin ? (
                  /* Password Request Form */
                  <form onSubmit={handleVerifyPassword} className="space-y-4 text-right">
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      هذه اللوحة مخصصة للأعضاء المخولين بنشر الأخبار والتعديل. يرجى إدخال كلمة المرور للمتابعة:
                    </p>
                    <div className="space-y-1">
                      <input
                        type="password"
                        required
                        placeholder="أدخل رمز المرور الخاص لإدارة الأخبار"
                        value={passwordInput}
                        onChange={(e) => setPasswordInput(e.target.value)}
                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-center font-mono text-xs focus:outline-none focus:border-indigo-500 font-bold"
                      />
                      {passwordError && (
                        <p className="text-[10px] text-rose-600 bg-rose-50 p-2 rounded-lg text-center font-bold mt-1">{passwordError}</p>
                      )}
                    </div>
                    <button
                      type="submit"
                      className="w-full py-3 bg-[#1e293b] hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition duration-150"
                    >
                      فك قفل المحادثة والتحكم
                    </button>
                  </form>
                ) : (
                  /* Create or Edit news item form */
                  <form onSubmit={handlePublishNews} className="space-y-4 text-right text-xs">
                    {newsFormSuccess && (
                      <p className="p-2.5 bg-emerald-50 text-emerald-800 rounded-xl text-center font-bold border border-emerald-250 mb-3">{newsFormSuccess}</p>
                    )}
                    {newsFormError && (
                      <p className="p-2.5 bg-rose-50 text-rose-800 rounded-xl text-center font-bold border border-rose-250 mb-3">{newsFormError}</p>
                    )}

                    <div className="space-y-1">
                      <label className="text-slate-700 font-bold block">العنوان الكامل للخبر:</label>
                      <input
                        type="text"
                        required
                        placeholder="مثال: مدرسة المستقبل تفتتح قسم الحاسب الآلي"
                        value={newsTitle}
                        onChange={(e) => setNewsTitle(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 text-right font-sans"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-700 font-bold block">تبويب وتصنيف الخبر المضاف:</label>
                      <select
                        value={newsCategory}
                        onChange={(e: any) => setNewsCategory(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-right focus:outline-none focus:border-indigo-500"
                      >
                        <option value="أخبار">أخبار المدرسة العامة</option>
                        <option value="إعلان">إعلانات وتعاميم الإدارة</option>
                        <option value="إنجاز">تكريم المتفوقين والإنجازات</option>
                        <option value="رحلة">رحلات ميدانية وعملية</option>
                      </select>
                    </div>

                    <div className="space-y-2 bg-slate-50/70 p-3 rounded-2xl border border-slate-100">
                      <label className="text-slate-700 font-bold block">صورة الخبر المرفقة:</label>
                      <div className="space-y-2">
                        {/* File Upload Simulator */}
                        <label className="flex items-center justify-center gap-1.5 p-2 bg-white hover:bg-slate-55 border border-slate-200 text-slate-700 rounded-xl text-[10.5px] font-bold cursor-pointer transition">
                          <span>📁 رفع صورة محلية من جهازك</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  if (typeof reader.result === "string") {
                                    setNewsImage(reader.result);
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                        <input
                          type="text"
                          placeholder="أو الصق هنا رابط الصورة المباشر (رابط ويب)"
                          value={newsImage.startsWith("data:") ? "[صورة مرفوعة محلياً وجاهزة لتسجيل]" : newsImage}
                          onChange={(e) => setNewsImage(e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded-xl text-left focus:outline-none focus:border-indigo-500 text-[10px] font-mono"
                        />
                      </div>
                      {newsImage && (
                        <div className="mt-1 border rounded-lg overflow-hidden h-16 bg-white relative">
                          <img src={newsImage} alt="Preview" className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => setNewsImage("")}
                            className="absolute top-1 left-1 bg-rose-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded cursor-pointer"
                          >
                            حذف وإلغاء
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-700 font-bold block">المحتوى النصي المفصل وتفاصيل الخبر:</label>
                      <textarea
                        rows={4}
                        required
                        placeholder="اكتب هنا الخبر بالتفصيل والمخرجات والقرائن..."
                        value={newsContent}
                        onChange={(e) => setNewsContent(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-right focus:outline-none focus:border-indigo-500 font-sans leading-relaxed"
                      />
                    </div>

                    <div className="flex gap-1.5 pt-2">
                      {editId && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditId(null);
                            setNewsTitle("");
                            setNewsContent("");
                            setNewsImage("");
                          }}
                          className="w-1/3 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-bold transition"
                        >
                          إلغاء التعديل
                        </button>
                      )}
                      <button
                        type="submit"
                        className="flex-grow py-2.5 bg-indigo-600 hover:bg-[#1e293b] text-white rounded-xl font-bold transition"
                      >
                        {editId ? "حفظ وتثبيت التعديلات" : "نشر الخبر فورياً 📢"}
                      </button>
                    </div>

                    <div className="text-center pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAdmin(false);
                          localStorage.removeItem("news_gallery_authenticated");
                        }}
                        className="text-[9.5px] text-slate-400 hover:underline hover:text-rose-600 font-bold"
                      >
                        🔒 تسجيل الخروج وقفل اللوحة الإدارية
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>

          </div>
        </>
      )}
    </div>
  );
}
