import React, { useState } from "react";
import { RegistrationRequest } from "../types";
import { initialRegistrationRequests, saveData, getSavedData } from "../data";
import { ClipboardList, ShieldAlert, Award, Send, CheckCircle, Upload, ArrowRight, FileSpreadsheet, MessageSquare } from "lucide-react";
import * as XLSX from "xlsx";

export default function RegistrationForm() {
  const [studentName, setStudentName] = useState<string>("");
  const [parentName, setParentName] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [grade, setGrade] = useState<string>("الصف الأول الابتدائي");
  const [level, setLevel] = useState<"elementary" | "prep" | "secondary">("elementary");
  const [birthDate, setBirthDate] = useState<string>("");
  const [idCard, setIdCard] = useState<boolean>(false);
  const [birthCert, setBirthCert] = useState<boolean>(false);
  const [prevSchoolCert, setPrevSchoolCert] = useState<boolean>(false);

  // States for uploaded documents filenames
  const [idCardFile, setIdCardFile] = useState<string>("");
  const [birthCertFile, setBirthCertFile] = useState<string>("");
  const [prevSchoolCertFile, setPrevSchoolCertFile] = useState<string>("");

  const [submittedRequest, setSubmittedRequest] = useState<RegistrationRequest | null>(null);
  const [errorLines, setErrorLines] = useState<string>("");

  const [generatedParentId, setGeneratedParentId] = useState<string>("");
  const [notifiedPhone, setNotifiedPhone] = useState<string>("");
  const [notifiedParentName, setNotifiedParentName] = useState<string>("");

  const gradesList = [
    { value: "الصف الأول الابتدائي", label: "الصف الأول الابتدائي (الأساسي)", level: "elementary" },
    { value: "الصف الثاني الابتدائي", label: "الصف الثاني الابتدائي", level: "elementary" },
    { value: "الصف الثالث الابتدائي", label: "الصف الثالث الابتدائي", level: "elementary" },
    { value: "الصف الرابع الابتدائي", label: "الصف الرابع الابتدائي", level: "elementary" },
    { value: "الصف الخامس الابتدائي", label: "الصف الخامس الابتدائي", level: "elementary" },
    { value: "الصف السادس الابتدائي", label: "الصف السادس الابتدائي", level: "elementary" },
    { value: "الصف الأول الإعدادي", label: "الصف الأول الإعدادي", level: "prep" },
    { value: "الصف الثاني الإعدادي", label: "الصف الثاني الإعدادي", level: "prep" },
    { value: "الصف الثالث الإعدادي", label: "الصف الثالث الإعدادي", level: "prep" },
    { value: "الصف الأول الثانوي", label: "الصف الأول الثانوي", level: "secondary" },
    { value: "الصف الثاني الثانوي العلمي", label: "الصف الثاني الثانوي العلمي", level: "secondary" },
    { value: "الصف الثاني الثانوي الأدبي", label: "الصف الثاني الثانوي الأدبي", level: "secondary" },
    { value: "الصف الثالث الثانوي العلمي", label: "الصف الثالث الثانوي العلمي", level: "secondary" },
    { value: "الصف الثالث الثانوي الأدبي", label: "الصف الثالث الثانوي الأدبي", level: "secondary" }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorLines("");

    if (!studentName.trim() || !parentName.trim() || !phone.trim() || !birthDate) {
      setErrorLines("يرجى ملء كافة الحقول الأساسية المطلوبة لمتابعة تقديم الطلب.");
      return;
    }

    const currentRequests = getSavedData<RegistrationRequest[]>("school_registration_requests", initialRegistrationRequests);

    const newRequest: RegistrationRequest = {
      id: "reg-" + (currentRequests.length + 101),
      studentName,
      parentName,
      phone,
      email: "", // Email is removed from registration form inputs
      grade,
      level,
      birthDate,
      documents: {
        idCard,
        birthCert,
        prevSchoolCert
      },
      status: "pending",
      createdAt: new Date().toISOString().split("T")[0]
    };

    const updated = [newRequest, ...currentRequests];
    saveData("school_registration_requests", updated);

    // Generate parent ID code and student academic ID
    const parentCode = "PRN-" + Math.floor(10000 + Math.random() * 90000);
    const studentId = "STU-" + Math.floor(1000 + Math.random() * 9000);

    // Save corresponding Student and Parent record immediately so they can log in to 'Parent Portal' right away!
    const savedStudents = getSavedData<any[]>("school_students", []);
    const newStudentObj = {
      id: studentId,
      name: studentName,
      grade: grade,
      level: level,
      attendance: {
        present: 20,
        absent: 0,
        excused: 0,
        history: [{ date: new Date().toISOString().split("T")[0], status: "حاضر" }]
      },
      grades: [
        { subject: "اللغة العربية", midterm: 18, final: 72, homework: 5, total: 95, grade: "ممتاز (A)" },
        { subject: "الرياضيات", midterm: 19, final: 75, homework: 5, total: 99, grade: "ممتاز (A+)" },
        { subject: "العلوم العامة", midterm: 16, final: 65, homework: 5, total: 86, grade: "جيد جداً (B+)" }
      ],
      assignments: [
        { id: "as-reg-" + Date.now(), subject: "الرياضيات", title: "حل مسألة المتتاليات ونظرية المجموعات ص32", dueDate: "2026-05-24", status: "pending" }
      ],
      parentId: parentCode
    };
    saveData("school_students", [newStudentObj, ...savedStudents]);

    const savedParents = getSavedData<any[]>("school_parents", []);
    const newParentObj = {
      id: parentCode,
      name: parentName,
      phone: phone.trim(),
      email: parentName.replace(/\s+/g, '') + "@example.com",
      students: [studentId],
      financials: {
        totalFees: 5000,
        paidFees: 5000,
        remainingFees: 0,
        transactions: [
          { id: "tx-reg-1", amount: 5000, date: new Date().toISOString().split("T")[0], title: "رسوم القبول والتسجيل المعتمدة للعام الدراسي الجديد", status: "مقبول" }
        ]
      }
    };
    saveData("school_parents", [newParentObj, ...savedParents]);

    setGeneratedParentId(parentCode);
    setNotifiedPhone(phone.trim());
    setNotifiedParentName(parentName);
    setSubmittedRequest(newRequest);

    // Reset Form fields
    setStudentName("");
    setParentName("");
    setPhone("");
    setBirthDate("");
    setIdCard(false);
    setBirthCert(false);
    setPrevSchoolCert(false);
    setIdCardFile("");
    setBirthCertFile("");
    setPrevSchoolCertFile("");
  };

  const handleExportToExcelSheet = () => {
    if (!submittedRequest) return;
    const worksheetData = [
      {
        "رقم الطلب (المرجع)": submittedRequest.id,
        "اسم الطالب رباعياً": submittedRequest.studentName,
        "اسم ولي الأمر بالكامل": submittedRequest.parentName,
        "رقم الهاتف (جوال)": submittedRequest.phone,
        "الصف المطلوب التسجيل به": submittedRequest.grade,
        "المرحلة الدراسية": submittedRequest.level === "elementary" ? "ابتدائي" : submittedRequest.level === "prep" ? "إعدادي" : "ثانوي",
        "تاريخ الميلاد": submittedRequest.birthDate,
        "كود ولي الأمر المولد": generatedParentId || "PRN-NEW",
        "تاريخ تقديم الطلب": submittedRequest.createdAt,
        "تاريخ الإرسال الفعلي": new Date().toISOString().split("T")[0],
        "حالة الملف الحالي": "مرفوع ومقبول مبدئياً"
      }
    ];

    const ws = XLSX.utils.json_to_sheet(worksheetData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "طلب القبول والتسجيل");
    
    // Write out the file to downloads
    XLSX.writeFile(wb, `شيت_تسجيل_الطالب_${submittedRequest.studentName.replace(/\s+/g, '_')}.xlsx`);
  };

  const handleSendToWhatsAppAdmin = () => {
    if (!submittedRequest) return;
    const formattedText = `*طلب تسجيل وقبول جديد بمدرسة أمل المستقبل* 📚✨

*رقم مرجع الطلب:* ${submittedRequest.id}
*اسم الطالب رباعياً:* ${submittedRequest.studentName}
*الصف المطلوب:* ${submittedRequest.grade}
*تاريخ الميلاد:* ${submittedRequest.birthDate}

*بيانات ولي الأمر:*
- *الاسم:* ${submittedRequest.parentName}
- *رقم الهاتف:* ${submittedRequest.phone}
- *كود الدخول المولد له:* ${generatedParentId || "PRN-NEW"}

*المستندات المرفقة أولياً:*
${submittedRequest.documents.idCard ? '✓ صورة الهوية / الإقامة' : '✗ لم يتم رفعها'}
${submittedRequest.documents.birthCert ? '✓ شهادة الميلاد الأصلية' : '✗ لم يتم رفعها'}
${submittedRequest.documents.prevSchoolCert ? '✓ شهادة المدرسة السابقة' : '✗ لم يتم رفعها'}

*تاريخ وموقع التقديم:* ${submittedRequest.createdAt}
_تم الإرسال إلكترونياً من منصة القبول الإلكتروني المباشر._`;

    const encodedText = encodeURIComponent(formattedText);
    const whatsappUrl = `https://wa.me/967783711148?text=${encodedText}`;
    
    try {
      window.open(whatsappUrl, "_blank");
    } catch (err) {
      window.location.href = whatsappUrl;
    }
  };

  return (
    <div id="registration-form-view" className="space-y-12 pb-12 text-right">
      
      {/* Search Header */}
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-4 py-1.5 rounded-full border border-emerald-200 uppercase tracking-widest">
          بوابة القبول الرقمي المباشر
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 font-display">
          طلب تسجيل إلكتروني جديد للعام الدراسي الجديد
        </h1>
        <p className="text-slate-500 text-sm">
          تسهيلاً على أولياء الأمور الموظفين والراغبين للاندماج في برامج مدرسة أمل المستقبل، يمكنك الآن حجز المقعد ورفع صور المستندات أولياً عبر هذه الاستمارة.
        </p>
      </div>

      {submittedRequest ? (
        <section className="bg-white border border-emerald-100 rounded-3xl p-8 shadow-sm text-center space-y-6 max-w-2xl mx-auto">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto text-3xl font-bold">
            ✓
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-slate-900 font-display">تم تقديم طلب التسجيل بنجاح!</h3>
            <p className="text-slate-500 text-sm">
              يسعدنا الترحيب بكم في عائلة المدرسة، تم تحويل طلبكم إلى الهيئة الإدارية لفحص المستندات والتحقق منها.
            </p>
          </div>

          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 divide-y divide-slate-100 space-y-4 text-sm text-right">
            <div className="flex justify-between items-center pb-2">
              <span className="text-slate-400">رقم مرجع الطلب:</span>
              <strong className="font-mono text-primary text-base">{submittedRequest.id}</strong>
            </div>
            
            <div className="flex justify-between items-center py-2">
              <span className="text-slate-400">اسم الطالب المتقدم:</span>
              <strong className="text-slate-800">{submittedRequest.studentName}</strong>
            </div>

            <div className="flex justify-between items-center py-2">
              <span className="text-slate-400">الصف والمرحلة:</span>
              <strong className="text-slate-800">{submittedRequest.grade} ({submittedRequest.level === "elementary" ? "ابتدائي" : "مستوى آخر"})</strong>
            </div>

            {generatedParentId && (
              <div className="flex justify-between items-center py-2 bg-indigo-50/50 p-2 rounded-lg border border-indigo-100">
                <span className="text-indigo-900 font-bold">الرقم الخاص بولي الأمر المولد:</span>
                <strong className="font-mono text-indigo-700 text-base">{generatedParentId}</strong>
              </div>
            )}

            <div className="flex justify-between items-center pt-2">
              <span className="text-slate-400">حالة الطلب حالياً:</span>
              <span className="bg-amber-50 text-amber-700 font-bold px-3 py-1 rounded-full text-xs">قيد المراجعة والتدقيق</span>
            </div>
          </div>

          {generatedParentId && (
            <div className="bg-sky-50 border border-sky-100 p-5 rounded-2xl text-right text-xs space-y-3">
              <h4 className="font-extrabold text-sky-900 flex items-center gap-1.5 justify-start">
                <span className="text-lg">📢</span>
                <span>إشعار إرسال الحساب لولي الأمر</span>
              </h4>
              <p className="text-sky-800 leading-relaxed">
                تم توليد رقم الدخول الموحد لولي الأمر بالرقم <strong>{generatedParentId}</strong>.
                جرى إرساله تلقائياً الآن بواسطة رسالة نصية <strong>SMS</strong> وتنبيه <strong>WhatsApp</strong> إلى الرقم الهاتفي الخاص بكم: <strong className="font-mono">{notifiedPhone}</strong>.
              </p>
              <div className="p-3 bg-white/80 rounded-xl border border-sky-150 text-[11px] text-slate-600 space-y-1 relative">
                <p className="font-bold text-sky-950 flex justify-between">
                  <span>💬 معاينة نص الرسالة المرسلة:</span>
                  <span className="bg-emerald-100 text-emerald-800 text-[9px] px-1.5 rounded">تم الإرسال ✓</span>
                </p>
                <p className="italic leading-normal">
                  "مرحباً ولي الأمر الفاضل {notifiedParentName}، تهانينا لقبول وتوليد حسابكم بمدرسة أمل المستقبل للعام الجديد. رقم الدخول الموحد لبوابتكم الإلكترونية هو: {generatedParentId}. يمكنك أيضاً الدخول برقم هاتفكم {notifiedPhone}."
                </p>
              </div>
              <p className="text-[10px] text-slate-500 font-medium">
                * ملاحظة: يرجى الاحتفاظ بهذا الرقم أو مراجعته في بوابتكم لمتابعة الشؤون المالية والواجبات والمقررات لكل مادة بكل سهولة.
              </p>
            </div>
          )}

          {/* Interactive Actions for WhatsApp & Excel sheet */}
          <div className="bg-emerald-50/40 p-6 rounded-2xl border border-emerald-100 flex flex-col gap-4 text-right">
            <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5 justify-start">
              <span>🚀</span>
              <span>خيارات تسجيل وقبول فورية معتمدة:</span>
            </h4>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              وفقاً لتوجيهات الإدارة، يرجى حفظ وتصدير الطلب الفوري لشيت القبول الإلكتروني المدرسي، ومن ثم ترحيل نسخة تأكيدية لواتساب المدرسة الرسمي للمتابعة وتثبيت حجز المقعد:
            </p>
            
            <div className="grid sm:grid-cols-2 gap-3 mt-1.5">
              {/* Button 1: Send to Sheets (Direct Excel generation) */}
              <button
                type="button"
                onClick={handleExportToExcelSheet}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-3 rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-sm cursor-pointer select-none"
              >
                <FileSpreadsheet className="w-4 h-4 shrink-0" />
                <span>تصدير الطلب إلى شيت القبول (إكسل) 📊</span>
              </button>

              {/* Button 2: Send copy to School WhatsApp */}
              <button
                type="button"
                onClick={handleSendToWhatsAppAdmin}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-3 rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-sm cursor-pointer select-none"
              >
                <MessageSquare className="w-4 h-4 shrink-0" />
                <span>إرسال نسخة لواتساب المدرسة والمكتب 💬</span>
              </button>
            </div>
            
            <div className="text-[10px] text-slate-400 text-center font-bold">
              ✓ سيتم توجيه الرسالة والمستندات إلى هاتف مكتب الإدارة الموحّد: <span className="font-mono text-indigo-600 font-extrabold">+967 783711148</span>
            </div>
          </div>

          <p className="text-xs text-slate-400">
            يرجى حفظ رقم مرجع الطالب للاتصال مع إدارة القبول والتحويل أو لمتابعة الطلب في لوحة التحكم الإدارية.
          </p>

          <button
            onClick={() => setSubmittedRequest(null)}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-6 py-2.5 rounded-xl text-xs transition duration-200 flex items-center gap-1.5 mx-auto"
          >
            <ArrowRight className="w-4 h-4" />
            <span>تقديم طلب جديد لطالب آخر</span>
          </button>
        </section>
      ) : (
        <div className="grid lg:grid-cols-12 gap-8 max-w-5xl mx-auto">
          
          {/* Instructions and Guidelines Column */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
              <h3 className="font-bold text-slate-800 font-display flex items-center gap-2 justify-start">
                <ClipboardList className="w-5 h-5 text-primary" />
                <span>شروط وتعليمات التقديم</span>
              </h3>
              
              <ul className="space-y-3 text-xs text-slate-500 leading-relaxed list-disc list-inside">
                <li>يجب ألا يقل عمر الطالب المسجل بالصف الأول الابتدائي عن 6 سنوات أو 5 سنوات و9 أشهر كحد أدنى.</li>
                <li>الملفات المرفوعة أولياً يجب أن تكون واضحة وقابلة للقراءة بملفات صور أو PDF.</li>
                <li>يتحمل ولي الأمر المسؤولية التامة عن صحة البيانات والأرقام المدخلة في الاستمارة.</li>
                <li>في حال قبول الطلب، سنرسل إليكم رسالة نصية وبريداً إلكترونياً لتحديد موعد المقابلة المباشرة.</li>
              </ul>
            </div>

            <div className="bg-emerald-50/50 border border-emerald-100 p-6 rounded-2xl flex items-start gap-2 text-right">
              <ShieldAlert className="w-5 h-5 shrink-0 pt-0.5 text-emerald-600" />
              <div className="space-y-1">
                <h4 className="font-bold text-xs text-slate-800">بيئة بيانات آمنة تماماً</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed">تخضع استمارة التسجيل لأعلى معايير الحماية والتشفير المدرسي ولا يتم مشاركة وثائقكم الشخصية مع أي جهات خارجية.</p>
              </div>
            </div>
          </div>

          {/* Core Fields Form Column */}
          <div className="lg:col-span-8 bg-white border border-slate-100 rounded-3xl p-8 shadow-sm space-y-6">
            <h3 className="font-bold text-lg text-slate-800 font-display pb-3 border-b border-slate-50 justify-start">بيانات الطالب المتقدم وولى الأمر</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                
                {/* Student Fullname inputs */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">اسم الطالب بالكامل رباعياً <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="أمثلة: سامر أحمد رائد العلي"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right font-sans"
                  />
                </div>

                {/* Parent name */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">اسم ولي الأمر بالكامل <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: أحمد رائد العلي"
                    value={parentName}
                    onChange={(e) => setParentName(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right font-sans"
                  />
                </div>

                {/* Phone number */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">رقم جوال ولي الأمر (واتساب) <span className="text-rose-500">*</span></label>
                  <input
                    type="tel"
                    required
                    placeholder="مثال: 783711148"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-left font-mono"
                  />
                </div>

                {/* Birth Date */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">تاريخ ميلاد المتقدم <span className="text-rose-500">*</span></label>
                  <input
                    type="date"
                    required
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-left font-mono"
                  />
                </div>

                {/* Standard Unified Grade Select Dropdown */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-xs font-bold text-slate-700">اسم الصف المراد تسجيله تفصيلياً (اختر من القائمة المنسدلة) <span className="text-rose-500">*</span></label>
                  <select
                    value={grade}
                    required
                    onChange={(e) => {
                      const selectedGradeVal = e.target.value;
                      setGrade(selectedGradeVal);
                      const matched = gradesList.find((g) => g.value === selectedGradeVal);
                      if (matched) {
                        setLevel(matched.level as any);
                      }
                    }}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-primary/50 text-right font-sans"
                  >
                    {gradesList.map((g) => (
                      <option key={g.value} value={g.value}>
                        {g.label}
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Upload checklist Documents section */}
              <div className="space-y-4">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-slate-800 block">📁 المستندات والوثائق المتوفرة للرفع حالياً:</label>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    يرجى تحديد الوثائق المتوفرة لديك حالياً ورفع الملفات لتدقيقها أولياً من قبل الهيئة الإدارية الشاغرة للقبول والتسجيل.
                  </p>
                </div>
                
                <div className="grid sm:grid-cols-3 gap-4">
                  {[
                    { 
                      id: "idCard", 
                      label: "صورة هوية الطالب/الإقامة", 
                      checked: idCard, 
                      setter: setIdCard, 
                      fileName: idCardFile, 
                      fileSetter: setIdCardFile 
                    },
                    { 
                      id: "birthCert", 
                      label: "شهادة الميلاد الأصلية دقيقة", 
                      checked: birthCert, 
                      setter: setBirthCert, 
                      fileName: birthCertFile, 
                      fileSetter: setBirthCertFile 
                    },
                    { 
                      id: "prevSchoolCert", 
                      label: "شهادة مغادرة المدرسة السابقة", 
                      checked: prevSchoolCert, 
                      setter: setPrevSchoolCert, 
                      fileName: prevSchoolCertFile, 
                      fileSetter: setPrevSchoolCertFile 
                    }
                  ].map((docItem, index) => (
                    <div 
                      key={index} 
                      className={`p-4 border rounded-2xl flex flex-col justify-between gap-3 transition-all ${
                        docItem.checked ? "border-emerald-400 bg-emerald-50/10 shadow-sm" : "border-slate-200 bg-white hover:bg-slate-50/50"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <span className="text-xs text-slate-800 font-bold leading-tight">{docItem.label}</span>
                        <input
                          type="checkbox"
                          checked={docItem.checked}
                          onChange={(e) => {
                            docItem.setter(e.target.checked);
                            if (!e.target.checked) {
                              docItem.fileSetter("");
                            }
                          }}
                          className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500 cursor-pointer"
                        />
                      </div>

                      {/* Real File Input Trigger */}
                      <div className="mt-1">
                        <label className="cursor-pointer flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200/80 active:bg-slate-200 text-slate-700 rounded-xl text-[10.5px] font-bold transition">
                          <Upload className="w-3.5 h-3.5 text-slate-500" />
                          <span>{docItem.fileName ? "تغيير الملف المرفوع" : "اختيار ورفع ملف وثيقة"}</span>
                          <input
                            type="file"
                            accept="image/*,application/pdf"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                docItem.fileSetter(file.name);
                                docItem.setter(true);
                              }
                            }}
                          />
                        </label>
                      </div>

                      {docItem.fileName && (
                        <div className="text-[10px] text-emerald-600 bg-emerald-100/40 px-2 py-1 rounded-md flex items-center gap-1 font-mono justify-end">
                          <span className="truncate max-w-[150px]">{docItem.fileName}</span>
                          <span className="font-bold">✓ تم الرفع</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Original Document Verification Warning Note */}
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-2.5 text-right mt-4 animate-fade-in shadow-sm">
                  <ShieldAlert className="w-5 h-5 shrink-0 text-amber-600 font-bold" />
                  <div className="space-y-1">
                    <h4 className="font-extrabold text-xs text-amber-900 leading-tight">⚠️ ملاحظة هامة جداً بشأن مطابقة المستندات والوثائق</h4>
                    <p className="text-[11px] text-amber-800 font-semibold leading-relaxed">
                      يجب إحضار أصول كافة المستندات والوثائق والشهادات الرسمية كاملة إلى إدارة المدرسة لمطابقتها عملياً والتأكد من صحتها مع الصور أو الوثائق التي يتم إرسالها إلكترونياً، وذلك عند الحضور للمقابلة الشخصية المباشرة واستكمال إجراءات القبول المعتمدة.
                    </p>
                  </div>
                </div>
              </div>

              {errorLines && (
                <p className="text-xs text-rose-600 font-bold bg-rose-50 p-3 rounded-lg border border-rose-150">
                  {errorLines}
                </p>
              )}

              {/* Form Submission action button */}
              <div className="pt-4 flex justify-end">
                <button
                  id="btn-submit-registration-form"
                  type="submit"
                  className="bg-primary hover:bg-slate-800 text-white font-bold px-8 py-3.5 rounded-xl text-sm transition duration-150 flex items-center gap-2 shadow-lg shadow-primary/10"
                >
                  <Send className="w-4 h-4" />
                  <span>إرسال طلب التسجيل الرقمي وإخطار الإدارة</span>
                </button>
              </div>

            </form>
          </div>

        </div>
      )}

    </div>
  );
}
