import React, { useState, useEffect } from "react";
import JSZip from "jszip";
import Home from "./components/Home";
import About from "./components/About";
import AcademicPhases from "./components/AcademicPhases";
import NewsSection from "./components/NewsSection";
import ResultsPortal from "./components/ResultsPortal";
import RegistrationForm from "./components/RegistrationForm";
import MediaGallery from "./components/MediaGallery";
import ContactUs from "./components/ContactUs";
import StudentPortal from "./components/StudentPortal";
import ParentPortal from "./components/ParentPortal";
import FeesDashboard from "./components/FeesDashboard";
import TeacherPortal from "./components/TeacherPortal";
import AdminDashboard from "./components/AdminDashboard";
import SchoolLogo from "./components/SchoolLogo";

import { initializeSchoolStorage, fetchAndSyncAllSchoolData, saveDataWithServerSync } from "./data";
import { 
  Building2, 
  BookOpen, 
  MessageSquare, 
  Award, 
  User, 
  Users, 
  Settings, 
  Briefcase, 
  MapPin, 
  Phone, 
  GraduationCap, 
  Menu, 
  X,
  Compass,
  FileText,
  Images,
  ChevronDown,
  CreditCard
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("home");
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [selectedPhaseExplore, setSelectedPhaseExplore] = useState<string>("elementary");
  const [portalsDropdownOpen, setPortalsDropdownOpen] = useState<boolean>(false);

  // Developer Portal states (ALRASSASS Badge actions)
  const [showDevPortal, setShowDevPortal] = useState<boolean>(false);
  const [isDevAuthenticated, setIsDevAuthenticated] = useState<boolean>(false);
  const [devInputPass, setDevInputPass] = useState<string>("");
  const [devError, setDevError] = useState<string>("");
  const [devSuccessMsg, setDevSuccessMsg] = useState<string>("");

  const handleDevLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (devInputPass === "64a93s" || devInputPass === "alrassass") {
      setIsDevAuthenticated(true);
      setDevError("");
      setDevSuccessMsg("✓ تم فك تشفير وتأكيد اتصال المطور بنجاح.");
    } else {
      setDevError("❌ رمز التحقق غير صحيح، برجاء إدخال الكود المخصص للمطور.");
    }
  };

  const handleDownloadFullBackup = async () => {
    try {
      setDevSuccessMsg("جاري ضغط وتوليد ملف كود المشروع والمصادر وقواعد البيانات بالكامل سحابياً... الرجاء الانتظار.");
      
      const response = await fetch("/api/export-full-project-zip");
      if (!response.ok) {
        throw new Error("فشل توليد وضغط ملفات المشروع من الخادم.");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement("a");
      a.href = url;
      a.download = "amlf_school_project_full_source.zip";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setDevSuccessMsg("✓ تم توليد وتجميع كافة ملفات المشروع الأكاديمي، وقواعد البيانات وشاشات الواجهة والتهيئة بنجاح داخل أرشيف مضغوط (.ZIP) جاهز للاستضافة!");
    } catch (err) {
      console.error(err);
      alert("فشل تحميل وتحديث النسخة الاحتياطية المصدرية الشاملة.");
    }
  };

  const handleUploadBackupFileAndSync = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (!json || typeof json !== "object") {
          throw new Error("تنسيق الملف غير صالح.");
        }

        // Apply backup keys
        Object.keys(json).forEach(k => {
          localStorage.setItem(k, JSON.stringify(json[k]));
          // Sync with server as well!
          saveDataWithServerSync(k, json[k]);
        });

        setDevSuccessMsg("✓ تم استيراد ومزامنة كافة البيانات بالاستضافة الخارجية وتلقيمها للملفات آلياً!");
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } catch (err) {
        alert("فشل في استيراد الملف، تأكد من صحة البنية وتنسيق JSON.");
      }
    };
    reader.readAsText(file);
  };

  const handlePushAllDataToServerSync = async (): Promise<boolean> => {
    try {
      const schoolDB: Record<string, any> = {};
      const keyMappingKeys: Record<string, string> = {
        "school_news": "news",
        "school_announcements": "announcements",
        "school_gallery": "gallery",
        "school_students": "students",
        "school_parents": "parents",
        "school_teachers": "teachers",
        "school_registration_requests": "registrationRequests",
        "school_bus_routes_v2": "busRoutes",
        "school_grade_fees_templates_v2": "feesTemplates",
        "school_daily_homeworks": "dailyHomeworks"
      };

      Object.entries(keyMappingKeys).forEach(([localKey, serverKey]) => {
        const item = localStorage.getItem(localKey);
        if (item) {
          try {
            schoolDB[serverKey] = JSON.parse(item);
          } catch {
            schoolDB[serverKey] = item;
          }
        }
      });

      // Synchronize key tables to high-speed hosting json
      const schoolRes = await fetch("/api/school-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(schoolDB)
      });
      if (!schoolRes.ok) throw new Error("فشل مزامنة قاعدة البيانات الرئيسية");

      // Synchronize results table
      const resultsItem = localStorage.getItem("results_database");
      if (resultsItem) {
        let resultsData;
        try {
          resultsData = JSON.parse(resultsItem);
        } catch {
          resultsData = resultsItem;
        }

        const resRes = await fetch("/api/results", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(resultsData)
        });
        if (!resRes.ok) throw new Error("فشل مزامنة قاعدة بيانات النتائج");
      }

      // Re-fetch locally to ensure alignment
      await fetchAndSyncAllSchoolData();
      return true;
    } catch (err) {
      console.error("Cloud developer synchronization failed:", err);
      return false;
    }
  };

  // Initialize storage on first render
  useEffect(() => {
    initializeSchoolStorage();
    fetchAndSyncAllSchoolData();
  }, []);

  const handleNavigate = (tab: string) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleExplorePhase = (phase: string) => {
    setSelectedPhaseExplore(phase);
    handleNavigate("phases");
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-slate-50/50 text-slate-900">
      
      {/* 1. Header & Navigation Panel */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            
            {/* School Logo Concept */}
            <div 
              onClick={() => handleNavigate("home")} 
              className="flex items-center gap-3 cursor-pointer select-none"
            >
              <SchoolLogo className="w-12 h-12" />
              <div className="text-right">
                <h1 className="text-md font-black text-slate-900 font-display tracking-tight">مدرسة أمل المستقبل</h1>
                <p className="text-[10px] text-accent font-bold">الأهلية والمتميزة دائماً</p>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden xl:flex items-center gap-1 text-xs font-bold leading-none">
              {[
                { id: "home", label: "الرئيسية", icon: Building2 },
                { id: "about", label: "عن المدرسة", icon: Compass },
                { id: "phases", label: "المراحل التعليمية", icon: BookOpen },
                { id: "news", label: "الأخبار والفعاليات", icon: FileText },
                { id: "gallery", label: "معرض اللقطات", icon: Images },
                { id: "results", label: "بوابة النتائج", icon: Award },
                { id: "register", label: "التسجيل الإلكتروني", icon: GraduationCap },
                { id: "contact", label: "تواصل معنا", icon: Phone }
              ].map((item) => (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => handleNavigate(item.id)}
                  className={`px-4.5 py-3.5 rounded-xl transition duration-150 flex items-center gap-1.5 ${
                    activeTab === item.id || (item.id === "phases" && activeTab === "phases")
                      ? "bg-primary text-white shadow-sm"
                      : "text-slate-600 hover:text-primary hover:bg-slate-50"
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>

            {/* Unified Dropdown Menu for all online portals to avoid menu crowding (Desktop only) */}
            <div 
              className="hidden lg:relative lg:block"
              onMouseLeave={() => setPortalsDropdownOpen(false)}
            >
              <button
                id="portals-dropdown-trigger"
                onClick={() => setPortalsDropdownOpen(!portalsDropdownOpen)}
                onMouseEnter={() => setPortalsDropdownOpen(true)}
                className={`px-4.5 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border select-none cursor-pointer ${
                  ["student-portal", "parent-portal", "fees-dashboard", "teacher-portal", "admin-dashboard"].includes(activeTab)
                    ? "bg-slate-900 text-white border-slate-900 shadow-sm"
                    : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                }`}
              >
                <span>منصات الخدمات الإلكترونية</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-250 ${portalsDropdownOpen ? "rotate-180" : ""}`} />
              </button>

              {portalsDropdownOpen && (
                <div className="absolute left-0 mt-2 w-72 bg-white rounded-2xl border border-slate-100 shadow-xl overflow-hidden py-2.5 z-50 text-right animate-fade-in text-slate-900">
                  <p className="text-[10px] text-slate-400 font-extrabold px-4 pb-1.5 pt-1 border-b border-slate-50">اختر المنصة للولوج الآمن لخدماتنا:</p>
                  
                  {[
                    { id: "student-portal", label: "منصة الطالب الذكية", desc: "الواجبات اليومية، كشف العلامات، الغياب والجدول الرسمي", icon: User, color: "text-blue-600" },
                    { id: "parent-portal", label: "بوابة ولي أمر الطالب", desc: "كشف كشوفات الطلاب ومتابعة المواد والتواصل المباشر", icon: Users, color: "text-indigo-600" },
                    { id: "fees-dashboard", label: "لوحة متابعة الرسوم وحجوزات الباص المدرسي", desc: "سداد الأقساط، كشف الرسوم المدرسية وحجوزات حافلات النقل", icon: CreditCard, color: "text-emerald-600" },
                    { id: "teacher-portal", label: "لوحة المعلم والكوادر", desc: "رصد العلامات، وضع الواجبات القادمة، إدارة تحضير الغياب", icon: Briefcase, color: "text-sky-600" },
                    { id: "admin-dashboard", label: "منصة الإشراف والتحكم المالي", desc: "اعتماد كشف القوائم، إدارة الطلاب والمدرسين والقرارات المعتمدة", icon: Settings, color: "text-rose-600" }
                  ].map((port) => (
                    <button
                      key={port.id}
                      onClick={() => {
                        handleNavigate(port.id);
                        setPortalsDropdownOpen(false);
                      }}
                      className={`w-full px-4 py-2.5 flex items-start gap-3 transition-colors text-right border-l-4 ${
                        activeTab === port.id 
                          ? "bg-slate-50 border-primary" 
                          : "border-transparent hover:bg-slate-50"
                      }`}
                    >
                      <div className={`p-1.5 bg-slate-100 rounded-lg mt-0.5 shrink-0 ${port.color}`}>
                        <port.icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-extrabold text-slate-900 text-xs">{port.label}</p>
                        <p className="text-[9.5px] text-slate-400 truncate">{port.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Mobile menu hamburger icon */}
            <div className="xl:hidden flex items-center gap-2">
              <button
                onClick={() => handleNavigate("admin-dashboard")}
                className="p-2 rounded-lg bg-slate-50 text-slate-500 border border-slate-200"
              >
                <Settings className="w-4 h-4" />
              </button>
              
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2.5 bg-slate-100/80 hover:bg-slate-150 rounded-xl text-slate-700 transition"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>

          </div>
        </div>

        {/* 2. Responsive Mobile Drawer navigation items */}
        {mobileMenuOpen && (
          <div className="xl:hidden border-t border-slate-100 bg-white shadow-xl px-4 py-6 space-y-4 animate-slide-down">
            <div className="grid grid-cols-2 gap-3">
              {[
                { id: "home", label: "الرئيسية", icon: Building2 },
                { id: "about", label: "عن المدرسة", icon: Compass },
                { id: "phases", label: "المراحل التعليمية", icon: BookOpen },
                { id: "news", label: "الأخبار", icon: FileText },
                { id: "gallery", label: "معرض الصور", icon: Images },
                { id: "results", label: "النتائج", icon: Award },
                { id: "register", label: "التسجيل الرقمي", icon: GraduationCap },
                { id: "contact", label: "تواصل معنا", icon: Phone }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavigate(item.id)}
                  className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2 justify-center border ${
                    activeTab === item.id
                      ? "bg-primary text-white border-primary shadow"
                      : "bg-slate-50 text-slate-700 border-slate-100"
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

             {/* Quick Portals inside mobile view drawer */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <p className="text-[10px] text-slate-400 font-bold text-right px-1">المنصات التعليمية والإدارية:</p>
              
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleNavigate("student-portal")}
                  className={`py-3 rounded-lg text-xs font-bold text-center border ${
                    activeTab === "student-portal" ? "bg-slate-900 text-white border-transparent" : "bg-white text-slate-700 border-slate-250"
                  }`}
                >
                  منصة الطالب
                </button>
                <button
                  onClick={() => handleNavigate("parent-portal")}
                  className={`py-3 rounded-lg text-xs font-bold text-center border ${
                    activeTab === "parent-portal" ? "bg-slate-900 text-white border-transparent" : "bg-white text-slate-700 border-slate-250"
                  }`}
                >
                  بوابة ولي الأمر
                </button>
                <button
                  onClick={() => handleNavigate("fees-dashboard")}
                  className={`py-3 rounded-lg text-xs font-bold text-center border col-span-2 ${
                    activeTab === "fees-dashboard" ? "bg-slate-900 text-white border-transparent" : "bg-white text-slate-700 border-slate-250"
                  }`}
                >
                  🚌 متابعة الرسوم وحجوزات الباص
                </button>
                <button
                  onClick={() => handleNavigate("teacher-portal")}
                  className={`py-3 rounded-lg text-xs font-bold text-center border ${
                    activeTab === "teacher-portal" ? "bg-slate-900 text-white border-transparent" : "bg-white text-slate-700 border-slate-250"
                  }`}
                >
                  لوحة المعلم
                </button>
                <button
                  onClick={() => handleNavigate("admin-dashboard")}
                  className={`py-3 rounded-lg text-xs font-bold text-center border ${
                    activeTab === "admin-dashboard" ? "bg-slate-900 text-white border-transparent" : "bg-white text-slate-700 border-slate-250"
                  }`}
                >
                  لوحة الإشراف
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* 3. Primary Core Canvas Content container */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {activeTab === "home" && (
          <Home 
            onNavigate={handleNavigate} 
            onExplorePhase={handleExplorePhase} 
            isDevAuthenticated={isDevAuthenticated}
            setIsDevAuthenticated={setIsDevAuthenticated}
            handleDownloadFullBackup={handleDownloadFullBackup}
            handleUploadBackupFileAndSync={handleUploadBackupFileAndSync}
            handlePushAllDataToServerSync={handlePushAllDataToServerSync}
          />
        )}
        {activeTab === "about" && <About />}
        {activeTab === "phases" && <AcademicPhases initialPhase={selectedPhaseExplore} />}
        {activeTab === "news" && <NewsSection />}
        {activeTab === "gallery" && <MediaGallery />}
        {activeTab === "results" && <ResultsPortal />}
        {activeTab === "register" && <RegistrationForm />}
        {activeTab === "contact" && <ContactUs />}
        {activeTab === "student-portal" && <StudentPortal />}
        {activeTab === "parent-portal" && <ParentPortal />}
        {activeTab === "fees-dashboard" && <FeesDashboard />}
        {activeTab === "teacher-portal" && <TeacherPortal />}
        {activeTab === "admin-dashboard" && <AdminDashboard />}
      </main>

      {/* 4. Elegant Persistent Footer in Medical Sky Blue Theme */}
      <footer className="bg-gradient-to-br from-[#0284c7] to-[#0ea5e9] text-white border-t-4 border-[#0369a1] shadow-inner">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-12 gap-8 text-right text-xs">
            
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center gap-3 justify-start">
                <SchoolLogo className="w-11 h-11 bg-white/20 p-1.5 rounded-2xl shadow-sm" />
                <h3 className="text-lg font-extrabold text-white font-display">مدرسة أمل المستقبل الأهلية</h3>
              </div>
              <p className="text-white/95 leading-relaxed text-xs">
                منظومة تربوية متكاملة تجمع بين الأصالة والتقنيات الذكية. نُعِد أجيال الغد بشغف الريادة والتفوق المعرفي والأخلاقي لبناء غدٍ تفخرون به جميعاً.
              </p>
            </div>

            <div className="md:col-span-3 space-y-3">
              <h4 className="font-bold text-white text-sm pb-1 border-b border-white/20">البوابات الذكية السريعة</h4>
              <ul className="space-y-2.5 text-white/95 text-xs">
                <li><button onClick={() => handleNavigate("student-portal")} className="hover:text-yellow-200 hover:underline font-extrabold transition text-right">بوابة منصة الطالب</button></li>
                <li><button onClick={() => handleNavigate("parent-portal")} className="hover:text-yellow-200 hover:underline font-extrabold transition text-right">منصة ولي الأمر الحصرية</button></li>
                <li><button onClick={() => handleNavigate("teacher-portal")} className="hover:text-yellow-200 hover:underline font-extrabold transition text-right">لوحة المعلمين والكوادر</button></li>
                <li><button onClick={() => handleNavigate("admin-dashboard")} className="hover:text-yellow-200 hover:underline font-extrabold transition text-right">لوحة التحكم الإدارية</button></li>
                <li><button onClick={() => handleNavigate("contact")} className="hover:text-yellow-200 hover:underline font-extrabold transition text-right">مقر الإدارة والتواصل</button></li>
              </ul>
            </div>

            <div className="md:col-span-4 space-y-3">
              <h4 className="font-bold text-white text-sm pb-1 border-b border-white/20">مقر الإدارة والتواصل</h4>
              <ul className="space-y-2.5 text-white/95 leading-relaxed text-xs">
                <li className="flex items-center gap-2 justify-start"><MapPin className="w-4 h-4 text-yellow-300 shrink-0" /> <span className="font-bold">اليمن، الحديدة، باجل</span></li>
                <li className="flex items-center gap-2 justify-start"><Phone className="w-4 h-4 text-yellow-300 shrink-0" /> <span className="font-mono font-bold">الهاتف: 783711148 (967+)</span></li>
                <li className="flex items-center gap-2 justify-start"><MessageSquare className="w-4 h-4 text-yellow-300 shrink-0" /> <span className="font-mono font-bold">الواتس آب: 783711148 (967+)</span></li>
              </ul>
            </div>

          </div>

          <div className="border-t border-white/20 mt-12 pt-6 text-[11px] text-white/95 flex flex-col items-center justify-center gap-4 font-bold text-center">
            <p className="text-sm">مدرسة أمل المستقبل الأهلية © للعام الدراسي 2026-2027. كافة الحقوق محفوظة ومحمية بإشراف وزارة التعليم.</p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-1">
              <span className="bg-white/10 px-4 py-2 rounded-2xl text-white shadow-sm flex items-center gap-1.5">
                منصة إدارة ذكية متكاملة 🤖✨
              </span>
              
              {/* ALRASSASS Badge with Spinning Glowing Blogger Icon */}
              <a 
                href="https://wa.me/967774632249" 
                target="_blank" 
                rel="noopener noreferrer" 
                onDoubleClick={(e) => {
                  e.preventDefault();
                  setShowDevPortal(true);
                }}
                title="اضغط مرتين لفتح بوابة المطورين المعتمدة 💻"
                className="inline-flex items-center gap-2 bg-white text-slate-900 hover:bg-slate-100 border border-slate-200 shadow-md transition-all duration-350 transform hover:scale-105 active:scale-95 px-3.5 py-1.5 rounded-full text-[11px] font-black cursor-pointer select-none"
              >
                <img 
                  src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgRo4g4_W6PymhtlOvN5CxBqz6yChzUFfKcwx8ahexjk7Kyo6_1FZ3yKilegJEPLEmZO788AGdgcKCrQ5AkLbvMIRP72TT6BLMpjx731qmJAvEqPitsmRJdd1pmcFOkPLucbK6oO_vpKCXaHcb7pLh3l7zDeNh4MrnkvSDxofb5Rz5lT2E6Q42pFfHBtg/s320/1746267577250.jpg" 
                  alt="ALRASSASS" 
                  className="w-5 h-5 rounded-full object-cover animate-spin-slow animate-glow-pulse border border-emerald-400"
                  referrerPolicy="no-referrer"
                />
                <span className="text-slate-800">تصميم ALRASSASS</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
              </a>
            </div>
          </div>
        </div>
      </footer>

      {showDevPortal && (
        <div className="fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in text-right" dir="rtl">
          <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-md p-6 relative shadow-2xl space-y-6">
            <button
              onClick={() => {
                setShowDevPortal(false);
                setIsDevAuthenticated(false);
                setDevInputPass("");
                setDevError("");
                setDevSuccessMsg("");
              }}
              className="absolute left-4 top-4 text-slate-400 hover:text-slate-600 font-extrabold text-sm"
            >
              ✕
            </button>

            <div className="text-center space-y-1 border-b border-slate-100 pb-4">
              <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-3 py-1 rounded-full">بوابة كبار المطورين المعتمدين 💻🔒</span>
              <h3 className="font-extrabold text-slate-900 font-display mt-2 text-sm">نظام ALRASSASS السحابي المطور</h3>
              <p className="text-[10px] text-slate-400">لوحة المطور الخاصة لتحديث قاعدة البيانات وتنزيل ملفات الربط والنسخ الاحتياطي</p>
            </div>

            {devSuccessMsg && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-850 p-3 rounded-xl text-[10px] text-center font-bold">
                {devSuccessMsg}
              </div>
            )}

            {!isDevAuthenticated ? (
              <form onSubmit={handleDevLogin} className="space-y-4 text-right">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-600 block font-bold text-right">يرجى توفير كود فك التشفير الأمني للمطور (مثال 64a93s):</label>
                  <input
                    type="password"
                    required
                    value={devInputPass}
                    onChange={(e) => setDevInputPass(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-205 rounded-xl text-center text-sm font-mono tracking-widest focus:outline-none focus:border-indigo-400"
                    placeholder="••••••••"
                  />
                </div>

                {devError && (
                  <p className="text-[10px] text-rose-600 bg-rose-50 p-2.5 rounded-lg text-center font-bold">{devError}</p>
                )}

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-black py-2.5 rounded-xl text-xs transition"
                >
                  التحقق من صلاحية المطور 🛡️
                </button>
              </form>
            ) : (
              <div className="space-y-6 text-right">
                
                {/* Barcode representation carrying: http://amlf-ye.com */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-3 text-center">
                  <span className="text-[10px] font-black text-indigo-700 block">📲 باركود التحميل السريع (QR Code): http://amlf-ye.com</span>
                  
                  {/* Styled SVG QR Code vector representation of http://amlf-ye.com */}
                  <svg className="w-32 h-32 bg-white p-2 border border-slate-200 rounded-lg shadow-sm" viewBox="0 0 100 100">
                    <rect x="5" y="5" width="25" height="25" fill="black" />
                    <rect x="8" y="8" width="19" height="19" fill="white" />
                    <rect x="11" y="11" width="13" height="13" fill="black" />

                    <rect x="70" y="5" width="25" height="25" fill="black" />
                    <rect x="73" y="8" width="19" height="19" fill="white" />
                    <rect x="76" y="11" width="13" height="13" fill="black" />

                    <rect x="5" y="70" width="25" height="25" fill="black" />
                    <rect x="8" y="73" width="19" height="19" fill="white" />
                    <rect x="11" y="76" width="13" height="13" fill="black" />

                    <rect x="35" y="10" width="5" height="10" fill="black" />
                    <rect x="45" y="5" width="10" height="5" fill="black" />
                    <rect x="60" y="20" width="5" height="5" fill="black" />
                    <rect x="40" y="25" width="15" height="5" fill="black" />

                    <rect x="5" y="35" width="10" height="5" fill="black" />
                    <rect x="25" y="40" width="15" height="10" fill="black" />
                    <rect x="45" y="35" width="5" height="15" fill="black" />
                    <rect x="55" y="45" width="10" height="5" fill="black" />
                    <rect x="75" y="35" width="20" height="5" fill="black" />
                    <rect x="85" y="45" width="5" height="15" fill="black" />

                    <rect x="35" y="60" width="15" height="10" fill="black" />
                    <rect x="55" y="55" width="5" height="20" fill="black" />
                    <rect x="65" y="70" width="15" height="5" fill="black" />
                    <rect x="45" y="80" width="15" height="15" fill="black" />
                    <rect x="75" y="85" width="20" height="10" fill="black" />
                    
                    <rect x="45" y="45" width="10" height="10" fill="#4f46e5" />
                  </svg>
                  
                  <a 
                    href="http://amlf-ye.com" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-[10px] text-slate-500 hover:text-indigo-600 underline font-mono"
                  >
                    http://amlf-ye.com
                  </a>
                </div>

                {/* Developer Program Download button */}
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <h4 className="text-[11px] font-bold text-slate-800">📥 تحميل البرنامج والمحتوى الكامل:</h4>
                  <button
                    onClick={handleDownloadFullBackup}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-2.5 px-4 rounded-xl text-xs transition duration-200 flex items-center justify-center gap-2"
                  >
                    <span>تحميل قاعدة البيانات الكاملة (JSON) 📥</span>
                  </button>
                  <p className="text-[9px] text-slate-400 leading-relaxed">
                    يتيح لك هذا الزر تحميل كامل شيتات البيانات المدرسية وقاعدة بيانات الطلاب بملف احتياطي مشفر تمهيداً لرفعه على استضافتكم الخاصة.
                  </p>
                </div>

                {/* Platform Sync Database and update button */}
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <h4 className="text-[11px] font-bold text-slate-800">🔄 تحديث ومزامنة المنصة بالاستضافة الخارجية:</h4>
                  <label className="w-full bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 text-indigo-800 cursor-pointer font-extrabold py-2.5 px-4 rounded-xl text-xs transition duration-200 flex items-center justify-center gap-2">
                    <span>رفع وتحديث البيانات سحابياً 🔄</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleUploadBackupFileAndSync}
                      className="hidden"
                    />
                  </label>
                  <p className="text-[9px] text-slate-400 leading-relaxed">
                    تقوم هذه الميزة بالارتباط التلقائي وتغذية كافة التعديلات، الأخبار والسجلات من الاستضافة بالملف الخارجي المرفوع لتحديث المنصة بالكامل دفعة واحدة آلياً.
                  </p>
                </div>

              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
