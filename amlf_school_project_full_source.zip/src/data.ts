import { Student, Parent, Teacher, RegistrationRequest, SchoolNews, GalleryItem, Announcement } from "./types";

// Initial datasets to populate localStorage on first visit

export const initialNews: SchoolNews[] = [
  {
    id: "news-1",
    title: "حفل تكريم الطلبة المتفوقين للفصل الدراسي الأول",
    content: "كرمت إدارة مدرسة أمل المستقبل الأهلية كوكبة من طالباتها وطلابها المتفوقين في الحفل السنوي البهيج بحضور السادة أولياء الأمور وأعضاء الكادر الإداري والتعليمي تمنياتنا لهم بدوام التميز والنجاح.",
    date: "2026-05-15",
    category: "إنجاز",
    imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "news-2",
    title: "بدء التسجيل الإلكتروني للعام الدراسي الجديد 2026-2027",
    content: "تعلن إدارة مدرسة أمل المستقبل الأهلية عن فتح باب القبول والتسجيل للعام الدراسي الجديد لكافة المراحل التعليمية (رياض الأطفال، الابتدائي، الإعدادي، الثانوي). يرجى تقديم الطلبات إلكترونياً عبر البوابة الرسمية.",
    date: "2026-05-10",
    category: "إعلان",
    imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "news-3",
    title: "الرحلة المدرسية العلمية إلى معرض العلوم والاستكشاف",
    content: "نظمت المدرسة رحلة استكشافية لطلاب المرحلة المتوسطة والإعدادية إلى مختبرات العلوم والتكنولوجيا بهدف ترسيخ المفاهيم المنهجية عملياً وتوليد شغف الابتكار والبحث العلمي لدى طلابنا.",
    date: "2026-04-28",
    category: "رحلة",
    imageUrl: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "news-4",
    title: "حصول المدرسة على درع التميز في الأنشطة الرياضية والفيزيائية",
    content: "توج فريق المدرسة الرياضي بالمركز الأول في البطولة السنوية المفتوحة لكرة السلة والعدو الطويل على مستوى مدارس المنطقة. فخورون بأبطال المستقبل كادر تدريبياً ولاعبين.",
    date: "2026-04-18",
    category: "إنجاز",
    imageUrl: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=600"
  }
];

export const initialAnnouncements: Announcement[] = [
  {
    id: "ann-1",
    title: "تنبيه هام بشأن موعد انعقاد مجالس أولياء الأمور الدورية",
    content: "ندعو السادة أولياء أمور طلاب المرحلة الابتدائية والتمهيدي لحضور اللقاء المشترك يوم الأحد القادم لمتابعة المستويات الأكاديمية والخطط التقييمية.",
    target: "parents",
    date: "2026-05-19"
  },
  {
    id: "ann-2",
    title: "اعتماد التقويم النهائي للاختبارات النهائية وتعميم الإجراءات",
    content: "إلى كافة الكوادر التعليمية والطلاب، تم رفع جداول الاختبارات التفصيلية على صفحة النتائج والجداول. نرجو الحرص والالتزام بالوقت والمراجعة.",
    target: "all",
    date: "2026-05-18"
  },
  {
    id: "ann-3",
    title: "ورشة عمل تطوير مهارات استخدام منصة التعليم الذكية للمعلمين",
    content: "تعلن إدارة التدريب والتعليم المستمر عن عقد ورشة تفاعلية غداً في تمام الساعة الواحدة ظهراً لمناقشة تفعيل ميزات الذكاء الاصطناعي وكيفية رصد الواجبات والدرجات.",
    target: "teachers",
    date: "2026-05-16"
  }
];

export const initialGallery: GalleryItem[] = [
  {
    id: "g-1",
    title: "معمل الكيمياء والأحياء الحديث لطلاب الثانوي",
    category: "مرافق",
    imageUrl: "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "g-2",
    title: "المسرح المدرسي الكبير وحفل تخريج رواد المستقبل",
    category: "حفلات",
    imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "g-3",
    title: "حصص النشاط التفاعلي لطلاب الروضة والتمهيدي",
    category: "أنشطة",
    imageUrl: "https://images.unsplash.com/photo-1576267423445-b2e0074d68a4?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "g-4",
    title: "المكتبة المركزية الشاملة - واحة القراءة والاطلاع",
    category: "مرافق",
    imageUrl: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "g-5",
    title: "فصول نموذجية متكاملة بأحدث الشاشات الذكية",
    category: "فصول",
    imageUrl: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "g-6",
    title: "المعرض الفني السنوي لرسومات وأعمال طلابنا اليدوية",
    category: "أنشطة",
    imageUrl: "https://images.unsplash.com/photo-1460518451285-97b6ba32ee61?auto=format&fit=crop&q=80&w=600"
  }
];

// default Mock Students
export const initialStudents: Student[] = [
  {
    id: "101",
    name: "عمر أحمد اليوسف",
    grade: "الصف السادس الابتدائي",
    level: "elementary",
    attendance: {
      present: 42,
      absent: 2,
      excused: 1,
      history: [
        { date: "2026-05-19", status: "حاضر" },
        { date: "2026-05-18", status: "حاضر" },
        { date: "2026-05-17", status: "غائب" },
        { date: "2026-05-16", status: "حاضر" },
        { date: "2026-05-15", status: "حاضر" }
      ]
    },
    grades: [
      { subject: "اللغة العربية", midterm: 19, final: 76, homework: 5, total: 100, grade: "ممتاز (A+)" },
      { subject: "الرياضيات", midterm: 18, final: 72, homework: 4, total: 94, grade: "ممتاز (A)" },
      { subject: "العلوم العامة", midterm: 17, final: 70, homework: 5, total: 92, grade: "ممتاز (A)" },
      { subject: "اللغة الإنجليزية", midterm: 15, final: 68, homework: 4, total: 87, grade: "جيد جداً (B+)" }
    ],
    assignments: [
      { id: "as-1", subject: "الرياضيات", title: "حل مسألة المتتاليات ونظرية المجموعات ص32", dueDate: "2026-05-24", status: "pending" },
      { id: "as-2", subject: "اللغة العربية", title: "موضوع تعبير عن الكرم ومكارم الأخلاق في العصر الجاهلي", dueDate: "2026-05-21", status: "submitted" },
      { id: "as-3", subject: "العلوم العامة", title: "رسم مبسط لتركيب الخلايا النباتية والحيوانية", dueDate: "2026-05-18", status: "graded", grade: "10/10", feedback: "رسم غاية في الدقة وتوزيع ألوان رائع" }
    ],
    parentId: "parent-1"
  },
  {
    id: "102",
    name: "سارة محمد الكردي",
    grade: "الصف الثالث الإعدادي",
    level: "prep",
    attendance: {
      present: 44,
      absent: 1,
      excused: 0,
      history: [
        { date: "2026-05-19", status: "حاضر" },
        { date: "2026-05-18", status: "حاضر" },
        { date: "2026-05-17", status: "حاضر" },
        { date: "2026-05-16", status: "حاضر" },
        { date: "2026-05-15", status: "حاضر" }
      ]
    },
    grades: [
      { subject: "اللغة العربية", midterm: 20, final: 78, homework: 5, total: 103, grade: "ممتاز (A+)" },
      { subject: "الرياضيات", midterm: 19, final: 77, homework: 5, total: 101, grade: "ممتاز (A+)" },
      { subject: "الفيزياء والكمياء", midterm: 18, final: 73, homework: 5, total: 96, grade: "ممتاز (A)" },
      { subject: "اللغة الإنجليزية", midterm: 20, final: 75, homework: 5, total: 100, grade: "ممتاز (A+)" }
    ],
    assignments: [
      { id: "as-4", subject: "الفيزياء والكمياء", title: "تقرير مصور عن تجارب التفاعلات الطاردة للحرارة", dueDate: "2026-05-25", status: "pending" },
      { id: "as-5", subject: "الرياضيات", title: "حل مسائل حساب المثلثات الإضافية", dueDate: "2026-05-22", status: "pending" },
      { id: "as-6", subject: "اللغة العربية", title: "إعراب قصيدة لغة الضاد كاملة وبشرح الأبيات", dueDate: "2026-05-17", status: "graded", grade: "15/15", feedback: "أحسنتِ النحو المتميز أداءً رائعاً" }
    ],
    parentId: "parent-2"
  },
  {
    id: "103",
    name: "يوسف محمد الكردي",
    grade: "الصف الأول الابتدائي",
    level: "elementary",
    attendance: {
      present: 40,
      absent: 4,
      excused: 1,
      history: [
        { date: "2026-05-19", status: "حاضر" },
        { date: "2026-05-18", status: "غائب" },
        { date: "2026-05-17", status: "حاضر" },
        { date: "2026-05-16", status: "حاضر" },
        { date: "2026-05-15", status: "حاضر" }
      ]
    },
    grades: [
      { subject: "اللغة العربية", midterm: 15, final: 65, homework: 5, total: 85, grade: "جيد جداً (B)" },
      { subject: "الرياضيات والعد", midterm: 16, final: 70, homework: 4, total: 90, grade: "ممتاز (A)" },
      { subject: "دروس الاستكشاف ورسم", midterm: 18, final: 75, homework: 5, total: 98, grade: "ممتاز (A+)" }
    ],
    assignments: [
      { id: "as-7", subject: "اللغة العربية", title: "كتابة الحروف من الألف إلى الياء مكررة مرتين بخط جميل", dueDate: "2026-05-23", status: "pending" }
    ],
    parentId: "parent-2"
  }
];

// Parents Mock Data
export const initialParents: Parent[] = [
  {
    id: "parent-1",
    name: "أحمد عمر اليوسف",
    phone: "783711148",
    email: "ahmed@example.com",
    students: ["101"],
    financials: {
      totalFees: 12000,
      paidFees: 8000,
      remainingFees: 4000,
      transactions: [
        { id: "tx-1", amount: 4000, date: "2026-05-01", title: "رسوم القسط الثاني - الفصل الدراسي الثاني", status: "مقبول" },
        { id: "tx-2", amount: 4000, date: "2026-01-10", title: "رسوم تقسيط الكتب وتوصيل الحافلة المدرسية", status: "مقبول" }
      ]
    }
  },
  {
    id: "parent-2",
    name: "محمد الكردي",
    phone: "711114173",
    email: "kurdi@example.com",
    students: ["102", "103"],
    financials: {
      totalFees: 24000,
      paidFees: 15000,
      remainingFees: 9000,
      transactions: [
        { id: "tx-3", amount: 10000, date: "2026-04-15", title: "رسوم الفصل الدراسي الثاني كاملة للطالبين سارة ويوسف", status: "مقبول" },
        { id: "tx-4", amount: 5000, date: "2026-05-10", title: "رسوم حافلة وأنشطة ترفيهية سنوية", status: "مقبول" },
        { id: "tx-5", amount: 9000, date: "2026-05-19", title: "طلب تسوية القسط المتبقي للعام", status: "قيد الانتظار" }
      ]
    }
  }
];

// Teachers Mock Data
export const initialTeachers: Teacher[] = [
  {
    id: "teach-101",
    name: "الأستاذ خالد الدوسري",
    subject: "الرياضيات",
    grades: ["الصف السادس الابتدائي", "الصف الثالث الإعدادي"],
    lessons: [
      { id: "l-1", title: "شرح درس المتتاليات العددية البسيطة والكسور", grade: "الصف السادس الابتدائي", date: "2026-05-18", description: "ملف PDF يحتوي على أمثلة توضيحية لتبسيط جمع وطرح الكسور الكبيرة وتطبيقات حياتية." },
      { id: "l-2", title: "مقدمة عامة في حساب المثلثات للشهادة الإعدادية", grade: "الصف الثالث الإعدادي", date: "2026-05-15", description: "شرح شامل للنسب المثلثية الأساسية (جا، جتا، ظا) وقوانين المثلث قائم الزاوية." }
    ],
    assignments: [
      { id: "as-1", title: "حل مسألة المتتاليات ونظرية المجموعات ص32", subject: "الرياضيات", grade: "الصف السادس الابتدائي", dueDate: "2026-05-24", maxDegrees: 10 },
      { id: "as-5", title: "حل مسائل حساب المثلثات الإضافية", subject: "الرياضيات", grade: "الصف الثالث الإعدادي", dueDate: "2026-05-22", maxDegrees: 15 }
    ]
  },
  {
    id: "teach-102",
    name: "الأستاذة ميساء الحلبي",
    subject: "اللغة العربية",
    grades: ["الصف السادس الابتدائي", "الصف الثالث الإعدادي", "الصف الأول الابتدائي"],
    lessons: [
      { id: "l-3", title: "شرح نصب وجزم الأفعال المضارعة وأمثلتها الإعرابية", grade: "الصف السادس الابتدائي", date: "2026-05-17", description: "مذكرة تفاعلية تتضمن تلخيص علامات الإعراب الأصلية والفرعية للأفعال." },
      { id: "l-4", title: "تدريبات الحروف الأبجدية والمد الطويل والقصير", grade: "الصف الأول الابتدائي", date: "2026-05-19", description: "رابط فيديو ترفيهي لمساعدة أطفال الصف الأول على تهجئة الحروف بالتطبيقات العملية." }
    ],
    assignments: [
      { id: "as-2", title: "موضوع تعبير عن الكرم ومكارم الأخلاق في العصر الجاهلي", subject: "اللغة العربية", grade: "الصف السادس الابتدائي", dueDate: "2026-05-21", maxDegrees: 10 },
      { id: "as-7", title: "كتابة الحروف من الألف إلى الياء مكررة مرتين بخط جميل", subject: "اللغة العربية", grade: "الصف الأول الابتدائي", dueDate: "2026-05-23", maxDegrees: 5 }
    ]
  }
];

// Registration Requests Mock Data
export const initialRegistrationRequests: RegistrationRequest[] = [
  {
    id: "reg-1",
    studentName: "رائد سامر العلي",
    parentName: "سامر العلي",
    phone: "711114480",
    email: "samer@example.com",
    grade: "الصف الأول الإعدادي",
    level: "prep",
    birthDate: "2013-04-12",
    documents: {
      idCard: true,
      birthCert: true,
      prevSchoolCert: true
    },
    status: "pending",
    createdAt: "2026-05-15"
  },
  {
    id: "reg-2",
    studentName: "هبة مصطفى زقوت",
    parentName: "مصطفى زقوت",
    phone: "783711148",
    email: "mostafa@example.com",
    grade: "الصف الأول الابتدائي",
    level: "elementary",
    birthDate: "2020-08-05",
    documents: {
      idCard: true,
      birthCert: true,
      prevSchoolCert: false
    },
    status: "approved",
    createdAt: "2026-05-12"
  }
];

// Storage Helpers to keep state continuous
export function getSavedData<T>(key: string, initialData: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (saved) return JSON.parse(saved);
  } catch (error) {
    console.error("Error reading localStorage", error);
  }
  return initialData;
}

export function saveData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error("Error writing localStorage", error);
  }
}

const keyMapping: Record<string, string> = {
  "school_news": "news",
  "school_announcements": "announcements",
  "school_gallery": "gallery",
  "school_students": "students",
  "school_parents": "parents",
  "school_teachers": "teachers",
  "school_registration_requests": "registrationRequests",
  "school_bus_routes_v2": "busRoutes",
  "school_grade_fees_templates_v2": "feesTemplates",
  "school_daily_homeworks": "dailyHomeworks"
};

export function saveDataWithServerSync<T>(key: string, data: T): void {
  saveData(key, data);
  const serverKey = keyMapping[key] || key;
  fetch("/api/school-data", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ key: serverKey, data })
  }).catch(err => console.error("Error syncing with platform server:", err));
}

export async function fetchAndSyncAllSchoolData(): Promise<void> {
  try {
    const res = await fetch("/api/school-data");
    const data = await res.json();
    if (data && typeof data === "object") {
      const reverseMapping: Record<string, string> = {
        news: "school_news",
        announcements: "school_announcements",
        gallery: "school_gallery",
        students: "school_students",
        parents: "school_parents",
        teachers: "school_teachers",
        registrationRequests: "school_registration_requests",
        busRoutes: "school_bus_routes_v2",
        feesTemplates: "school_grade_fees_templates_v2",
        dailyHomeworks: "school_daily_homeworks"
      };
      
      for (const [serverKey, localKey] of Object.entries(reverseMapping)) {
        if (data[serverKey] !== undefined) {
          localStorage.setItem(localKey, JSON.stringify(data[serverKey]));
        }
      }
    }
  } catch (err) {
    console.error("Failed to fetch primary master data from server:", err);
  }
}

// Global data states initializer
export function initializeSchoolStorage() {
  if (!localStorage.getItem("school_news")) saveData("school_news", initialNews);
  if (!localStorage.getItem("school_announcements")) saveData("school_announcements", initialAnnouncements);
  if (!localStorage.getItem("school_gallery")) saveData("school_gallery", initialGallery);
  if (!localStorage.getItem("school_students")) saveData("school_students", initialStudents);
  if (!localStorage.getItem("school_parents")) saveData("school_parents", initialParents);
  if (!localStorage.getItem("school_teachers")) saveData("school_teachers", initialTeachers);
  if (!localStorage.getItem("school_registration_requests")) saveData("school_registration_requests", initialRegistrationRequests);
}
