export interface Student {
  id: string; // academic ID
  name: string;
  grade: string; // e.g. "أول ابتدائي", "ثاني ابتدائي", "ثالث متوسط"
  level: "elementary" | "prep" | "secondary";
  attendance: {
    present: number;
    absent: number;
    excused: number;
    history: { date: string; status: "حاضر" | "غائب" | "إجازة" }[];
  };
  grades: {
    subject: string;
    midterm: number;
    final: number;
    homework: number;
    total: number;
    grade: string; // A, B, C, etc.
  }[];
  assignments: {
    id: string;
    subject: string;
    title: string;
    dueDate: string;
    status: "submitted" | "pending" | "late" | "graded";
    grade?: string;
    feedback?: string;
  }[];
  parentId: string;
}

export interface Parent {
  id: string;
  name: string;
  phone: string;
  email: string;
  students: string[]; // Academic IDs of kids
  financials: {
    totalFees: number;
    paidFees: number;
    remainingFees: number;
    transactions: { id: string; amount: number; date: string; title: string; status: "مقبول" | "قيد الانتظار" }[];
  };
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  grades: string[];
  imageUrl?: string;
  bio?: string;
  role?: string;
  phone?: string;
  email?: string;
  classes?: string[];
  academicId?: string;
  lessons: {
    id: string;
    title: string;
    grade: string;
    date: string;
    fileUrl?: string;
    description: string;
  }[];
  assignments: {
    id: string;
    title: string;
    subject: string;
    grade: string;
    dueDate: string;
    maxDegrees: number;
  }[];
}

export interface RegistrationRequest {
  id: string;
  studentName: string;
  parentName: string;
  phone: string;
  email: string;
  grade: string;
  level: "elementary" | "prep" | "secondary";
  birthDate: string;
  documents: {
    idCard: boolean;
    birthCert: boolean;
    prevSchoolCert: boolean;
  };
  status: "pending" | "approved" | "rejected";
  createdAt: string;
}

export interface SchoolNews {
  id: string;
  title: string;
  content: string;
  date: string;
  category: "أخبار" | "إعلان" | "إنجاز" | "رحلة";
  imageUrl: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  target: "all" | "students" | "teachers" | "parents";
  date: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: "أنشطة" | "حفلات" | "مرافق" | "فصول";
  imageUrl: string;
}
