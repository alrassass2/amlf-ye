import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import JSZip from "jszip";

dotenv.config();

const DEFAULT_RESULTS: Record<string, any[]> = {
  "الصف الأول الأساسي": [
    { "رقم الطالب": "103", "اسم الطالب": "يوسف محمد الكردي", "اللغة العربية": 85, "الرياضيات والعد": 90, "الاستكشاف والرسم": 98, "المجموع": 273, "التقدير العام": "ممتاز" }
  ],
  "الصف الثاني الأساسي": [
    { "رقم الطالب": "201", "اسم الطالب": "خالد وليد العامري", "اللغة العربية": 92, "الرياضيات": 88, "العلوم المبسطة": 90, "المجموع": 270, "التقدير العام": "ممتاز" }
  ],
  "الصف الثالث الأساسي": [
    { "رقم الطالب": "301", "اسم الطالب": "نورة سالم الهاشمي", "اللغة العربية": 95, "الرياضيات": 94, "العلوم": 92, "المجموع": 281, "التقدير العام": "ممتاز مرتفع" }
  ],
  "الصف الرابع الأساسي": [
    { "رقم الطالب": "401", "اسم الطالب": "علي حسن غانم", "اللغة العربية": 78, "الرياضيات": 82, "العلوم": 80, "المجموع": 240, "التقدير العام": "جيد جداً" }
  ],
  "الصف الخامس الأساسي": [
    { "رقم الطالب": "501", "اسم الطالب": "منيرة عبد الله صالح", "اللغة العربية": 89, "الرياضيات": 91, "العلوم": 87, "المجموع": 267, "التقدير العام": "ممتاز" }
  ],
  "الصف السادس الأساسي": [
    { "رقم الطالب": "101", "اسم الطالب": "عمر أحمد اليوسف", "اللغة العربية": 100, "الرياضيات": 94, "العلوم العامة": 92, "اللغة الإنجليزية": 87, "المجموع": 373, "التقدير العام": "ممتاز مرتفع" }
  ],
  "الصف السابع الأساسي": [
    { "رقم الطالب": "701", "اسم الطالب": "فيصل أحمد العتيبي", "اللغة العربية": 88, "الرياضيات": 85, "العلوم": 84, "المجموع": 257, "التقدير العام": "جيد جداً" }
  ],
  "الصف الثامن الأساسي": [
    { "رقم الطالب": "801", "اسم الطالب": "شهد عبد الرحمن الشهري", "اللغة العربية": 94, "الرياضيات": 89, "العلوم": 91, "المجموع": 274, "التقدير العام": "ممتاز" }
  ],
  "الصف التاسع الأساسي": [
    { "رقم الطالب": "102", "اسم الطالب": "سارة محمد الكردي", "اللغة العربية": 103, "الرياضيات": 101, "الفيزياء والكيمياء": 96, "اللغة الإنجليزية": 100, "المجموع": 400, "التقدير العام": "ممتاز مرتفع (A+)" }
  ],
  "الصف الأول الثانوي": [
    { "رقم الطالب": "1001", "اسم الطالب": "عبد الرحمن خالد السعدي", "اللغة العربية": 90, "الرياضيات العامة": 92, "الفيزياء": 89, "الكيمياء": 91, "المجموع": 362, "التقدير العام": "ممتاز" }
  ],
  "الصف الثاني الثانوي": [
    { "رقم الطالب": "1101", "اسم الطالب": "جود محمد اليامي", "اللغة العربية": 96, "الرياضيات العلمية": 95, "الأحياء": 92, "الفيزياء": 93, "المجموع": 376, "التقدير العام": "ممتاز مرتفع" }
  ],
  "الصف الثالث الثانوي": [
    { "رقم الطالب": "1201", "اسم الطالب": "ماجد فيصل العتيبي", "اللغة العربية": 99, "الرياضيات المكثفة": 98, "الفيزياء": 97, "الكيمياء العضوية": 100, "المجموع": 394, "التقدير العام": "ممتاز مع مرتبة الشرف" }
  ]
};

const RESULTS_DB_PATH = path.join(process.cwd(), "results_database.json");

function loadResultsDB() {
  if (fs.existsSync(RESULTS_DB_PATH)) {
    try {
      const data = fs.readFileSync(RESULTS_DB_PATH, "utf8");
      return JSON.parse(data);
    } catch (e) {
      console.error("Error reading results database, resetting to default:", e);
    }
  }
  try {
    fs.writeFileSync(RESULTS_DB_PATH, JSON.stringify(DEFAULT_RESULTS, null, 2), "utf8");
  } catch (err) {
    console.error("Error writing initial results database:", err);
  }
  return DEFAULT_RESULTS;
}

function saveResultsDB(data: any) {
  try {
    fs.writeFileSync(RESULTS_DB_PATH, JSON.stringify(data, null, 2), "utf8");
    return true;
  } catch (err) {
    console.error("Error saving results database:", err);
    return false;
  }
}

const SCHOOL_DB_PATH = path.join(process.cwd(), "school_database.json");

function loadSchoolDB() {
  if (fs.existsSync(SCHOOL_DB_PATH)) {
    try {
      const data = fs.readFileSync(SCHOOL_DB_PATH, "utf8");
      return JSON.parse(data);
    } catch (e) {
      console.error("Error reading school database, resetting to default:", e);
    }
  }
  
  // Default structure
  const defaultDB = {
    news: [
      {
        id: "news-1",
        title: "حفل تكريم الطلبة المتفوقين للفصل الدراسي الأول",
        content: "كرمت إدارة مدرسة أمل المستقبل الأهلية كوكبة من طالباتها وطلابها المتفوقين في الحفل السنوي البهيج بحضور السادة أولياء الأمور وأعضاء الكادر الإداري والتعليمي تمنياتنا لهم بدوام التميز والنجاح.",
        date: "2026-05-15",
        category: "إنجاز",
        imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "news-2",
        title: "بدء التسجيل الإلكتروني للعام الدراسي الجديد 2026-2027",
        content: "تعلن إدارة مدرسة أمل المستقبل الأهلية عن فتح باب القبول والتسجيل للعام الدراسي الجديد لكافة المراحل التعليمية (رياض الأطفال، الابتدائي، الإعدادي، الثانوي). يرجى تقديم الطلبات إلكترونياً عبر البوابة الرسمية.",
        date: "2026-05-10",
        category: "إعلان",
        imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "news-3",
        title: "الرحلة المدرسية العلمية إلى معرض العلوم والاستكشاف",
        content: "نظمت المدرسة رحلة استكشافية لطلاب المرحلة المتوسطة والإعدادية إلى مختبرات العلوم والتكنولوجيا بهدف ترسيخ المفاهيم المنهجية عملياً وتوليد شغف الابتكار والبحث العلمي لدى طلابنا.",
        date: "2026-04-28",
        category: "رحلة",
        imageUrl: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "news-4",
        title: "حصول المدرسة على درع التميز في الأنشطة الرياضية والفيزيائية",
        content: "توج فريق المدرسة الرياضي بالمركز الأول في البطولة السنوية المفتوحة لكرة السلة والعدو الطويل على مستوى مدارس المنطقة. فخورون بأبطال المستقبل كادر تدريبياً ولاعبين.",
        date: "2026-04-18",
        category: "إنجاز",
        imageUrl: "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=600"
      }
    ],
    announcements: [
      {
        id: "ann-1",
        title: "تنبيه هام بشأن موعد انعقاد مجالس أولياء الأمور الدورية",
        content: "ندعو السادة أولياء أمور طلاب المرحلة الابتدائية والتمهيدي لحضور اللقاء المشترك يوم الأحد القادم لمتابعة المستويات الأكاديمية والخطط التقييمية.",
        target: "parents",
        date: "2026-05-19"
      },
      {
        id: "ann-2",
        title: "اعتماد التقويم النهائي للاختبارات النهائية وتعميم الإجراءات",
        content: "إلى كافة الكوادر التعليمية والطلاب، تم رفع جداول الاختبارات التفصيلية على صفحة النتائج والجداول. نرجو الحرص والالتزام بالوقت والمراجعة.",
        target: "all",
        date: "2026-05-18"
      },
      {
        id: "ann-3",
        title: "ورشة عمل تطوير مهارات استخدام منصة التعليم الذكية للمعلمين",
        content: "تعلن إدارة التدريب والتعليم المستمر عن عقد ورشة تفاعلية غداً في تمام الساعة الواحدة ظهراً لمناقشة تفعيل ميزات الذكاء الاصطناعي وكيفية رصد الواجبات والدرجات.",
        target: "teachers",
        date: "2026-05-16"
      }
    ],
    gallery: [
      {
        id: "g-1",
        title: "معمل الكيمياء والأحياء الحديث لطلاب الثانوي",
        category: "مرافق",
        imageUrl: "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "g-2",
        title: "المسرح المدرسي الكبير وحفل تخريج رواد المستقبل",
        category: "حفلات",
        imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "g-3",
        title: "حصص النشاط التفاعلي لطلاب الروضة والتمهيدي",
        category: "أنشطة",
        imageUrl: "https://images.unsplash.com/photo-1576267423445-b2e0074d68a4?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "g-4",
        title: "المكتبة المركزية الشاملة - واحة القراءة والاطلاع",
        category: "مرافق",
        imageUrl: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "g-5",
        title: "فصول نموذجية متكاملة بأحدث الشاشات الذكية",
        category: "فصول",
        imageUrl: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&q=80&w=600"
      },
      {
        id: "g-6",
        title: "المعرض الفني السنوي لرسومات وأعمال طلابنا اليدوية",
        category: "أنشطة",
        imageUrl: "https://images.unsplash.com/photo-1460518451285-97b6ba32ee61?auto=format&fit=crop&q=80&w=600"
      }
    ],
    students: [
      {
        id: "101",
        name: "عمر أحمد اليوسف",
        grade: "الصف السادس الابتدائي",
        level: "elementary",
        busRoute: "خط الحافلة B - شارع المطار والغربي",
        seatNumber: "A-12",
        attendance: {
          present: 42,
          absent: 2,
          excused: 1,
          history: [
            { date: "2026-05-19", status: "حاضر" },
            { date: "2026-05-18", status: "حاضر" },
            { date: "2026-05-17", status: "غائب" },
            { date: "2026-05-16", status: "حاضر" },
            { date: "2026-05-15", status: "حاضر" }
          ]
        },
        grades: [
          { subject: "اللغة العربية", midterm: 19, final: 76, homework: 5, total: 100, grade: "ممتاز (A+)" },
          { subject: "الرياضيات", midterm: 18, final: 72, homework: 4, total: 94, grade: "ممتاز (A)" },
          { subject: "العلوم العامة", midterm: 17, final: 70, homework: 5, total: 92, grade: "ممتاز (A)" },
          { subject: "اللغة الإنجليزية", midterm: 15, final: 68, homework: 4, total: 87, grade: "جيد جداً (B+)" }
        ],
        assignments: [
          { id: "as-1", subject: "الرياضيات", title: "حل مسألة المتتاليات ونظرية المجموعات ص32", dueDate: "2026-05-24", status: "pending" },
          { id: "as-2", subject: "اللغة العربية", title: "موضوع تعبير عن الكرم ومكارم الأخلاق في العصر الجاهلي", dueDate: "2026-05-21", status: "submitted" },
          { id: "as-3", subject: "العلوم العامة", title: "رسم مبسط لتركيب الخلايا النباتية والحيوانية", dueDate: "2026-05-18", status: "graded", grade: "10/10", feedback: "رسم غاية في الدقة وتوزيع ألوان رائع" }
        ],
        parentId: "parent-1"
      },
      {
        id: "102",
        name: "سارة محمد الكردي",
        grade: "الصف الثالث الإعدادي",
        level: "prep",
        busRoute: "بدون نقل - نقل خاص",
        seatNumber: "غير محجوز",
        attendance: {
          present: 44,
          absent: 1,
          excused: 0,
          history: [
            { date: "2026-05-19", status: "حاضر" },
            { date: "2026-05-18", status: "حاضر" },
            { date: "2026-05-17", status: "حاضر" },
            { date: "2026-05-16", status: "حاضر" },
            { date: "2026-05-15", status: "حاضر" }
          ]
        },
        grades: [
          { subject: "اللغة العربية", midterm: 20, final: 78, homework: 5, total: 103, grade: "ممتاز (A+)" },
          { subject: "الرياضيات", midterm: 19, final: 77, homework: 5, total: 101, grade: "ممتاز (A+)" },
          { subject: "الفيزياء والكمياء", midterm: 18, final: 73, homework: 5, total: 96, grade: "ممتاز (A)" },
          { subject: "اللغة الإنجليزية", midterm: 20, final: 75, homework: 5, total: 100, grade: "ممتاز (A+)" }
        ],
        assignments: [
          { id: "as-4", subject: "الفيزياء والكمياء", title: "تقرير مصور عن تجارب التفاعلات الطاردة للحرارة", dueDate: "2026-05-25", status: "pending" },
          { id: "as-5", subject: "الرياضيات", title: "حل مسائل حساب المثلثات الإضافية", dueDate: "2026-05-22", status: "pending" },
          { id: "as-6", subject: "اللغة العربية", title: "إعراب قصيدة لغة الضاد كاملة وبشرح الأبيات", dueDate: "2026-05-17", status: "graded", grade: "15/15", feedback: "أحسنتِ النحو المتميز أداءً رائعاً" }
        ],
        parentId: "parent-2"
      },
      {
        id: "103",
        name: "يوسف محمد الكردي",
        grade: "الصف الأول الابتدائي",
        level: "elementary",
        busRoute: "خط الحافلة A - الميناء والشعب",
        seatNumber: "B-04",
        attendance: {
          present: 40,
          absent: 4,
          excused: 1,
          history: [
            { date: "2026-05-19", status: "حاضر" },
            { date: "2026-05-18", status: "غائب" },
            { date: "2026-05-17", status: "حاضر" },
            { date: "2026-05-16", status: "حاضر" },
            { date: "2026-05-15", status: "حاضر" }
          ]
        },
        grades: [
          { subject: "اللغة العربية", midterm: 15, final: 65, homework: 5, total: 85, grade: "جيد جداً (B)" },
          { subject: "الرياضيات والعد", midterm: 16, final: 70, homework: 4, total: 90, grade: "ممتاز (A)" },
          { subject: "دروس الاستكشاف ورسم", midterm: 18, final: 75, homework: 5, total: 98, grade: "ممتاز (A+)" }
        ],
        assignments: [
          { id: "as-7", subject: "اللغة العربية", title: "كتابة الحروف من الألف إلى الياء مكررة مرتين بخط جميل", dueDate: "2026-05-23", status: "pending" }
        ],
        parentId: "parent-2"
      }
    ],
    parents: [
      {
        id: "parent-1",
        name: "أحمد عمر اليوسف",
        phone: "783711148",
        email: "ahmed@example.com",
        students: ["101"],
        financials: {
          totalFees: 12000,
          paidFees: 8000,
          remainingFees: 4000,
          transactions: [
            { id: "tx-1", amount: 4000, date: "2026-05-01", title: "رسوم القسط الثاني - الفصل الدراسي الثاني", status: "مقبول" },
            { id: "tx-2", amount: 4000, date: "2026-01-10", title: "رسوم تقسيط الكتب وتوصيل الحافلة المدرسية", status: "مقبول" }
          ]
        }
      },
      {
        id: "parent-2",
        name: "محمد الكردي",
        phone: "711114173",
        email: "kurdi@example.com",
        students: ["102", "103"],
        financials: {
          totalFees: 24000,
          paidFees: 15000,
          remainingFees: 9000,
          transactions: [
            { id: "tx-3", amount: 10000, date: "2026-04-15", title: "رسوم الفصل الدراسي الثاني كاملة للطالبين سارة ويوسف", status: "مقبول" },
            { id: "tx-4", amount: 5000, date: "2026-05-10", title: "رسوم حافلة وأنشطة ترفيهية سنوية", status: "مقبول" },
            { id: "tx-5", amount: 9000, date: "2026-05-19", title: "طلب تسوية القسط المتبقي للعام", status: "قيد الانتظار" }
          ]
        }
      }
    ],
    teachers: [
      {
        id: "teach-101",
        name: "الأستاذ خالد الدوسري",
        subject: "الرياضيات",
        grades: ["الصف السادس الابتدائي", "الصف الثالث الإعدادي"],
        imageUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200",
        bio: "أستاذ رياضيات ذو خبرة تفوق 10 سنوات في تقديم وتسهيل مفاهيم الهندسة وحساب المثلثات.",
        lessons: [
          { id: "l-1", title: "شرح درس المتتاليات العددية البسيطة والكسور", grade: "الصف السادس الابتدائي", date: "2026-05-18", description: "ملف PDF يحتوي على أمثلة توضيحية لتبسيط جمع وطرح الكسور الكبيرة وتطبيقات حياتية." },
          { id: "l-2", title: "مقدمة عامة في حساب المثلثات للشهادة الإعدادية", grade: "الصف الثالث الإعدادي", date: "2026-05-15", description: "شرح شامل للنسب المثلثية الأساسية (جا، جتا، ظا) وقوانين المثلث قائم الزاوية." }
        ],
        assignments: [
          { id: "as-1", title: "حل مسألة المتتاليات ونظرية المجموعات ص32", subject: "الرياضيات", grade: "الصف السادس الابتدائي", dueDate: "2026-05-24", maxDegrees: 10 },
          { id: "as-5", title: "حل مسائل حساب المثلثات الإضافية", subject: "الرياضيات", grade: "الصف الثالث الإعدادي", dueDate: "2026-05-22", maxDegrees: 15 }
        ]
      },
      {
        id: "teach-102",
        name: "الأستاذة ميساء الحلبي",
        subject: "اللغة العربية",
        grades: ["الصف السادس الابتدائي", "الصف الثالث الإعدادي", "الصف الأول الابتدائي"],
        imageUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
        bio: "أستاذة اللغة العربية وبلاغتها للأطوار الأساسية والإعدادية، مهتمة بجماليات الخط العربي.",
        lessons: [
          { id: "l-3", title: "شرح نصب وجزم الأفعال المضارعة وأمثلتها الإعرابية", grade: "الصف السادس الابتدائي", date: "2026-05-17", description: "مذكرة تفاعلية تتضمن تلخيص علامات الإعراب الأصلية والفرعية للأفعال." },
          { id: "l-4", title: "تدريبات الحروف الأبجدية والمد الطويل والقصير", grade: "الصف الأول الابتدائي", date: "2026-05-19", description: "رابط فيديو ترفيهي لمساعدة أطفال الصف الأول على تهجئة الحروف بالتطبيقات العملية." }
        ],
        assignments: [
          { id: "as-2", title: "موضوع تعبير عن الكرم ومكارم الأخلاق في العصر الجاهلي", subject: "اللغة العربية", grade: "الصف السادس الابتدائي", dueDate: "2026-05-21", maxDegrees: 10 },
          { id: "as-7", title: "كتابة الحروف من الألف إلى الياء مكررة مرتين بخط جميل", subject: "اللغة العربية", grade: "الصف الأول الابتدائي", dueDate: "2026-05-23", maxDegrees: 5 }
        ]
      }
    ],
    registrationRequests: [
      {
        id: "reg-1",
        studentName: "رائد سامر العلي",
        parentName: "سامر العلي",
        phone: "711114480",
        email: "samer@example.com",
        grade: "الصف الأول الإعدادي",
        level: "prep",
        birthDate: "2013-04-12",
        documents: {
          idCard: true,
          birthCert: true,
          prevSchoolCert: true
        },
        status: "pending",
        createdAt: "2026-05-15"
      },
      {
        id: "reg-2",
        studentName: "هبة مصطفى زقوت",
        parentName: "مصطفى زقوت",
        phone: "783711148",
        email: "mostafa@example.com",
        grade: "الصف الأول الابتدائي",
        level: "elementary",
        birthDate: "2020-08-05",
        documents: {
          idCard: true,
          birthCert: true,
          prevSchoolCert: false
        },
        status: "approved",
        createdAt: "2026-05-12"
      }
    ],
    busRoutes: [
      {
        id: "bus-a",
        name: "خط الحافلة A (ذهبي)",
        route: "باجل، الميناء، حي الشعب والأطراف المجاورة",
        driver: "الكابتن عادل المشجر",
        phone: "773195229",
        capacity: 25,
        supervisor: "أ. سلوى أحمد",
        status: "active"
      },
      {
        id: "bus-b",
        name: "خط الحافلة B (فضي)",
        route: "شارع المطار، الحي الغربي والمخطط القديم",
        driver: "الكابتن طارق الهادي",
        phone: "711823901",
        capacity: 25,
        supervisor: "أ. خديجة عمر",
        status: "active"
      },
      {
        id: "bus-c",
        name: "خط الحافلة C (احتياطي)",
        route: "المخطط الدائري، ومجمع الإدارة الأهلية الجديد",
        driver: "الكابتن صبري حزام",
        phone: "739501533",
        capacity: 20,
        supervisor: "أ. ماجد عثمان",
        status: "suspended"
      }
    ],
    feesTemplates: {
      "الصف الأول الابتدائي": { tuition: 4000, bus: 2000, uniform: 1000, books: 1000 },
      "الصف الثاني الابتدائي": { tuition: 4000, bus: 2000, uniform: 1000, books: 1200 },
      "الصف الثالث الابتدائي": { tuition: 4500, bus: 2000, uniform: 1000, books: 1200 },
      "الصف الرابع الابتدائي": { tuition: 5000, bus: 2000, uniform: 1200, books: 1300 },
      "الصف الخامس الابتدائي": { tuition: 5200, bus: 2000, uniform: 1200, books: 1400 },
      "الصف السادس الابتدائي": { tuition: 5500, bus: 2000, uniform: 1250, books: 1500 },
      "الصف الأول الإعدادي": { tuition: 6000, bus: 2500, uniform: 1300, books: 1600 },
      "الصف الثاني الإعدادي": { tuition: 6500, bus: 2500, uniform: 1300, books: 1700 },
      "الصف الثالث الإعدادي": { tuition: 7000, bus: 2500, uniform: 1300, books: 1800 },
      "الصف الأول الثانوي": { tuition: 8000, bus: 3000, uniform: 1500, books: 2000 },
      "الصف الثاني الثانوي": { tuition: 8500, bus: 3000, uniform: 1500, books: 2200 },
      "الصف الثالث الثانوي": { tuition: 10000, bus: 3000, uniform: 1500, books: 2500 }
    },
    dailyHomeworks: []
  };

  try {
    fs.writeFileSync(SCHOOL_DB_PATH, JSON.stringify(defaultDB, null, 2), "utf8");
  } catch (err) {
    console.error("Error writing default school database:", err);
  }
  return defaultDB;
}

function saveSchoolDB(data: any) {
  try {
    fs.writeFileSync(SCHOOL_DB_PATH, JSON.stringify(data, null, 2), "utf8");
    return true;
  } catch (err) {
    console.error("Error saving school database:", err);
    return false;
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for body parsing
  app.use(express.json());

  // API Route: Smart AI Student Assistant
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "مصفوفة الرسائل مطلوبة." });
      }

      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        return res.status(500).json({ 
          error: "مفتاح Gemini API غير مكوّن. يرجى تهيئته في لوحة الإعدادات (Secrets)." 
        });
      }

      const ai = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const systemInstruction = `أنت المساعد التعليمي الذكي في مدرسة أمل المستقبل الأهلية واسمك "مساعد أمل الذكي".
تتحدث باللغة العربية الفصحى المبسطة بأسلوب تربوي مشجع وودود.
تساعد الطلاب في شرح الواجبات والمواد الدراسية (الرياضيات، العلوم، اللغة العربية، الإنجليزية، التاريخ، وغيرها) وتقديم أمثلة تعليمية تفاعلية.
كما تقترح خططاً دراسية مخصصة ونصائح للمذاكرة وأفضل الممارسات التعليمية لأولياء الأمور والمعلمين.
حافظ على لمسة من التفاؤل والأمل دائماً في إجاباتك تماشياً مع اسم المدرسة "أمل المستقبل".`;

      const contents = messages.map((m: any) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content || "" }]
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
        }
      });

      res.json({ text: response.text });
    } catch (err: any) {
      console.error("Gemini API server route error:", err);
      res.status(500).json({ 
        error: err.message || "حدث خطأ داخلي أثناء معالجة طلب الذكاء الاصطناعي." 
      });
    }
  });

  // API Endpoint: Get all school master data (server-side persistence)
  app.get("/api/school-data", (req, res) => {
    try {
      const db = loadSchoolDB();
      res.json(db);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to load school DB" });
    }
  });

  // API Endpoint: Save school key or complete data (server-side persistence)
  app.post("/api/school-data", (req, res) => {
    try {
      const { key, data } = req.body;
      const db = loadSchoolDB();
      
      if (key && data !== undefined) {
        db[key] = data;
        const success = saveSchoolDB(db);
        if (success) {
          return res.json({ status: "success", message: `تم حفظ تحديثات البينات لـ ${key} بنجاح على الخادم ✓` });
        }
      } else {
        // Fallback or complete save
        const success = saveSchoolDB(req.body);
        if (success) {
          return res.json({ status: "success", message: "تم حفظ كافة البيانات بنجاح على الخادم الرئيسي ✓" });
        }
      }
      res.status(500).json({ error: "فشل حفظ البيانات على الخادم" });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to save school DB" });
    }
  });

  // API Endpoint: Get all results (server-side persistence)
  app.get("/api/results", (req, res) => {
    try {
      const db = loadResultsDB();
      res.json(db);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to load results DB" });
    }
  });

  // API Endpoint: Save results (server-side persistence)
  app.post("/api/results", (req, res) => {
    try {
      const data = req.body;
      if (!data || typeof data !== "object") {
        return res.status(400).json({ error: "بيانات النتائج غير صالحة." });
      }
      const success = saveResultsDB(data);
      if (success) {
        res.json({ status: "success", message: "تم رصد وحفظ النتائج بنجاح على الخادم الرئيسي 🛡️" });
      } else {
        res.status(500).json({ error: "فشل حفظ البيانات على الخادم" });
      }
    } catch (error: any) {
      res.status(550).json({ error: error.message || "Failed to save results DB" });
    }
  });

  // Health endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // API Endpoint to export the entire workspace source code + databases inside a ZIP
  app.get("/api/export-full-project-zip", async (req, res) => {
    try {
      const zip = new JSZip();
      const rootDir = process.cwd();

      function addFilesRecursively(currentDir: string, zipFolder: JSZip) {
        const items = fs.readdirSync(currentDir);
        for (const item of items) {
          if (
            item === "node_modules" ||
            item === ".git" ||
            item === "dist" ||
            item === ".npm" ||
            item === ".cache" ||
            item.startsWith(".")
          ) {
            continue;
          }
          const fullPath = path.join(currentDir, item);
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) {
            const folder = zipFolder.folder(item);
            if (folder) {
              addFilesRecursively(fullPath, folder);
            }
          } else {
            const content = fs.readFileSync(fullPath);
            zipFolder.file(item, content);
          }
        }
      }

      addFilesRecursively(rootDir, zip);

      const content = await zip.generateAsync({ type: "nodebuffer" });
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", "attachment; filename=amlf_school_project_full_source.zip");
      res.send(content);
    } catch (err: any) {
      console.error("Error zipping project source files:", err);
      res.status(500).json({ error: "فشل تجميع وأرشفة ملفات المشروع المصدرية." });
    }
  });

  // Vite Integration for Serving Frontend
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server started on http://0.0.0.0:${PORT} under NODE_ENV=${process.env.NODE_ENV || 'development'}`);
  });
}

startServer().catch((error) => {
  console.error("Failed to start server:", error);
});
